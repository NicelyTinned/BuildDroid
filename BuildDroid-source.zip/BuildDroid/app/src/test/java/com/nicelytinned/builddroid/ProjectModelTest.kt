package com.nicelytinned.builddroid

import com.nicelytinned.builddroid.model.BuildDroidProject
import org.junit.Assert.assertEquals
import org.junit.Test

class ProjectModelTest {
    @Test
    fun repositoryNameIsGithubSafe() {
        val project = BuildDroidProject(name = "My Cool Game!!!")
        assertEquals("my-cool-game", project.repositoryName())
    }

    @Test
    fun emptyNameUsesFallbackRepositoryName() {
        val project = BuildDroidProject(name = " !!! ")
        assertEquals("builddroid-project", project.repositoryName())
    }
}
