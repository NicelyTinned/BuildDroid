package com.nicelytinned.builddroid

import com.nicelytinned.builddroid.model.BuildDroidProject
import com.nicelytinned.builddroid.model.GameScene
import com.nicelytinned.builddroid.model.ProjectItem
import com.nicelytinned.builddroid.model.ScriptDocument
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectModelTest {
    @Test
    fun repositoryNameIsGithubSafe() {
        val project = BuildDroidProject(name = "My Cool Game!!!")
        assertEquals("my-cool-game", project.repositoryName())
    }

    @Test
    fun emptyNameUsesFallbackRepositoryName() {
        val project = BuildDroidProject(name = " !!! ")
        assertEquals("builddroid-project", project.repositoryName())
    }

    @Test
    fun formatTwoRoundTripPreservesScenesPropertiesAndEvents() {
        val instance = ProjectItem(
            objectId = "player-def", name = "Player", x = 123f, y = 45f,
            width = 50f, height = 80f, rotation = 17f, depth = -2,
            scaleX = 1.5f, scaleY = 0.75f, alpha = 0.6f,
            velocityX = 12f, velocityY = -5f, gravity = 9.8f,
            variables = mapOf("health" to "100"),
        )
        val project = BuildDroidProject(
            name = "Round Trip",
            scenes = listOf(GameScene(id = "scene-a", name = "Arena", instances = listOf(instance))),
            activeSceneId = "scene-a",
            scripts = listOf(ScriptDocument(id = "event-a", name = "Player Step", source = "Game.log('tick')", targetObjectId = "player-def", eventType = "Step")),
            selectedScriptId = "event-a",
        )

        val restored = BuildDroidProject.fromJson(project.toJson())
        assertEquals(project.name, restored.name)
        assertEquals("Arena", restored.currentScene.name)
        assertEquals(instance, restored.currentScene.instances.single())
        assertEquals(project.scripts.single(), restored.scripts.single())
        assertEquals("event-a", restored.selectedScriptId)
    }

    @Test
    fun versionOneProjectMigrationCreatesObjectDefinitionsForInstances() {
        val old = JSONObject()
            .put("formatVersion", 1)
            .put("name", "Legacy Project")
            .put("items", JSONArray().put(JSONObject()
                .put("id", "old-player")
                .put("name", "Player")
                .put("kind", "Rectangle")
                .put("x", 22)
                .put("y", 33)))
            .put("script", "Game.log('legacy')")

        val migrated = BuildDroidProject.fromJson(old)
        val instance = migrated.items.single()
        assertTrue(migrated.objects.any { it.id == instance.objectId })
        assertEquals("Player", migrated.objects.single { it.id == instance.objectId }.name)
        assertEquals("Game.log('legacy')", migrated.script)
        assertNotEquals("", instance.objectId)
    }
}
