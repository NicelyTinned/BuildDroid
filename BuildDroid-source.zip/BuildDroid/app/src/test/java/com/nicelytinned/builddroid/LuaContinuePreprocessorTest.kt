package com.nicelytinned.builddroid

import com.nicelytinned.builddroid.lua.LuaContinuePreprocessor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class LuaContinuePreprocessorTest {
    @Test
    fun continueIsRewrittenInsideWhileLoopAndBreakSemanticsArePreserved() {
        val source = """while Game.keyboard_check("right") do
            if Game.keyboard_check("up") then continue end
            if Game.keyboard_check("down") then break end
            Game.log("step")
        end"""
        val transformed = LuaContinuePreprocessor.transform(source)
        assertTrue(transformed.contains("repeat"))
        assertTrue(transformed.contains("until true"))
        assertTrue(transformed.contains("then break end"))
        assertTrue(transformed.contains("= true; break"))
    }

    @Test
    fun nestedLoopsReceiveIndependentContinueScopes() {
        val source = """for i = 1, 4 do
            while Game.instance_count() > 0 do
                if i == 2 then continue end
                break
            end
            continue
        end"""
        val transformed = LuaContinuePreprocessor.transform(source)
        assertTrue(Regex("local __builddroid_continue_").findAll(transformed).count() == 2)
        assertTrue(transformed.contains("__builddroid_continue_1 = true; break") || transformed.contains("__builddroid_continue_2 = true; break"))
    }

    @Test
    fun stringsAndCommentsAreNotRewritten() {
        val source = "local label = \"continue\" -- continue\nGame.log(label)"
        assertEquals(source, LuaContinuePreprocessor.transform(source))
    }

    @Test
    fun continueWorksBetweenSemicolonSeparatedStatements() {
        val source = "while true do local ignored = 1; continue; Game.log(ignored) end"
        val transformed = LuaContinuePreprocessor.transform(source)
        assertTrue(transformed.contains("break; Game.log(ignored)"))
    }

    @Test
    fun continueAsAnIdentifierOrFunctionCallIsNotRewritten() {
        val source = "while true do local continue = function() end; continue() end"
        assertEquals(source, LuaContinuePreprocessor.transform(source))
    }

    @Test
    fun repeatUntilContinueExplainsLua51ScopeLimitation() {
        try {
            LuaContinuePreprocessor.transform("repeat\n continue\nuntil true")
            fail("Expected repeat/until continue to be rejected")
        } catch (error: IllegalArgumentException) {
            assertTrue(error.message.orEmpty().contains("repeat/until"))
        }
    }

    @Test
    fun sourceWithoutContinueIsReturnedUnchanged() {
        val source = "while true do break end"
        assertEquals(source, LuaContinuePreprocessor.transform(source))
    }
}
