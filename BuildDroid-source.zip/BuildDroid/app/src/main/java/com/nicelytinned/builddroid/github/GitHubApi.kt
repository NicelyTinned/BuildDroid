package com.nicelytinned.builddroid.github

import android.content.Context
import android.os.Environment
import android.util.Base64
import com.nicelytinned.builddroid.model.BuildDroidProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.time.Instant
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/** Small REST client for the BuildDroid GitHub Actions build path. */
class GitHubApi(private val token: String, private val context: Context) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private data class ApiResponse(val code: Int, val body: String)

    private suspend fun request(
        method: String,
        path: String,
        json: JSONObject? = null,
        allow404: Boolean = false,
    ): ApiResponse = withContext(Dispatchers.IO) {
        val url = if (path.startsWith("https://")) path else "https://api.github.com$path"
        val requestBuilder = Request.Builder()
            .url(url)
            .header("Accept", "application/vnd.github+json")
            .header("Authorization", "Bearer $token")
            .header("X-GitHub-Api-Version", API_VERSION)
            .header("User-Agent", "BuildDroid-NicelyTinned")

        val requestBody = json?.toString()?.toRequestBody(JSON_MEDIA_TYPE)
        requestBuilder.method(method, if (method == "GET" || method == "DELETE") null else requestBody ?: "{}".toRequestBody(JSON_MEDIA_TYPE))

        http.newCall(requestBuilder.build()).execute().use { response ->
            val bodyText = response.body?.string().orEmpty()
            if (!response.isSuccessful && !(allow404 && response.code == 404)) {
                val message = runCatching { JSONObject(bodyText).optString("message") }
                    .getOrNull().orEmpty()
                    .ifBlank { response.message }
                throw IOException("GitHub API error ${response.code}: $message")
            }
            ApiResponse(response.code, bodyText)
        }
    }

    suspend fun authenticatedLogin(): String {
        val result = request("GET", "/user")
        return JSONObject(result.body).optString("login").ifBlank {
            throw IOException("GitHub did not return an account name.")
        }
    }

    private suspend fun getRepository(owner: String, repository: String): JSONObject? {
        val result = request("GET", "/repos/${segment(owner)}/${segment(repository)}", allow404 = true)
        return if (result.code == 404) null else JSONObject(result.body)
    }

    private suspend fun ensureRepository(owner: String, repository: String, description: String): JSONObject {
        getRepository(owner, repository)?.let { return it }

        val payload = JSONObject()
            .put("name", repository)
            .put("description", "BuildDroid project: $description")
            .put("private", true)
            .put("auto_init", false)
        val created = request("POST", "/user/repos", payload)
        return JSONObject(created.body)
    }

    suspend fun publishProject(
        project: BuildDroidProject,
        files: LinkedHashMap<String, String>,
        onProgress: (String) -> Unit,
        binaryFiles: LinkedHashMap<String, ByteArray> = linkedMapOf(),
    ): Pair<String, String> {
        val owner = authenticatedLogin()
        val repositoryName = project.repositoryName()
        onProgress("Checking repository $owner/$repositoryName…")
        var repository = ensureRepository(owner, repositoryName, project.name)
        var branch = repository.optString("default_branch").ifBlank { "main" }
        var isEmpty = repository.optInt("size", 0) == 0

        // README is always the first commit in an empty repository so GitHub creates its default branch.
        val orderedFiles = LinkedHashMap<String, ByteArray>()
        if (files.containsKey("README.md")) orderedFiles["README.md"] = files.getValue("README.md").toByteArray(Charsets.UTF_8)
        files.forEach { (path, content) -> if (path != "README.md") orderedFiles[path] = content.toByteArray(Charsets.UTF_8) }
        binaryFiles.forEach { (path, content) -> orderedFiles[path] = content }

        orderedFiles.forEach { (path, content) ->
            onProgress("Uploading $path…")
            putFile(owner, repositoryName, path, content, if (isEmpty) null else branch)
            if (isEmpty) {
                repository = getRepository(owner, repositoryName) ?: repository
                branch = repository.optString("default_branch").ifBlank { "main" }
                isEmpty = false
            }
        }
        repository = getRepository(owner, repositoryName) ?: repository
        branch = repository.optString("default_branch").ifBlank { branch }
        return owner to branch
    }

    private suspend fun putFile(
        owner: String,
        repository: String,
        path: String,
        content: ByteArray,
        branch: String?,
    ) {
        val encodedPath = path.split('/').joinToString("/") { segment(it) }
        val branchQuery = branch?.let { "?ref=${query(it)}" }.orEmpty()
        val existing = request(
            "GET",
            "/repos/${segment(owner)}/${segment(repository)}/contents/$encodedPath$branchQuery",
            allow404 = true,
        )
        val sha = if (existing.code == 404) null else JSONObject(existing.body).optString("sha").ifBlank { null }
        val payload = JSONObject()
            .put("message", "BuildDroid: sync $path")
            .put("content", Base64.encodeToString(content, Base64.NO_WRAP))
        if (sha != null) payload.put("sha", sha)
        if (branch != null) payload.put("branch", branch)
        request("PUT", "/repos/${segment(owner)}/${segment(repository)}/contents/$encodedPath", payload)
    }

    suspend fun dispatchAndWait(
        owner: String,
        repository: String,
        branch: String,
        onProgress: (String) -> Unit,
    ): Long {
        val base = "/repos/${segment(owner)}/${segment(repository)}"
        val previousRunIds = recentRunIds(base, branch)
        val dispatchTime = Instant.now()

        onProgress("Starting GitHub Actions build…")
        request(
            "POST",
            "$base/actions/workflows/$WORKFLOW_FILE/dispatches",
            JSONObject().put("ref", branch),
        )

        var runId: Long? = null
        for (attempt in 0 until RUN_DISCOVERY_ATTEMPTS) {
            delay(RUN_DISCOVERY_DELAY_MS)
            val runs = listRuns(base, branch)
            val fresh = runs.firstOrNull { run ->
                val id = run.optLong("id")
                val createdAt = run.optString("created_at")
                id !in previousRunIds && createdAt >= dispatchTime.minusSeconds(30).toString()
            }
            if (fresh != null) {
                runId = fresh.optLong("id")
                break
            }
        }
        val discoveredRunId = runId ?: throw IOException(
            "GitHub accepted the build request but no workflow run appeared. Check that Actions are enabled and the workflow is on the default branch.",
        )

        repeat(BUILD_POLL_ATTEMPTS) {
            val run = JSONObject(request("GET", "$base/actions/runs/$discoveredRunId").body)
            val status = run.optString("status")
            val conclusion = run.optString("conclusion")
            onProgress("GitHub Actions: ${status.ifBlank { "working" }}${if (status == "completed") " ($conclusion)" else ""}…")
            if (status == "completed") {
                if (conclusion != "success") {
                    throw IOException("GitHub Actions build finished with '$conclusion'. Open the workflow run in GitHub to inspect its logs.")
                }
                return discoveredRunId
            }
            delay(BUILD_POLL_DELAY_MS)
        }
        throw IOException("The GitHub Actions build did not finish before the polling limit.")
    }

    private suspend fun recentRunIds(base: String, branch: String): Set<Long> =
        listRuns(base, branch).mapNotNull { run -> run.optLong("id").takeIf { it > 0 } }.toSet()

    private suspend fun listRuns(base: String, branch: String): List<JSONObject> {
        val result = request(
            "GET",
            "$base/actions/runs?event=workflow_dispatch&branch=${query(branch)}&per_page=20",
        )
        val array = JSONObject(result.body).optJSONArray("workflow_runs") ?: JSONArray()
        return (0 until array.length()).mapNotNull { array.optJSONObject(it) }
    }

    suspend fun downloadApk(owner: String, repository: String, runId: Long): File = withContext(Dispatchers.IO) {
        val artifactsResponse = request(
            "GET",
            "/repos/${segment(owner)}/${segment(repository)}/actions/runs/$runId/artifacts?per_page=100",
        )
        val artifacts = JSONObject(artifactsResponse.body).optJSONArray("artifacts") ?: JSONArray()
        val artifact = (0 until artifacts.length())
            .mapNotNull { artifacts.optJSONObject(it) }
            .firstOrNull { it.optString("name") == ARTIFACT_NAME && !it.optBoolean("expired") }
            ?: throw IOException("The build succeeded, but the APK artifact was not found.")

        val artifactId = artifact.optLong("id")
        val downloadUrl = "https://api.github.com/repos/${segment(owner)}/${segment(repository)}/actions/artifacts/$artifactId/zip"
        val request = Request.Builder()
            .url(downloadUrl)
            .header("Accept", "application/vnd.github+json")
            .header("Authorization", "Bearer $token")
            .header("X-GitHub-Api-Version", API_VERSION)
            .header("User-Agent", "BuildDroid-NicelyTinned")
            .get()
            .build()

        val outputDirectory = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir,
            "BuildDroid",
        )
        if (!outputDirectory.exists()) outputDirectory.mkdirs()
        val zipFile = File(outputDirectory, "builddroid-artifact.zip")
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Could not download build artifact (HTTP ${response.code}).")
            val body = response.body ?: throw IOException("GitHub returned an empty artifact.")
            body.byteStream().use { input -> zipFile.outputStream().use { output -> input.copyTo(output) } }
        }

        var apkFile: File? = null
        ZipInputStream(zipFile.inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && entry.name.lowercase().endsWith(".apk")) {
                    val safeName = "${repository}-${runId}.apk"
                    val destination = File(outputDirectory, safeName)
                    destination.outputStream().use { output -> zip.copyTo(output) }
                    apkFile = destination
                    break
                }
                zip.closeEntry()
            }
        }
        zipFile.delete()
        apkFile ?: throw IOException("The artifact archive did not contain an APK.")
    }

    private fun segment(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name()).replace("+", "%20")
    private fun query(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private companion object {
        const val API_VERSION = "2026-03-10"
        const val WORKFLOW_FILE = "builddroid-android.yml"
        const val ARTIFACT_NAME = "builddroid-apk"
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        const val RUN_DISCOVERY_ATTEMPTS = 45
        const val RUN_DISCOVERY_DELAY_MS = 4_000L
        const val BUILD_POLL_ATTEMPTS = 360
        const val BUILD_POLL_DELAY_MS = 5_000L
    }
}
