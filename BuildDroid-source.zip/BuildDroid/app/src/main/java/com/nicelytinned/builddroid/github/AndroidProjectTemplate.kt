package com.nicelytinned.builddroid.github

import com.nicelytinned.builddroid.model.BuildDroidProject

/** Files uploaded to the per-game repository before its Actions workflow is dispatched. */
object AndroidProjectTemplate {
    fun files(project: BuildDroidProject): LinkedHashMap<String, String> = linkedMapOf(
        "README.md" to readme(project),
        "settings.gradle.kts" to settingsGradle(project),
        "build.gradle.kts" to rootBuildGradle,
        "gradle.properties" to gradleProperties,
        "app/build.gradle.kts" to appBuildGradle,
        "app/src/main/AndroidManifest.xml" to manifest(project),
        "app/src/main/java/com/nicelytinned/game/MainActivity.kt" to mainActivity,
        "app/src/main/assets/game-api.lua" to gameApi,
        "app/src/main/assets/main.lua" to project.script,
        "app/src/test/java/com/nicelytinned/game/GameApiContractTest.kt" to contractTest,
        "builddroid-project.json" to project.toJson().toString(2),
        ".github/workflows/builddroid-android.yml" to workflow,
    )

    private fun readme(project: BuildDroidProject) = """# ${project.name}

Created with **BuildDroid** by **NicelyTinned**.

This is the first BuildDroid Android export. It includes:

- An Android APK shell for a 2D game project.
- A Lua 5.1 runtime powered by LuaJava.
- The first `Game` API smoke-test functions (`log`, `instance_create`, `instance_count`, `instance_get`, `keyboard_check`, and `scene_name`).
- A GitHub Actions workflow that builds a debug APK and uploads it as `builddroid-apk`.

The current runtime is an early test target: it runs the project's Lua script and displays a placeholder 2D screen. Scene rendering, input wiring, object event lifecycles, and full editor export are future engine work.

## Build locally

Open this project in Android Studio, sync Gradle, then run `:app:assembleDebug`.

## Lua

The project script is at `app/src/main/assets/main.lua`. The small engine API is loaded from `app/src/main/assets/game-api.lua` first.
"""

    private fun settingsGradle(project: BuildDroidProject) = """pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "${project.repositoryName().replace('-', '_')}"
include(":app")
"""

    private val rootBuildGradle = """plugins {
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
}
"""

    private val gradleProperties = """org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8
org.gradle.parallel=true
android.useAndroidX=true
kotlin.code.style=official
"""

    private val appBuildGradle = """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nicelytinned.game"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.nicelytinned.game"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("party.iroiro.luajava:luajava:4.1.0")
    implementation("party.iroiro.luajava:lua51:4.1.0")
    runtimeOnly("party.iroiro.luajava:android:4.1.0:lua51@aar")
    testImplementation("junit:junit:4.13.2")
}
"""

    private fun manifest(project: BuildDroidProject) = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="false"
        android:label="${xmlAttribute(project.name)}"
        android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""

    private fun xmlAttribute(value: String): String = value
        .replace("&", "&amp;")
        .replace("\"", "&quot;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("'", "&apos;")

    private val mainActivity = """package com.nicelytinned.game

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.View
import party.iroiro.luajava.lua51.Lua51

class MainActivity : Activity() {
    private lateinit var gameSurface: GameSurface

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gameSurface = GameSurface(this)
        setContentView(gameSurface)

        // Run project Lua away from the UI thread so a script cannot block first paint.
        Thread({
            try {
                Lua51().use { lua ->
                    lua.openLibraries()
                    lua.run(assets.open("game-api.lua").bufferedReader().use { it.readText() })
                    lua.run(assets.open("main.lua").bufferedReader().use { it.readText() })
                }
            } catch (error: Throwable) {
                runOnUiThread { gameSurface.scriptError = error.message ?: "Lua runtime error" }
            }
        }, "BuildDroid-Lua").start()
    }
}

private class GameSurface(context: Context) : View(context) {
    var scriptError: String? = null
        set(value) {
            field = value
            postInvalidate()
        }

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(20, 24, 32) }
    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(48, 58, 75) }
    private val playerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(79, 190, 145) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 42f
    }
    private val smallTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(190, 201, 218)
        textSize = 24f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(20, 24, 32))
        canvas.drawText("Built with BuildDroid", 32f, 64f, textPaint)
        canvas.drawRoundRect(RectF(28f, 100f, width - 28f, height - 28f), 22f, 22f, panelPaint)
        canvas.drawRoundRect(RectF(100f, 220f, 190f, 310f), 16f, 16f, playerPaint)
        canvas.drawText("2D project preview", 52f, 160f, smallTextPaint)
        scriptError?.let { error ->
            textPaint.textSize = 26f
            textPaint.color = Color.rgb(255, 145, 145)
            canvas.drawText("Lua: ${'$'}{error.take(90)}", 52f, height - 70f, textPaint)
        }
    }
}
"""

    private val gameApi = """-- BuildDroid's first Lua 5.1 API smoke-test surface.
Game = {
    logs = {},
    instances = {},
    current_scene = "MainScene"
}

function Game.log(message)
    table.insert(Game.logs, tostring(message))
end

function Game.instance_create(object_name, x, y)
    local id = #Game.instances + 1
    Game.instances[id] = {
        id = id,
        object = tostring(object_name),
        x = tonumber(x) or 0,
        y = tonumber(y) or 0
    }
    Game.log("Created " .. tostring(object_name) .. " #" .. tostring(id))
    return id
end

function Game.instance_count()
    return #Game.instances
end

function Game.instance_get(id)
    return Game.instances[tonumber(id)]
end

function Game.keyboard_check(_key)
    return false -- Input mapping is not implemented in this first test build.
end

function Game.scene_name()
    return Game.current_scene
end

function instance_create(object_name, x, y)
    return Game.instance_create(object_name, x, y)
end

function keyboard_check(key)
    return Game.keyboard_check(key)
end

function show_debug_message(message)
    Game.log(message)
end

function print(...)
    local parts = {}
    for index = 1, select("#", ...) do
        parts[index] = tostring(select(index, ...))
    end
    Game.log(table.concat(parts, " "))
end

-- Keep accidental infinite loops from locking the game's UI thread.
local __builddroid_instructions = 0
if debug and debug.sethook then
    debug.sethook(function()
        __builddroid_instructions = __builddroid_instructions + 1
        if __builddroid_instructions > 100 then
            error("BuildDroid Lua instruction budget exceeded")
        end
    end, "", 10000)
end
java = nil
luajava = nil
io = nil
os = nil
package = nil
debug = nil
require = nil
dofile = nil
loadfile = nil
loadstring = nil
"""


    private val contractTest = """package com.nicelytinned.game

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class GameApiContractTest {
    @Test
    fun starterApiDeclaresTheSmokeTestFunctions() {
        val api = File("src/main/assets/game-api.lua").readText()
        assertTrue(api.contains("function Game.log"))
        assertTrue(api.contains("function Game.instance_create"))
        assertTrue(api.contains("function Game.instance_count"))
    }
}
"""

    private val workflow = """name: BuildDroid Android Build

on:
  workflow_dispatch:

permissions:
  contents: read

env:
  GRADLE_OPTS: -Dorg.gradle.daemon=false

jobs:
  build:
    name: Test and build debug APK
    runs-on: ubuntu-latest
    steps:
      - name: Checkout project
        uses: actions/checkout@v7

      - name: Set up Java
        uses: actions/setup-java@v6
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v6
        with:
          gradle-version: '8.13'
          cache-provider: basic

      - name: Run Gradle checks
        run: gradle --no-daemon testDebugUnitTest

      - name: Build debug APK
        run: gradle --no-daemon assembleDebug

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: builddroid-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
          retention-days: 7
"""
}
