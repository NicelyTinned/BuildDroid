package com.nicelytinned.builddroid.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

data class ProjectItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String = "Object",
    val x: Float = 48f,
    val y: Float = 48f,
    val width: Float = 64f,
    val height: Float = 64f,
)

data class BuildDroidProject(
    val name: String = "My Game",
    val script: String = DEFAULT_SCRIPT,
    val items: List<ProjectItem> = listOf(
        ProjectItem(name = "Player", kind = "Object", x = 70f, y = 90f),
        ProjectItem(name = "Coin", kind = "Object", x = 190f, y = 120f, width = 32f, height = 32f),
    ),
) {
    fun repositoryName(): String = name
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "-")
        .trim('-')
        .take(80)
        .ifBlank { "builddroid-project" }

    fun toJson(): JSONObject = JSONObject().apply {
        put("format", "builddroid-project")
        put("formatVersion", 1)
        put("name", name)
        put("script", script)
        put("items", JSONArray().apply {
            items.forEach { item ->
                put(JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("kind", item.kind)
                    put("x", item.x.toDouble())
                    put("y", item.y.toDouble())
                    put("width", item.width.toDouble())
                    put("height", item.height.toDouble())
                })
            }
        })
    }

    companion object {
        const val DEFAULT_SCRIPT = """-- Player: Create Event
speed = 4
health = 100

Game.log("Player ready")

-- A tiny API smoke test
local coinId = Game.instance_create("Coin", 200, 120)
assert(coinId > 0, "instance_create should return an id")
assert(Game.instance_count() == 1, "one instance should exist")
Game.log("Lua API test passed")
"""

        fun fromJson(json: JSONObject): BuildDroidProject {
            val itemArray = json.optJSONArray("items") ?: JSONArray()
            val parsedItems = buildList {
                for (index in 0 until itemArray.length()) {
                    val item = itemArray.optJSONObject(index) ?: continue
                    add(
                        ProjectItem(
                            id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                            name = item.optString("name", "Object"),
                            kind = item.optString("kind", "Object"),
                            x = item.optDouble("x", 48.0).toFloat(),
                            y = item.optDouble("y", 48.0).toFloat(),
                            width = item.optDouble("width", 64.0).toFloat(),
                            height = item.optDouble("height", 64.0).toFloat(),
                        ),
                    )
                }
            }
            return BuildDroidProject(
                name = json.optString("name", "My Game"),
                script = json.optString("script", DEFAULT_SCRIPT),
                items = parsedItems,
            )
        }
    }
}
