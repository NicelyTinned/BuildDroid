package com.nicelytinned.builddroid.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

private fun newId(): String = UUID.randomUUID().toString()

/** Reusable object definition. Instances in scenes reference these by objectId. */
data class GameObjectDefinition(
    val id: String = newId(),
    val name: String,
    val type: String = "Rectangle",
    val defaultWidth: Float = 64f,
    val defaultHeight: Float = 64f,
    val color: String = "#55D6A0",
    val spriteAssetId: String? = null,
    val gravity: Float = 0f,
    val bounce: Float = 0f,
) {
    companion object {
        fun fromJson(json: JSONObject): GameObjectDefinition = parseGameObjectDefinition(json)
    }
}

/** A concrete occurrence of an object in a scene. */
data class ProjectItem(
    val id: String = newId(),
    val objectId: String = "",
    val name: String,
    val kind: String = "Rectangle",
    val x: Float = 48f,
    val y: Float = 48f,
    val width: Float = 64f,
    val height: Float = 64f,
    val rotation: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val depth: Int = 0,
    val visible: Boolean = true,
    val locked: Boolean = false,
    val alpha: Float = 1f,
    val color: String = "#55D6A0",
    val text: String = "",
    val spriteAssetId: String? = null,
    val velocityX: Float = 0f,
    val velocityY: Float = 0f,
    val gravity: Float = 0f,
    val bounce: Float = 0f,
    val collisionEnabled: Boolean = true,
    val variables: Map<String, String> = emptyMap(),
) {
    companion object {
        fun fromJson(json: JSONObject): ProjectItem = parseProjectItem(json)
    }
}

data class GameScene(
    val id: String = newId(),
    val name: String,
    val width: Int = 640,
    val height: Int = 360,
    val background: String = "#111824",
    val instances: List<ProjectItem> = emptyList(),
) {
    companion object {
        fun fromJson(json: JSONObject): GameScene = parseGameScene(json)
    }
}

data class ProjectAsset(
    val id: String = newId(),
    val name: String,
    val fileName: String,
    val relativePath: String,
    val mimeType: String = "application/octet-stream",
    val category: String = "Data",
    val sizeBytes: Long = 0L,
) {
    companion object {
        fun fromJson(json: JSONObject): ProjectAsset = parseProjectAsset(json)
    }
}

data class ScriptDocument(
    val id: String = newId(),
    val name: String,
    val source: String,
    val targetObjectId: String? = null,
    val eventType: String = "Script",
) {
    companion object {
        fun fromJson(json: JSONObject): ScriptDocument = parseScriptDocument(json)
    }
}

data class BuildDroidProject(
    val id: String = newId(),
    val name: String = "My Game",
    val scenes: List<GameScene> = defaultScenes(),
    val activeSceneId: String = "main-scene",
    val objects: List<GameObjectDefinition> = defaultObjects(),
    val assets: List<ProjectAsset> = emptyList(),
    val scripts: List<ScriptDocument> = listOf(
        ScriptDocument(id = "main-script", name = "main.lua", source = DEFAULT_SCRIPT),
        ScriptDocument(
            id = "player-step-event", name = "Player · Step", targetObjectId = "player-object", eventType = "Step",
            source = """if Game.keyboard_check("left") then Game.move(self.id, -180 * dt, 0) end
if Game.keyboard_check("right") then Game.move(self.id, 180 * dt, 0) end
if Game.keyboard_check("up") then Game.move(self.id, 0, -180 * dt) end
if Game.keyboard_check("down") then Game.move(self.id, 0, 180 * dt) end""",
        ),
    ),
    val selectedScriptId: String = "main-script",
    val settings: Map<String, String> = mapOf(
        "orientation" to "landscape",
        "targetFps" to "60",
        "pixelArt" to "false",
    ),
) {
    val currentScene: GameScene
        get() = scenes.firstOrNull { it.id == activeSceneId } ?: scenes.firstOrNull() ?: GameScene(name = "MainScene")

    /** Compatibility view used by the first BuildDroid cloud exporter. */
    val items: List<ProjectItem> get() = currentScene.instances

    /** Compatibility view for the original single-script project format. */
    val script: String get() = scripts.firstOrNull { it.id == selectedScriptId }?.source
        ?: scripts.firstOrNull { it.targetObjectId == null }?.source
        ?: DEFAULT_SCRIPT

    fun repositoryName(): String = name
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "-")
        .trim('-')
        .take(80)
        .ifBlank { "builddroid-project" }

    fun withCurrentScene(transform: (GameScene) -> GameScene): BuildDroidProject = copy(
        scenes = scenes.map { scene -> if (scene.id == activeSceneId) transform(scene) else scene },
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("format", "builddroid-project")
        put("formatVersion", 2)
        put("id", id)
        put("name", name)
        put("activeSceneId", activeSceneId)
        put("selectedScriptId", selectedScriptId)
        put("scenes", JSONArray().apply { scenes.forEach { put(it.toJson()) } })
        put("objects", JSONArray().apply { objects.forEach { put(it.toJson()) } })
        put("assets", JSONArray().apply { assets.forEach { put(it.toJson()) } })
        put("scripts", JSONArray().apply { scripts.forEach { put(it.toJson()) } })
        put("settings", JSONObject(settings))
        // Kept for backwards compatibility with build exporters created for format v1.
        put("script", script)
        put("items", JSONArray().apply { items.forEach { put(it.toJson()) } })
    }

    companion object {
        const val DEFAULT_SCRIPT = """-- BuildDroid · Lua 5.1
Game.log("Hello from BuildDroid!")
Game.log("Scene: " .. Game.scene_name())

-- Try creating an instance at runtime:
-- local id = Game.instance_create("Coin", 260, 140)
-- Game.set_velocity(id, 0, -80)
"""

        private fun defaultObjects(): List<GameObjectDefinition> = listOf(
            GameObjectDefinition(id = "player-object", name = "Player", type = "Rectangle", color = "#55D6A0", defaultWidth = 44f, defaultHeight = 52f),
            GameObjectDefinition(id = "coin-object", name = "Coin", type = "Circle", color = "#F5C451", defaultWidth = 26f, defaultHeight = 26f),
            GameObjectDefinition(id = "platform-object", name = "Platform", type = "Rectangle", color = "#7299C8", defaultWidth = 140f, defaultHeight = 20f),
            GameObjectDefinition(id = "label-object", name = "Title", type = "Text", color = "#EAF0F7", defaultWidth = 240f, defaultHeight = 36f),
        )

        private fun defaultScenes(): List<GameScene> = listOf(
            GameScene(
                id = "main-scene",
                name = "MainScene",
                instances = listOf(
                    ProjectItem(id = "player-instance", objectId = "player-object", name = "Player", kind = "Rectangle", x = 72f, y = 180f, width = 44f, height = 52f, color = "#55D6A0", collisionEnabled = true),
                    ProjectItem(id = "coin-instance", objectId = "coin-object", name = "Coin", kind = "Circle", x = 235f, y = 205f, width = 26f, height = 26f, color = "#F5C451", velocityY = -8f, bounce = 0.75f),
                    ProjectItem(id = "platform-instance", objectId = "platform-object", name = "Floor", kind = "Rectangle", x = 30f, y = 315f, width = 570f, height = 22f, color = "#7299C8", locked = true),
                    ProjectItem(id = "title-instance", objectId = "label-object", name = "Title", kind = "Text", x = 28f, y = 28f, width = 280f, height = 36f, color = "#EAF0F7", text = "BuildDroid Studio"),
                ),
            ),
        )

        fun fromJson(json: JSONObject): BuildDroidProject {
            if (json.optInt("formatVersion", 1) < 2 || !json.has("scenes")) {
                return fromLegacyJson(json)
            }
            val parsedScenes = json.optJSONArray("scenes")?.objectsTyped { GameScene.fromJson(it) }.orEmpty().ifEmpty { defaultScenes() }
            val parsedObjects = json.optJSONArray("objects")?.objectsTyped { GameObjectDefinition.fromJson(it) }.orEmpty().ifEmpty { defaultObjects() }
            val parsedAssets = json.optJSONArray("assets")?.objectsTyped { ProjectAsset.fromJson(it) }.orEmpty()
            val parsedScripts = json.optJSONArray("scripts")?.objectsTyped { ScriptDocument.fromJson(it) }.orEmpty().ifEmpty {
                listOf(ScriptDocument(id = "main-script", name = "main.lua", source = json.optString("script", DEFAULT_SCRIPT)))
            }
            val requestedSceneId = json.optString("activeSceneId")
            val requestedScriptId = json.optString("selectedScriptId")
            val settingsJson = json.optJSONObject("settings") ?: JSONObject()
            val settings = buildMap {
                val keys = settingsJson.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    put(key, settingsJson.optString(key))
                }
            }
            return BuildDroidProject(
                id = json.optString("id").ifBlank { newId() },
                name = json.optString("name", "My Game"),
                scenes = parsedScenes,
                activeSceneId = parsedScenes.firstOrNull { it.id == requestedSceneId }?.id ?: parsedScenes.first().id,
                objects = parsedObjects,
                assets = parsedAssets,
                scripts = parsedScripts,
                selectedScriptId = parsedScripts.firstOrNull { it.id == requestedScriptId }?.id ?: parsedScripts.first().id,
                settings = settings.ifEmpty { mapOf("orientation" to "landscape", "targetFps" to "60", "pixelArt" to "false") },
            )
        }

        private fun fromLegacyJson(json: JSONObject): BuildDroidProject {
            val oldItems = json.optJSONArray("items")?.objectsTyped { ProjectItem.fromJson(it) }.orEmpty()
            val legacyObjectId: (ProjectItem) -> String = { item ->
                item.objectId.ifBlank { "legacy-${item.kind.lowercase()}-${item.name.hashCode()}" }
            }
            val migratedItems = oldItems.map { item -> item.copy(objectId = legacyObjectId(item)) }
            val scene = GameScene(id = "main-scene", name = "MainScene", instances = migratedItems)
            val script = json.optString("script", DEFAULT_SCRIPT)
            return BuildDroidProject(
                id = json.optString("id").ifBlank { newId() },
                name = json.optString("name", "My Game"),
                scenes = listOf(scene),
                activeSceneId = "main-scene",
                objects = (oldItems.map { item ->
                    GameObjectDefinition(
                        id = legacyObjectId(item),
                        name = item.name,
                        type = item.kind,
                        defaultWidth = item.width,
                        defaultHeight = item.height,
                        color = item.color,
                        spriteAssetId = item.spriteAssetId,
                    )
                } + defaultObjects()).distinctBy { it.id },
                scripts = listOf(
                    ScriptDocument(id = "main-script", name = "main.lua", source = script),
                    ScriptDocument(
                        id = "player-step-event", name = "Player · Step", targetObjectId = "player-object", eventType = "Step",
                        source = "if Game.keyboard_check(\"left\") then Game.move(self.id, -180 * dt, 0) end\nif Game.keyboard_check(\"right\") then Game.move(self.id, 180 * dt, 0) end",
                    ),
                ),
                selectedScriptId = "main-script",
            )
        }
    }
}

private fun JSONArray.objects(mapper: (JSONObject) -> Any): List<Any> = buildList {
    for (index in 0 until length()) optJSONObject(index)?.let { add(mapper(it)) }
}

private inline fun <reified T> JSONArray.objectsTyped(noinline mapper: (JSONObject) -> T): List<T> = buildList {
    for (index in 0 until length()) optJSONObject(index)?.let { add(mapper(it)) }
}

private fun ProjectItem.toJson() = JSONObject().apply {
    put("id", id); put("objectId", objectId); put("name", name); put("kind", kind)
    put("x", x.toDouble()); put("y", y.toDouble()); put("width", width.toDouble()); put("height", height.toDouble())
    put("rotation", rotation.toDouble()); put("scaleX", scaleX.toDouble()); put("scaleY", scaleY.toDouble()); put("depth", depth)
    put("visible", visible); put("locked", locked); put("alpha", alpha.toDouble()); put("color", color); put("text", text)
    put("spriteAssetId", spriteAssetId); put("velocityX", velocityX.toDouble()); put("velocityY", velocityY.toDouble())
    put("gravity", gravity.toDouble()); put("bounce", bounce.toDouble()); put("collisionEnabled", collisionEnabled)
    put("variables", JSONObject(variables))
}

private fun GameScene.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("width", width); put("height", height); put("background", background)
    put("instances", JSONArray().apply { instances.forEach { put(it.toJson()) } })
}

private fun GameObjectDefinition.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("type", type); put("defaultWidth", defaultWidth); put("defaultHeight", defaultHeight)
    put("color", color); put("spriteAssetId", spriteAssetId); put("gravity", gravity); put("bounce", bounce)
}

private fun ProjectAsset.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("fileName", fileName); put("relativePath", relativePath)
    put("mimeType", mimeType); put("category", category); put("sizeBytes", sizeBytes)
}

private fun ScriptDocument.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("source", source); put("targetObjectId", targetObjectId); put("eventType", eventType)
}

private fun parseProjectItem(json: JSONObject): ProjectItem = ProjectItem(
    id = json.optString("id").ifBlank { newId() },
    objectId = json.optString("objectId"),
    name = json.optString("name", "Object"),
    kind = json.optString("kind", "Rectangle"),
    x = json.optDouble("x", 48.0).toFloat(), y = json.optDouble("y", 48.0).toFloat(),
    width = json.optDouble("width", 64.0).toFloat(), height = json.optDouble("height", 64.0).toFloat(),
    rotation = json.optDouble("rotation", 0.0).toFloat(), scaleX = json.optDouble("scaleX", 1.0).toFloat(), scaleY = json.optDouble("scaleY", 1.0).toFloat(),
    depth = json.optInt("depth", 0), visible = json.optBoolean("visible", true), locked = json.optBoolean("locked", false),
    alpha = json.optDouble("alpha", 1.0).toFloat(), color = json.optString("color", "#55D6A0"), text = json.optString("text"),
    spriteAssetId = json.optString("spriteAssetId").takeIf { it.isNotBlank() },
    velocityX = json.optDouble("velocityX", 0.0).toFloat(), velocityY = json.optDouble("velocityY", 0.0).toFloat(),
    gravity = json.optDouble("gravity", 0.0).toFloat(), bounce = json.optDouble("bounce", 0.0).toFloat(),
    collisionEnabled = json.optBoolean("collisionEnabled", true),
    variables = json.optJSONObject("variables")?.let { obj -> buildMap { val keys = obj.keys(); while (keys.hasNext()) { val key = keys.next(); put(key, obj.optString(key)) } } }.orEmpty(),
)

private fun parseGameScene(json: JSONObject): GameScene = GameScene(
    id = json.optString("id").ifBlank { newId() }, name = json.optString("name", "Scene"),
    width = json.optInt("width", 640).coerceIn(64, 8192), height = json.optInt("height", 360).coerceIn(64, 8192),
    background = json.optString("background", "#111824"),
    instances = json.optJSONArray("instances")?.objectsTyped { ProjectItem.fromJson(it) }.orEmpty(),
)

private fun parseGameObjectDefinition(json: JSONObject): GameObjectDefinition = GameObjectDefinition(
    id = json.optString("id").ifBlank { newId() }, name = json.optString("name", "Object"), type = json.optString("type", "Rectangle"),
    defaultWidth = json.optDouble("defaultWidth", 64.0).toFloat(), defaultHeight = json.optDouble("defaultHeight", 64.0).toFloat(),
    color = json.optString("color", "#55D6A0"), spriteAssetId = json.optString("spriteAssetId").takeIf { it.isNotBlank() },
    gravity = json.optDouble("gravity", 0.0).toFloat(), bounce = json.optDouble("bounce", 0.0).toFloat(),
)

private fun parseProjectAsset(json: JSONObject): ProjectAsset = ProjectAsset(
    id = json.optString("id").ifBlank { newId() }, name = json.optString("name", "Asset"), fileName = json.optString("fileName", "asset.bin"),
    relativePath = json.optString("relativePath", "assets/asset.bin"), mimeType = json.optString("mimeType", "application/octet-stream"),
    category = json.optString("category", "Data"), sizeBytes = json.optLong("sizeBytes", 0L),
)

private fun parseScriptDocument(json: JSONObject): ScriptDocument = ScriptDocument(
    id = json.optString("id").ifBlank { newId() }, name = json.optString("name", "script.lua"), source = json.optString("source"),
    targetObjectId = json.optString("targetObjectId").takeIf { it.isNotBlank() }, eventType = json.optString("eventType", "Script"),
)
