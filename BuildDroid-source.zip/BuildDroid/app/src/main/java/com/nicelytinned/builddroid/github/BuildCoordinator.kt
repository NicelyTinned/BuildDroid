package com.nicelytinned.builddroid.github

import android.content.Context
import com.nicelytinned.builddroid.lua.LuaEngine
import com.nicelytinned.builddroid.model.BuildDroidProject
import com.nicelytinned.builddroid.storage.ProjectStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class BuildCoordinator(context: Context) {
    private val appContext = context.applicationContext

    data class BuildResult(
        val owner: String,
        val repository: String,
        val branch: String,
        val runId: Long,
        val apk: File,
        val luaLog: String,
    )

    suspend fun build(
        project: BuildDroidProject,
        token: String,
        onProgress: (String) -> Unit,
    ): BuildResult {
        onProgress("Running Lua 5.1 preflight tests…")
        val testResult = withContext(Dispatchers.Default) {
            LuaEngine.validateProject(project)
        }
        onProgress("Lua tests passed: ${testResult.instanceCount} instance(s) in ${testResult.sceneName}.")

        val binaryAssets = withContext(Dispatchers.IO) {
            LinkedHashMap<String, ByteArray>().apply {
                project.assets.forEach { asset ->
                    val file = ProjectStorage.assetFile(appContext, project, asset)
                    if (file != null) {
                        require(file.length() <= 20L * 1024L * 1024L) { "${asset.name} is larger than the 20 MB GitHub Contents API limit used by this build." }
                        put("app/src/main/assets/${asset.relativePath}", file.readBytes())
                    }
                }
            }
        }
        val github = GitHubApi(token, appContext)
        val (owner, branch) = github.publishProject(
            project = project,
            files = AndroidProjectTemplate.files(project),
            onProgress = onProgress,
            binaryFiles = binaryAssets,
        )
        val repository = project.repositoryName()
        val runId = github.dispatchAndWait(owner, repository, branch, onProgress)
        onProgress("Build succeeded. Downloading APK artifact…")
        val apk = github.downloadApk(owner, repository, runId)
        return BuildResult(owner, repository, branch, runId, apk, testResult.log)
    }
}
