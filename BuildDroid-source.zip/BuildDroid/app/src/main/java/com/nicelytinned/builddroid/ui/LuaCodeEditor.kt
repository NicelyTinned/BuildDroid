package com.nicelytinned.builddroid.ui

import android.graphics.Typeface
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val EditorBg = Color(0xFF0B1017)
private val GutterBg = Color(0xFF111923)
private val CodeText = Color(0xFFD8E2EE)
private val KeywordColor = Color(0xFFC792EA)
private val FunctionColor = Color(0xFF82AAFF)
private val StringColor = Color(0xFFC3E88D)
private val NumberColor = Color(0xFFF78C6C)
private val CommentColor = Color(0xFF66788A)
private val OperatorColor = Color(0xFF89DDFF)

/**
 * Uses a previously cached JetBrains Mono font when available. Never performs network I/O
 * while opening the editor: a missing font falls back immediately to Android monospace.
 */
@Composable
fun rememberBuildDroidCodeFont(): FontFamily {
    val context = LocalContext.current.applicationContext
    var family by remember { mutableStateOf<FontFamily>(FontFamily.Monospace) }
    LaunchedEffect(context) {
        val cached = withContext(Dispatchers.IO) {
            runCatching {
                val file = File(context.filesDir, "fonts/jetbrains-mono-variable.ttf")
                if (!file.isFile || file.length() !in 20_000L..(12L * 1024L * 1024L)) return@runCatching null
                FontFamily(Typeface.createFromFile(file))
            }.getOrNull()
        }
        if (cached != null) family = cached
    }
    return family
}

@Composable
fun LuaCodeEditor(
    source: String,
    onSourceChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val fontFamily = rememberBuildDroidCodeFont()
    val lineCountKey = if (source.length > 100_000) -1 else source.count { it == '\n' } + 1
    val lineNumbers = remember(lineCountKey) {
        // Avoid scanning or allocating a giant gutter for generated/minified files.
        if (lineCountKey < 0 || lineCountKey >= 8_000) "⋮"
        else (1..lineCountKey).joinToString("\n") { it.toString() }
    }
    val highlighter = remember { LuaSyntaxHighlight() }
    Row(
        modifier = modifier
            .background(EditorBg, RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF263242), RoundedCornerShape(6.dp)),
    ) {
        BasicText(
            text = lineNumbers,
            modifier = Modifier
                .background(GutterBg, RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp))
                .padding(horizontal = 10.dp, vertical = 12.dp),
            style = TextStyle(color = Color(0xFF566579), fontFamily = fontFamily, fontSize = 12.sp, lineHeight = 20.sp),
        )
        Box(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 8.dp, vertical = 8.dp)) {
            BasicTextField(
                value = source,
                onValueChange = onSourceChange,
                modifier = Modifier.fillMaxSize(),
                textStyle = TextStyle(
                    color = CodeText,
                    fontFamily = fontFamily,
                    fontSize = 12.sp,
                    lineHeight = 20.sp,
                ),
                visualTransformation = highlighter,
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Color(0xFF55D6A0)),
                maxLines = Int.MAX_VALUE,
            )
        }
    }
}

/** Cached, allocation-light Lua highlighting. Large files deliberately use plain text. */
private class LuaSyntaxHighlight : VisualTransformation {
    private val keywords = setOf(
        "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in",
        "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while", "continue",
    )
    private val globals = setOf(
        "assert", "error", "ipairs", "pairs", "next", "pcall", "select", "tonumber", "tostring", "type", "xpcall",
    )
    private var cachedSource: String? = null
    private var cachedResult: TransformedText? = null

    override fun filter(text: AnnotatedString): TransformedText {
        val source = text.text
        if (source === cachedSource || source == cachedSource) return cachedResult ?: TransformedText(text, OffsetMapping.Identity)
        // Compose re-runs visual transformations during editing. Skip tokenization for huge files.
        if (source.length > MAX_HIGHLIGHT_CHARS) {
            cachedSource = source
            cachedResult = TransformedText(text, OffsetMapping.Identity)
            return cachedResult!!
        }

        val builder = AnnotatedString.Builder(source)
        var index = 0
        while (index < source.length) {
            val start = index
            val color: Color? = when {
                source[index] == '-' && index + 1 < source.length && source[index + 1] == '-' -> {
                    index += 2
                    while (index < source.length && source[index] != '\n') index++
                    CommentColor
                }
                source[index] == '\'' || source[index] == '"' -> {
                    val quote = source[index++]
                    while (index < source.length) {
                        if (source[index] == '\\' && index + 1 < source.length) index += 2
                        else if (source[index++] == quote) break
                    }
                    StringColor
                }
                source[index].isDigit() -> {
                    index++
                    while (index < source.length && (source[index].isDigit() || source[index] == '.')) index++
                    NumberColor
                }
                source[index].isLetter() || source[index] == '_' -> {
                    index++
                    while (index < source.length && (source[index].isLetterOrDigit() || source[index] == '_')) index++
                    val word = source.substring(start, index)
                    when {
                        word in keywords -> KeywordColor
                        word in globals -> FunctionColor
                        word.firstOrNull()?.isUpperCase() == true -> Color(0xFFFFCB6B)
                        else -> null
                    }
                }
                else -> {
                    val char = source[index++]
                    if (char in "+-*/%=<>~^#(){}[];:,." ) OperatorColor else null
                }
            }
            if (color != null && index > start) builder.addStyle(SpanStyle(color = color), start, index)
        }
        return TransformedText(builder.toAnnotatedString(), OffsetMapping.Identity).also {
            cachedSource = source
            cachedResult = it
        }
    }

    private companion object {
        const val MAX_HIGHLIGHT_CHARS = 48_000
    }
}
