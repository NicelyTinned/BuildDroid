package com.nicelytinned.builddroid.ui

import android.content.Context
import android.graphics.Typeface
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

private val EditorBg = Color(0xFF0B1017)
private val GutterBg = Color(0xFF111923)
private val CodeText = Color(0xFFD8E2EE)
private val KeywordColor = Color(0xFFC792EA)
private val FunctionColor = Color(0xFF82AAFF)
private val StringColor = Color(0xFFC3E88D)
private val NumberColor = Color(0xFFF78C6C)
private val CommentColor = Color(0xFF66788A)
private val OperatorColor = Color(0xFF89DDFF)

/** Downloads JetBrains Mono into app-private cache; editor falls back to system monospace offline. */
@Composable
fun rememberBuildDroidCodeFont(): FontFamily {
    val context = LocalContext.current
    var family by remember { mutableStateOf<FontFamily>(FontFamily.Monospace) }
    LaunchedEffect(Unit) {
        family = withContext(Dispatchers.IO) { loadJetBrainsMono(context) } ?: FontFamily.Monospace
    }
    return family
}

private fun loadJetBrainsMono(context: Context): FontFamily? = runCatching {
    val file = File(context.filesDir, "fonts/jetbrains-mono-variable.ttf")
    if (!file.isFile || file.length() < 20_000L) {
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, "jetbrains-mono.tmp")
        val request = Request.Builder()
            .url("https://raw.githubusercontent.com/google/fonts/main/ofl/jetbrainsmono/JetBrainsMono%5Bwght%5D.ttf")
            .header("User-Agent", "BuildDroid-NicelyTinned")
            .build()
        OkHttpClient.Builder().connectTimeout(12, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
            .newCall(request).execute().use { response ->
                check(response.isSuccessful) { "JetBrains Mono download failed" }
                val body = response.body ?: error("Empty font response")
                check(body.contentLength() <= 12L * 1024L * 1024L || body.contentLength() == -1L) { "Unexpected font size" }
                body.byteStream().use { input -> temp.outputStream().use { output ->
                    val buffer = ByteArray(16 * 1024)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        check(total <= 12L * 1024L * 1024L) { "Font file too large" }
                        output.write(buffer, 0, count)
                    }
                } }
            }
        if (file.exists()) file.delete()
        check(temp.renameTo(file)) { "Could not save font cache" }
    }
    FontFamily(Typeface.createFromFile(file))
}.getOrNull()

@Composable
fun LuaCodeEditor(
    source: String,
    onSourceChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val fontFamily = rememberBuildDroidCodeFont()
    val lines = remember(source.count { it == '\n' }) { (1..(source.count { it == '\n' } + 1)).joinToString("\n") }
    Row(
        modifier = modifier
            .background(EditorBg, RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF263242), RoundedCornerShape(12.dp)),
    ) {
        BasicText(
            text = lines,
            modifier = Modifier
                .background(GutterBg, RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp))
                .padding(horizontal = 10.dp, vertical = 12.dp),
            style = TextStyle(color = Color(0xFF566579), fontFamily = fontFamily, fontSize = 12.sp, lineHeight = 20.sp),
        )
        Box(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 8.dp, vertical = 8.dp)) {
            BasicTextField(
                value = source,
                onValueChange = onSourceChange,
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                textStyle = TextStyle(
                    color = CodeText,
                    fontFamily = fontFamily,
                    fontSize = 12.sp,
                    lineHeight = 20.sp,
                ),
                visualTransformation = LuaSyntaxHighlight,
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Color(0xFF55D6A0)),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize()) { inner() }
                },
            )
        }
    }
}

private object LuaSyntaxHighlight : VisualTransformation {
    private val keywords = setOf(
        "and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in",
        "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while",
    )
    private val globals = setOf("assert", "error", "ipairs", "pairs", "next", "pcall", "select", "tonumber", "tostring", "type", "xpcall")

    override fun filter(text: AnnotatedString): TransformedText {
        val source = text.text
        val highlighted = buildAnnotatedString {
            var index = 0
            while (index < source.length) {
                val start = index
                val char = source[index]
                val color = when {
                    char == '-' && index + 1 < source.length && source[index + 1] == '-' -> {
                        index += 2
                        while (index < source.length && source[index] != '\n') index++
                        CommentColor
                    }
                    char == '\'' || char == '"' -> {
                        val quote = char
                        index++
                        while (index < source.length) {
                            if (source[index] == '\\' && index + 1 < source.length) index += 2
                            else if (source[index++] == quote) break
                        }
                        StringColor
                    }
                    char.isDigit() -> {
                        index++
                        while (index < source.length && (source[index].isDigit() || source[index] == '.')) index++
                        NumberColor
                    }
                    char.isLetter() || char == '_' -> {
                        index++
                        while (index < source.length && (source[index].isLetterOrDigit() || source[index] == '_')) index++
                        val word = source.substring(start, index)
                        when {
                            word in keywords -> KeywordColor
                            word in globals -> FunctionColor
                            word.firstOrNull()?.isUpperCase() == true -> Color(0xFFFFCB6B)
                            else -> CodeText
                        }
                    }
                    else -> {
                        index++
                        if (char in "+-*/%=<>~^#(){}[];:,." ) OperatorColor else CodeText
                    }
                }
                addStyle(SpanStyle(color = color), start, index)
            }
        }
        return TransformedText(highlighted, OffsetMapping.Identity)
    }
}
