package com.nicelytinned.builddroid.github

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Stores a GitHub token encrypted with a key held by Android Keystore. */
class GitHubTokenStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        "builddroid_secure_settings",
        Context.MODE_PRIVATE,
    )

    fun save(token: String) {
        require(token.isNotBlank()) { "Token cannot be empty." }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + encrypted
        check(preferences.edit().putString(TOKEN_KEY, Base64.encodeToString(combined, Base64.NO_WRAP)).commit()) {
            "Could not save the encrypted token."
        }
    }

    fun read(): String? {
        val encoded = preferences.getString(TOKEN_KEY, null) ?: return null
        return runCatching {
            val combined = Base64.decode(encoded, Base64.NO_WRAP)
            require(combined.size > GCM_IV_BYTES) { "Saved token data is invalid." }
            val iv = combined.copyOfRange(0, GCM_IV_BYTES)
            val encrypted = combined.copyOfRange(GCM_IV_BYTES, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.doFinal(encrypted).toString(Charsets.UTF_8)
        }.getOrElse {
            // A missing/invalid Keystore key means this credential cannot be recovered.
            preferences.edit().remove(TOKEN_KEY).apply()
            null
        }
    }

    fun clear() {
        preferences.edit().remove(TOKEN_KEY).apply()
    }

    fun hasToken(): Boolean = preferences.contains(TOKEN_KEY)

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "nicelytinned.builddroid.github-token"
        const val TOKEN_KEY = "github_token_ciphertext"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val GCM_IV_BYTES = 12
        const val GCM_TAG_BITS = 128
    }
}
