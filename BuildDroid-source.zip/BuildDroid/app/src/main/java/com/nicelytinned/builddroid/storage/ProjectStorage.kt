package com.nicelytinned.builddroid.storage

import android.content.Context
import com.nicelytinned.builddroid.model.BuildDroidProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

object ProjectStorage {
    private fun projectFile(context: Context): File {
        val directory = File(context.filesDir, "projects")
        if (!directory.exists()) directory.mkdirs()
        return File(directory, "current-project.json")
    }

    suspend fun save(context: Context, project: BuildDroidProject) = withContext(Dispatchers.IO) {
        projectFile(context.applicationContext).writeText(project.toJson().toString(2))
    }

    suspend fun load(context: Context): BuildDroidProject? = withContext(Dispatchers.IO) {
        val file = projectFile(context.applicationContext)
        if (!file.exists()) return@withContext null
        runCatching { BuildDroidProject.fromJson(JSONObject(file.readText())) }.getOrNull()
    }
}
