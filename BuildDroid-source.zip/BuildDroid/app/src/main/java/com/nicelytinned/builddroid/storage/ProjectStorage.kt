package com.nicelytinned.builddroid.storage

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.nicelytinned.builddroid.model.BuildDroidProject
import com.nicelytinned.builddroid.model.ProjectAsset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ProjectStorage {
    private const val PROJECT_FILE = "project.json"
    private const val MAX_IMPORT_BYTES = 100L * 1024L * 1024L

    private const val PREFS = "builddroid_projects"
    private const val ACTIVE_PROJECT_KEY = "active_project_id"

    private fun projectsDirectory(context: Context): File = File(context.filesDir, "projects").apply { mkdirs() }

    private fun projectDirectory(context: Context, projectId: String): File {
        require(projectId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) { "Invalid project ID" }
        val projectsRoot = projectsDirectory(context).canonicalFile
        val directory = File(projectsRoot, projectId).canonicalFile
        require(directory.path.startsWith(projectsRoot.path + File.separator)) { "Invalid project directory" }
        return directory.apply { mkdirs() }
    }

    suspend fun save(context: Context, project: BuildDroidProject) = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val root = projectDirectory(appContext, project.id)
        val file = File(root, PROJECT_FILE)
        val temp = File(root, "$PROJECT_FILE.tmp")
        temp.writeText(project.toJson().toString(2), Charsets.UTF_8)
        if (file.exists() && !file.delete()) error("Could not replace the project file")
        if (!temp.renameTo(file)) error("Could not finalize the project save")
        appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ACTIVE_PROJECT_KEY, project.id).apply()
    }

    suspend fun load(context: Context): BuildDroidProject? = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val activeId = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ACTIVE_PROJECT_KEY, null)
        if (activeId != null) {
            val activeFile = runCatching { File(projectDirectory(appContext, activeId), PROJECT_FILE) }.getOrNull()
            if (activeFile?.isFile == true) {
                runCatching { BuildDroidProject.fromJson(JSONObject(activeFile.readText(Charsets.UTF_8))) }.getOrNull()?.let { return@withContext it }
            }
        }
        val root = projectsDirectory(appContext)
        root.listFiles()?.asSequence()?.filter { it.isDirectory }?.mapNotNull { directory ->
            runCatching {
                val file = File(directory, PROJECT_FILE)
                if (file.isFile) BuildDroidProject.fromJson(JSONObject(file.readText(Charsets.UTF_8))) else null
            }.getOrNull()
        }?.maxByOrNull { project -> File(File(root, project.id), PROJECT_FILE).lastModified() }
    }

    suspend fun load(context: Context, projectId: String): BuildDroidProject? = withContext(Dispatchers.IO) {
        val file = File(projectDirectory(context.applicationContext, projectId), PROJECT_FILE)
        if (!file.isFile) return@withContext null
        runCatching { BuildDroidProject.fromJson(JSONObject(file.readText(Charsets.UTF_8))) }.getOrNull()
    }

    suspend fun list(context: Context): List<BuildDroidProject> = withContext(Dispatchers.IO) {
        projectsDirectory(context.applicationContext).listFiles()?.asSequence()
            ?.filter { it.isDirectory }
            ?.mapNotNull { directory ->
                runCatching {
                    val file = File(directory, PROJECT_FILE)
                    if (file.isFile) BuildDroidProject.fromJson(JSONObject(file.readText(Charsets.UTF_8))) else null
                }.getOrNull()
            }
            ?.sortedBy { it.name.lowercase() }
            ?.toList().orEmpty()
    }

    suspend fun delete(context: Context, projectId: String) = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val deleted = projectDirectory(appContext, projectId).deleteRecursively()
        val preferences = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (preferences.getString(ACTIVE_PROJECT_KEY, null) == projectId) preferences.edit().remove(ACTIVE_PROJECT_KEY).apply()
        deleted
    }

    fun assetFile(context: Context, project: BuildDroidProject, asset: ProjectAsset): File? {
        val root = projectDirectory(context.applicationContext, project.id).canonicalFile
        val file = File(root, asset.relativePath).canonicalFile
        return file.takeIf { it.path.startsWith(root.path + File.separator) && it.isFile }
    }

    suspend fun importAsset(context: Context, project: BuildDroidProject, uri: Uri): ProjectAsset = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val resolver = appContext.contentResolver
        val displayName = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }?.takeIf { it.isNotBlank() } ?: "imported-file"
        val mimeType = resolver.getType(uri) ?: "application/octet-stream"
        val category = when {
            displayName.endsWith(".lua", true) -> "Script"
            mimeType.startsWith("image/") -> "Image"
            mimeType.startsWith("audio/") -> "Audio"
            mimeType.startsWith("video/") -> "Video"
            mimeType.startsWith("font/") || displayName.endsWith(".ttf", true) || displayName.endsWith(".otf", true) -> "Font"
            displayName.endsWith(".json", true) || displayName.endsWith(".csv", true) || displayName.endsWith(".txt", true) || displayName.endsWith(".xml", true) -> "Text/Data"
            else -> "Data"
        }
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]+"), "_").take(96).ifBlank { "asset" }
        val root = projectDirectory(appContext, project.id)
        val assetDirectory = File(root, "assets").apply { mkdirs() }
        val uniqueFileName = "${UUID.randomUUID().toString().take(8)}_$safeName"
        val destination = File(assetDirectory, uniqueFileName)
        try {
            resolver.openInputStream(uri)?.use { input -> destination.outputStream().buffered().use { output ->
                val buffer = ByteArray(32 * 1024)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= MAX_IMPORT_BYTES) { "Imported file is larger than 100 MB" }
                    output.write(buffer, 0, count)
                }
            } } ?: error("Unable to open the selected file")
        } catch (error: Throwable) {
            destination.delete()
            throw error
        }
        ProjectAsset(
            name = displayName,
            fileName = uniqueFileName,
            relativePath = "assets/$uniqueFileName",
            mimeType = mimeType,
            category = category,
            sizeBytes = destination.length(),
        )
    }

    suspend fun readAssetText(context: Context, project: BuildDroidProject, asset: ProjectAsset, maxBytes: Long = 2L * 1024L * 1024L): String = withContext(Dispatchers.IO) {
        val file = assetFile(context, project, asset) ?: error("Imported file is missing")
        require(file.length() <= maxBytes) { "${asset.name} is larger than the ${maxBytes / (1024 * 1024)} MB text import limit" }
        file.readText(Charsets.UTF_8)
    }

    suspend fun deleteAssetFile(context: Context, project: BuildDroidProject, asset: ProjectAsset) = withContext(Dispatchers.IO) {
        assetFile(context, project, asset)?.delete()
    }

    suspend fun exportTo(context: Context, project: BuildDroidProject, uri: Uri) = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val root = projectDirectory(appContext, project.id)
        save(appContext, project)
        appContext.contentResolver.openOutputStream(uri, "wt")?.use { raw ->
            ZipOutputStream(raw.buffered()).use { zip ->
                val projectFile = File(root, PROJECT_FILE)
                zip.putNextEntry(ZipEntry(PROJECT_FILE))
                FileInputStream(projectFile).use { it.copyTo(zip) }
                zip.closeEntry()
                val assetsRoot = File(root, "assets")
                if (assetsRoot.isDirectory) {
                    assetsRoot.walkTopDown().filter { it.isFile }.forEach { file ->
                        val relative = "assets/${file.relativeTo(assetsRoot).invariantSeparatorsPath}"
                        zip.putNextEntry(ZipEntry(relative))
                        FileInputStream(file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
        } ?: error("Unable to create the selected export file")
    }

    suspend fun importProject(context: Context, uri: Uri): BuildDroidProject = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val importedId = UUID.randomUUID().toString()
        val root = projectDirectory(appContext, importedId)
        var totalBytes = 0L
        var entries = 0
        try {
            appContext.contentResolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(BufferedInputStream(raw)).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        entries++
                        require(entries <= 1000) { "The project archive contains too many files" }
                        val normalized = entry.name.replace('\\', '/').trimEnd('/')
                        require(normalized.isNotBlank() && !normalized.startsWith('/') && normalized.split('/').none { it == ".." || it.isBlank() }) {
                            "The project archive contains an invalid path"
                        }
                        val destination = File(root, normalized).canonicalFile
                        require(destination.path.startsWith(root.canonicalPath + File.separator)) { "Invalid archive path" }
                        if (entry.isDirectory) {
                            destination.mkdirs()
                        } else {
                            destination.parentFile?.mkdirs()
                            FileOutputStream(destination).use { output ->
                                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                                while (true) {
                                    val read = zip.read(buffer)
                                    if (read <= 0) break
                                    totalBytes += read
                                    require(totalBytes <= MAX_IMPORT_BYTES) { "Project archive is larger than 100 MB" }
                                    output.write(buffer, 0, read)
                                }
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: error("Unable to read the selected project archive")
            val projectFile = File(root, PROJECT_FILE)
            require(projectFile.isFile) { "This ZIP does not contain a BuildDroid project.json" }
            val imported = BuildDroidProject.fromJson(JSONObject(projectFile.readText(Charsets.UTF_8))).copy(id = importedId)
            projectFile.writeText(imported.toJson().toString(2), Charsets.UTF_8)
            imported
        } catch (error: Throwable) {
            root.deleteRecursively()
            throw error
        }
    }
}
