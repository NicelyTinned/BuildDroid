package com.nicelytinned.builddroid.lua

/**
 * Adds `continue` to the Lua 5.1 dialect used by BuildDroid.
 *
 * Lua 5.1 has no jump instruction, so loops that contain `continue` get a tiny
 * repeat/until wrapper. `break` statements targeting that loop are translated
 * through a flag so their normal meaning is preserved. Strings and comments are
 * tokenized before rewriting, so words such as "continue" in text are untouched.
 *
 * `continue` in repeat/until loops is rejected because Lua exposes locals from a
 * repeat body to its until-condition; wrapping that body would change scope.
 */
internal object LuaContinuePreprocessor {
    private data class Token(val value: String, val start: Int, val end: Int)

    private data class Block(
        val kind: String,
        val tokenIndex: Int,
        var bodyStartIndex: Int = -1,
        var closeIndex: Int = -1,
        var hasContinue: Boolean = false,
        var flagName: String = "",
    )

    fun transform(source: String): String {
        val tokens = tokenize(source)
        if (tokens.none { it.value == "continue" }) return source

        val blocks = mutableListOf<Block>()
        val loops = mutableListOf<Block>()
        val continueTargets = mutableMapOf<Int, Block>()
        val breakTargets = mutableMapOf<Int, Block>()

        fun activeLoop(): Block? {
            val lastFunction = blocks.indexOfLast { it.kind == "function" }
            return blocks.asSequence().drop(lastFunction + 1)
                .lastOrNull { it.kind == "while" || it.kind == "for" || it.kind == "repeat" }
        }

        tokens.forEachIndexed { index, token ->
            when (token.value) {
                "continue" -> {
                    val isStatement = isContinueStatement(tokens, source, index)
                    val loop = if (isStatement) activeLoop() else null
                    if (loop != null) {
                        require(loop.kind != "repeat") {
                            "BuildDroid: continue inside repeat/until is not supported in Lua 5.1; use a while or for loop."
                        }
                        loop.hasContinue = true
                        continueTargets[index] = loop
                    }
                }
                "break" -> activeLoop()?.let { breakTargets[index] = it }
            }

            when (token.value) {
                "function" -> blocks += Block("function", index)
                "if" -> blocks += Block("if", index)
                "while", "for" -> {
                    val loop = Block(token.value, index)
                    blocks += loop
                    loops += loop
                }
                "repeat" -> {
                    val loop = Block("repeat", index, bodyStartIndex = index + 1)
                    blocks += loop
                    loops += loop
                }
                "do" -> {
                    val lastFunction = blocks.indexOfLast { it.kind == "function" }
                    val pendingLoop = blocks.subList(lastFunction + 1, blocks.size)
                        .lastOrNull { (it.kind == "while" || it.kind == "for") && it.bodyStartIndex < 0 }
                    if (pendingLoop != null) {
                        pendingLoop.bodyStartIndex = index + 1
                    } else {
                        blocks += Block("do", index)
                    }
                }
                "end" -> {
                    val block = blocks.lastOrNull()
                    if (block != null && block.kind != "repeat") {
                        blocks.removeAt(blocks.lastIndex)
                        block.closeIndex = index
                    }
                }
                "until" -> {
                    val repeatIndex = blocks.indexOfLast { it.kind == "repeat" }
                    if (repeatIndex >= 0) {
                        val block = blocks.removeAt(repeatIndex)
                        block.closeIndex = index
                    }
                }
            }
        }

        val changedLoops = loops.filter { it.hasContinue }
        if (changedLoops.isEmpty()) return source

        val existingNames = tokens.filter { it.value.firstOrNull()?.let { c -> c == '_' || c.isLetter() } == true }
            .map { it.value }.toSet()
        changedLoops.forEachIndexed { index, loop ->
            var candidate = "__builddroid_continue_${index + 1}"
            while (candidate in existingNames) candidate = "_${candidate}"
            loop.flagName = candidate
            require(loop.bodyStartIndex >= 0 && loop.closeIndex >= 0) {
                "BuildDroid: could not parse a loop containing continue. Check the loop's do/end structure."
            }
        }

        val edits = mutableListOf<Edit>()
        changedLoops.forEach { loop ->
            val opener = tokens[loop.bodyStartIndex - 1]
            val closer = tokens[loop.closeIndex]
            edits += Edit(opener.end, "\nlocal ${loop.flagName} = false\nrepeat\n")
            edits += Edit(
                closer.start,
                "\nuntil true\nif ${loop.flagName} then break end\n",
            )
        }

        continueTargets.forEach { (index, loop) ->
            if (loop.hasContinue) edits += Edit(tokens[index].start, "break", tokens[index].end)
        }
        breakTargets.forEach { (index, loop) ->
            if (loop.hasContinue) {
                edits += Edit(tokens[index].start, "${loop.flagName} = true; break", tokens[index].end)
            }
        }

        val result = StringBuilder(source)
        edits.sortedWith(compareByDescending<Edit> { it.start }.thenByDescending { it.end }).forEach { edit ->
            result.replace(edit.start, edit.end, edit.replacement)
        }
        return result.toString()
    }

    private data class Edit(val start: Int, val replacement: String, val end: Int = start)

    private fun isContinueStatement(tokens: List<Token>, source: String, index: Int): Boolean {
        val previous = tokens.getOrNull(index - 1)
        val next = tokens.getOrNull(index + 1)
        val gapBefore = previous?.let { source.substring(it.end, tokens[index].start) }.orEmpty()
        val startsStatement = previous == null || previous.value in setOf("do", "then", "else", "elseif", "repeat") ||
            gapBefore.contains(';') || gapBefore.contains('\n')
        if (!startsStatement) return false
        val gapAfter = next?.let { source.substring(tokens[index].end, it.start) }
            ?: source.substring(tokens[index].end)
        val trailing = gapAfter.trimStart()
        if (trailing.firstOrNull() in setOf('(', '.', '[', '=', ',', '+', '-', '*', '/', '%', '^', '<', '>', '~', ':')) {
            return false
        }
        return next == null || next.value in setOf("end", "else", "elseif", "until") ||
            gapAfter.contains(';') || gapAfter.contains('\n')
    }

    private fun tokenize(source: String): List<Token> {
        val result = mutableListOf<Token>()
        var index = 0
        while (index < source.length) {
            val char = source[index]
            if (char.isWhitespace()) {
                index++
                continue
            }
            if (char == '-' && source.getOrNull(index + 1) == '-') {
                val longEnd = longBracketEnd(source, index + 2)
                index = longEnd ?: (source.indexOf('\n', index).let { if (it < 0) source.length else it + 1 })
                continue
            }
            if (char == '\'' || char == '"') {
                val quote = char
                index++
                while (index < source.length) {
                    when {
                        source[index] == '\\' -> index = (index + 2).coerceAtMost(source.length)
                        source[index] == quote -> { index++; break }
                        else -> index++
                    }
                }
                continue
            }
            if (char == '[') {
                val longEnd = longBracketEnd(source, index)
                if (longEnd != null) {
                    index = longEnd
                    continue
                }
            }
            if (char == '_' || char.isLetter()) {
                val start = index
                index++
                while (index < source.length && (source[index] == '_' || source[index].isLetterOrDigit())) index++
                result += Token(source.substring(start, index), start, index)
                continue
            }
            index++
        }
        return result
    }

    /** Returns the first position after a Lua long-bracket body, or null. */
    private fun longBracketEnd(source: String, start: Int): Int? {
        if (source.getOrNull(start) != '[') return null
        var cursor = start + 1
        while (source.getOrNull(cursor) == '=') cursor++
        if (source.getOrNull(cursor) != '[') return null
        val equals = source.substring(start + 1, cursor)
        val closing = "]$equals]"
        val closeAt = source.indexOf(closing, cursor + 1)
        return if (closeAt < 0) source.length else closeAt + closing.length
    }
}
