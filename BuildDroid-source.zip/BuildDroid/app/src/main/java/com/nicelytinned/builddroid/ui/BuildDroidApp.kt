package com.nicelytinned.builddroid.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.focusable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import com.nicelytinned.builddroid.github.BuildCoordinator
import com.nicelytinned.builddroid.github.GitHubTokenStore
import com.nicelytinned.builddroid.lua.LuaEngine
import com.nicelytinned.builddroid.lua.LuaGameRuntime
import com.nicelytinned.builddroid.model.BuildDroidProject
import com.nicelytinned.builddroid.model.GameObjectDefinition
import com.nicelytinned.builddroid.model.GameScene
import com.nicelytinned.builddroid.model.ProjectAsset
import com.nicelytinned.builddroid.model.ProjectItem
import com.nicelytinned.builddroid.model.ScriptDocument
import com.nicelytinned.builddroid.storage.ProjectStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.min
import kotlin.math.abs

private val Bg = Color(0xFF0A0F15)
private val Panel = Color(0xFF131C27)
private val Panel2 = Color(0xFF1A2633)
private val Panel3 = Color(0xFF223243)
private val Border = Color(0xFF2B3B4E)
private val Accent = Color(0xFF55D6A0)
private val AccentBlue = Color(0xFF7BB7FF)
private val TextMain = Color(0xFFE8EEF5)
private val TextMuted = Color(0xFF8C9BAE)
private val Warning = Color(0xFFFFC66D)

private enum class EditorTab(val label: String, val glyph: String) {
    EDIT("Preview / Edit", "▧"), EXPLORER("Explorer", "☷"), SCRIPT("Script", "{ }")
}

private data class DrawItem(
    val id: String,
    val objectId: String,
    val name: String,
    val type: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val rotation: Float,
    val depth: Int,
    val color: String,
    val alpha: Float,
    val visible: Boolean,
    val text: String,
    val assetId: String?,
    val locked: Boolean,
)

@Composable
fun BuildDroidApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val playtestFocusRequester = remember { FocusRequester() }
    val tokenStore = remember { GitHubTokenStore(context) }
    val buildCoordinator = remember { BuildCoordinator(context) }
    val engineExecutor = remember { Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "BuildDroid-Engine").apply { isDaemon = true } } }
    val engineDispatcher = remember(engineExecutor) { engineExecutor.asCoroutineDispatcher() }
    val view = LocalView.current
    val window = context.findActivity()?.window

    var project by remember { mutableStateOf(BuildDroidProject()) }
    var projectLibrary by remember { mutableStateOf<List<BuildDroidProject>>(emptyList()) }
    var selectedTab by remember { mutableStateOf(EditorTab.EDIT) }
    var selectedInstanceId by remember { mutableStateOf(project.items.firstOrNull()?.id) }
    var selectedObjectId by remember { mutableStateOf<String?>(null) }
    var selectedAssetId by remember { mutableStateOf<String?>(null) }
    var isPlaytest by remember { mutableStateOf(false) }
    var runtime by remember { mutableStateOf<LuaGameRuntime?>(null) }
    DisposableEffect(isPlaytest, window, view) {
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        if (isPlaytest) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    val latestRuntime by rememberUpdatedState(runtime)
    var runtimeFrame by remember { mutableStateOf<LuaGameRuntime.Frame?>(null) }
    var isFileMenuExpanded by remember { mutableStateOf(false) }
    var showProjectLibrary by remember { mutableStateOf(false) }
    var showProjectDetails by remember { mutableStateOf(false) }
    var showTokenDialog by remember { mutableStateOf(false) }
    var showAddInstance by remember { mutableStateOf(false) }
    var isBuilding by remember { mutableStateOf(false) }
    var tokenDraft by remember { mutableStateOf("") }
    var projectNameDraft by remember { mutableStateOf(project.name) }
    var status by remember { mutableStateOf("Ready · autosave on") }
    var output by remember { mutableStateOf("BuildDroid 2D runtime ready.") }
    var tokenSaved by remember { mutableStateOf(false) }
    var assetImages by remember { mutableStateOf<Map<String, ImageBitmap>>(emptyMap()) }
    var isImporting by remember { mutableStateOf(false) }

    fun stopPlaytest() {
        isPlaytest = false
        val old = runtime
        runtime = null
        runtimeFrame = null
        scope.launch {
            withContext(engineDispatcher) { runCatching { old?.close() } }
            status = "Playtest stopped."
        }
    }

    val assetPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            scope.launch {
                status = "Importing ${uris.size} file(s)…"
                val added = mutableListOf<ProjectAsset>()
                val importedScripts = mutableListOf<ScriptDocument>()
                uris.forEach { uri ->
                    runCatching { ProjectStorage.importAsset(context, project, uri) }
                        .onSuccess { asset ->
                            added += asset
                            if (asset.category == "Script") {
                                runCatching { ProjectStorage.readAssetText(context, project, asset) }
                                    .onSuccess { source -> importedScripts += ScriptDocument(name = asset.name, source = source) }
                                    .onFailure { status = "Script import failed: ${it.message}" }
                            }
                        }
                        .onFailure { status = "Import failed: ${it.message}" }
                }
                if (added.isNotEmpty()) {
                    project = project.copy(assets = project.assets + added, scripts = project.scripts + importedScripts)
                    selectedAssetId = added.first().id
                    if (importedScripts.isNotEmpty()) {
                        project = project.copy(selectedScriptId = importedScripts.first().id)
                        selectedTab = EditorTab.SCRIPT
                    }
                    status = "Imported ${added.size} file(s), ${importedScripts.size} Lua script(s)."
                }
                isImporting = false
            }
        } else isImporting = false
    }
    val projectPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            stopPlaytest()
            runCatching { ProjectStorage.importProject(context, uri) }
                .onSuccess { imported ->
                    project = imported
                    selectedInstanceId = imported.items.firstOrNull()?.id
                    selectedTab = EditorTab.EDIT
                    status = "Imported project ${imported.name}."
                    projectLibrary = ProjectStorage.list(context)
                }
                .onFailure { status = "Project import failed: ${it.message}" }
        }
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) scope.launch {
            status = "Exporting project archive…"
            runCatching { ProjectStorage.exportTo(context, project, uri) }
                .onSuccess { status = "Exported ${project.name}.bdproj.zip" }
                .onFailure { status = "Export failed: ${it.message}" }
        }
    }

    LaunchedEffect(Unit) {
        ProjectStorage.load(context)?.let { loaded ->
            project = loaded
            selectedInstanceId = loaded.items.firstOrNull()?.id
        }
        projectLibrary = ProjectStorage.list(context)
        tokenSaved = tokenStore.hasToken()
    }

    // Debounced autosave keeps edits safe without writing on every keystroke or frame.
    LaunchedEffect(project) {
        delay(850)
        runCatching { ProjectStorage.save(context, project) }
            .onSuccess { status = "Saved · ${project.name}" }
            .onFailure { status = "Autosave failed: ${it.message}" }
    }

    // Decode only images referenced by objects/scenes. Work stays off the UI thread and is capped.
    val referencedSpriteIds = remember(project.objects, project.scenes) {
        (project.objects.mapNotNull { it.spriteAssetId } + project.currentScene.instances.mapNotNull { it.spriteAssetId }).distinct().take(8)
    }
    LaunchedEffect(project.id, project.assets, referencedSpriteIds) {
        assetImages = withContext(Dispatchers.IO) {
            val byId = project.assets.associateBy { it.id }
            referencedSpriteIds.mapNotNull { id ->
                val asset = byId[id]?.takeIf { it.category == "Image" } ?: return@mapNotNull null
                runCatching {
                    val file = ProjectStorage.assetFile(context, project, asset) ?: return@runCatching null
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(file.absolutePath, bounds)
                    val longest = maxOf(bounds.outWidth, bounds.outHeight)
                    var sample = 1
                    while (longest / sample > 512) sample *= 2
                    val options = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                    }
                    val bitmap = BitmapFactory.decodeFile(file.absolutePath, options) ?: return@runCatching null
                    id to bitmap.asImageBitmap()
                }.getOrNull()
            }.toMap()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            val oldRuntime = latestRuntime
            runCatching {
                engineExecutor.execute {
                    runCatching { oldRuntime?.close() }
                    engineDispatcher.close()
                }
            }.onFailure { engineDispatcher.close() }
        }
    }

    LaunchedEffect(isPlaytest, runtime) {
        if (isPlaytest) runCatching { playtestFocusRequester.requestFocus() }
        if (isPlaytest && runtime != null) {
            var previousNanos = 0L
            var lastUiSnapshotNanos = 0L
            while (isPlaytest) {
                val now = androidx.compose.runtime.withFrameNanos { it }
                val delta = if (previousNanos == 0L) 1f / 60f else ((now - previousNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
                previousNanos = now
                val publishFrame = lastUiSnapshotNanos == 0L || now - lastUiSnapshotNanos >= 33_333_333L
                val next = withContext(engineDispatcher) { runtime?.tick(delta, captureFrame = publishFrame) }
                if (next != null && publishFrame) {
                    runtimeFrame = next
                    lastUiSnapshotNanos = now
                }
                if (next?.error != null) {
                    output = "Runtime error: ${next.error}"
                    status = "Playtest stopped after a Lua runtime error."
                    isPlaytest = false
                    val failedRuntime = runtime
                    scope.launch {
                        withContext(engineDispatcher) { runCatching { failedRuntime?.close() } }
                        if (runtime === failedRuntime) runtime = null
                    }
                }
            }
        }
    }

    fun updateInstance(id: String, transform: (ProjectItem) -> ProjectItem) {
        project = project.withCurrentScene { scene ->
            scene.copy(instances = scene.instances.map { if (it.id == id) transform(it) else it })
        }
    }

    fun resizeInstance(id: String, x: Float, y: Float, width: Float, height: Float) {
        val scene = project.currentScene
        updateInstance(id) { item ->
            val scaleX = item.scaleX.coerceAtLeast(0.01f)
            val scaleY = item.scaleY.coerceAtLeast(0.01f)
            item.copy(
                x = x.coerceIn(0f, (scene.width - 1).toFloat()),
                y = y.coerceIn(0f, (scene.height - 1).toFloat()),
                width = (width / scaleX).coerceAtLeast(1f),
                height = (height / scaleY).coerceAtLeast(1f),
            )
        }
    }

    fun addObject(name: String, type: String) {
        val definition = GameObjectDefinition(
            name = name,
            type = type,
            color = when (type) {
                "Circle" -> "#F5C451"
                "Text" -> "#E8EEF5"
                "Button" -> "#55D6A0"
                "Sprite" -> "#7BB7FF"
                else -> "#55D6A0"
            },
            defaultWidth = if (type == "Text") 220f else 64f,
            defaultHeight = if (type == "Text") 34f else 64f,
        )
        project = project.copy(objects = project.objects + definition)
        selectedObjectId = definition.id
        status = "Created object ${definition.name}."
    }

    fun addInstance(objectId: String) {
        val definition = project.objects.firstOrNull { it.id == objectId } ?: return
        val instance = ProjectItem(
            objectId = definition.id,
            name = "${definition.name}${project.items.count { it.objectId == definition.id } + 1}",
            kind = definition.type,
            x = 80f + (project.items.size % 5) * 54f,
            y = 80f + (project.items.size % 4) * 42f,
            width = definition.defaultWidth,
            height = definition.defaultHeight,
            color = definition.color,
            spriteAssetId = definition.spriteAssetId,
            gravity = definition.gravity,
            bounce = definition.bounce,
        )
        project = project.withCurrentScene { it.copy(instances = it.instances + instance) }
        selectedInstanceId = instance.id
        selectedObjectId = null
        selectedTab = EditorTab.EDIT
        status = "Added ${instance.name}."
    }

    fun duplicateSelected() {
        val selected = project.items.firstOrNull { it.id == selectedInstanceId } ?: return
        val copy = selected.copy(id = UUID.randomUUID().toString(), name = "${selected.name} Copy", x = selected.x + 18f, y = selected.y + 18f)
        project = project.withCurrentScene { it.copy(instances = it.instances + copy) }
        selectedInstanceId = copy.id
    }

    fun addScene() {
        val scene = GameScene(name = "Scene${project.scenes.size + 1}")
        project = project.copy(scenes = project.scenes + scene, activeSceneId = scene.id)
        selectedInstanceId = null
        selectedObjectId = null
        isPlaytest = false
        status = "Created ${scene.name}."
    }

    fun addScript(targetObjectId: String? = null, eventType: String = "Script") {
        val targetName = project.objects.firstOrNull { it.id == targetObjectId }?.name
        val label = if (targetObjectId == null) "Script${project.scripts.count { it.targetObjectId == null } + 1}.lua" else "$targetName · $eventType"
        val document = ScriptDocument(
            name = label,
            source = if (eventType == "Step") "-- Runs every frame for each instance.\n-- self.id, self.x, self.y and dt are available.\n" else "-- $label\n",
            targetObjectId = targetObjectId,
            eventType = eventType,
        )
        project = project.copy(scripts = project.scripts + document, selectedScriptId = document.id)
        selectedTab = EditorTab.SCRIPT
        status = "Created $label."
    }

    fun startPlaytest() {
        val snapshot = project
        scope.launch {
            status = "Starting playtest…"
            try {
                val created = withContext(engineDispatcher) {
                    runtime?.close()
                    LuaGameRuntime(snapshot).also { it.snapshot() }
                }
                runtime = created
                runtimeFrame = created.snapshot()
                isPlaytest = true
                selectedTab = EditorTab.EDIT
                output = runtimeFrame?.logs?.takeLast(8)?.joinToString("\n")?.ifBlank { "Playtest running." } ?: "Playtest running."
                status = "Playtest running · display-synced frame loop"
            } catch (error: Throwable) {
                status = "Could not start playtest: ${error.message}"
                output = error.message ?: "Runtime initialization failed."
            }
        }
    }

    fun updateRuntimeKey(key: String, down: Boolean) {
        val current = runtime ?: return
        scope.launch {
            val next = withContext(engineDispatcher) {
                current.setKey(key, down)
                current.snapshot()
            }
            runtimeFrame = next
        }
    }

    fun moveRuntimeItem(id: String, x: Float, y: Float) {
        val current = runtime ?: return
        val runtimeId = id.toIntOrNull() ?: return
        scope.launch {
            val next = withContext(engineDispatcher) {
                current.moveInstance(runtimeId, x, y)
                current.snapshot()
            }
            runtimeFrame = next
        }
    }

    fun updateRuntimePointer(x: Float, y: Float, pressed: Boolean) {
        val current = runtime ?: return
        scope.launch {
            runCatching { withContext(engineDispatcher) { current.setPointer(x, y, pressed) } }
        }
    }

    fun runScriptTest(script: String) {
        scope.launch {
            status = "Running Lua 5.1 tests…"
            val result = runCatching { withContext(Dispatchers.Default) { LuaEngine.runPreflight(script) } }
            result.onSuccess {
                output = it.log.ifBlank { "Lua script completed without log output." }
                status = "Lua test passed · ${it.instanceCount} created · ${it.sceneName}"
            }.onFailure {
                output = it.message ?: "Lua test failed."
                status = "Lua test failed."
            }
        }
    }

    fun startBuild() {
        val token = tokenStore.read()
        if (token.isNullOrBlank()) {
            tokenDraft = ""
            showTokenDialog = true
            status = "Add a GitHub token before starting a cloud build."
            return
        }
        val snapshot = project
        scope.launch {
            isBuilding = true
            status = "Running Lua preflight and preparing GitHub Actions…"
            try {
                val result = buildCoordinator.build(snapshot, token) { message -> status = message }
                status = "APK downloaded · ${result.apk.name}"
                output = "Build succeeded. Saved at:\n${result.apk.absolutePath}\n\n${result.luaLog}"
            } catch (error: Throwable) {
                status = "Build failed: ${error.message ?: error.javaClass.simpleName}"
                output = status
            } finally {
                isBuilding = false
            }
        }
    }

    val selectedInstance = project.items.firstOrNull { it.id == selectedInstanceId }
    val selectedObject = project.objects.firstOrNull { it.id == selectedObjectId }
    val selectedScript = project.scripts.firstOrNull { it.id == project.selectedScriptId } ?: project.scripts.firstOrNull()

    Box(
        Modifier.fillMaxSize().background(Bg)
            .focusRequester(playtestFocusRequester)
            .focusable()
            .onPreviewKeyEvent { event ->
                val direction = when (event.key) {
                    Key.DirectionLeft, Key.A -> "left"
                    Key.DirectionRight, Key.D -> "right"
                    Key.DirectionUp, Key.W -> "up"
                    Key.DirectionDown, Key.S -> "down"
                    else -> null
                }
                if (isPlaytest && direction != null) {
                    updateRuntimeKey(direction, event.type == KeyEventType.KeyDown)
                    true
                } else false
            }
    ) {
        if (isPlaytest) {
            FullscreenPlaytest(
                scene = project.currentScene,
                objectDefinitions = project.objects.associateBy { it.id },
                frame = runtimeFrame,
                images = assetImages,
                onPointer = ::updateRuntimePointer,
                onKey = ::updateRuntimeKey,
                onStop = ::stopPlaytest,
            )
        } else {
        Column(Modifier.fillMaxSize()) {
            TopBar(
                projectName = project.name,
                sceneName = project.currentScene.name,
                isPlaytest = isPlaytest,
                menuExpanded = isFileMenuExpanded,
                onMenuToggle = { isFileMenuExpanded = !isFileMenuExpanded },
                onMenuDismiss = { isFileMenuExpanded = false },
                onSave = {
                    scope.launch {
                        runCatching { ProjectStorage.save(context, project) }
                            .onSuccess { status = "Saved ${project.name}." }
                            .onFailure { status = "Save failed: ${it.message}" }
                    }
                },
                onProjects = {
                    isFileMenuExpanded = false
                    scope.launch { projectLibrary = ProjectStorage.list(context) }
                    showProjectLibrary = true
                },
                onNewProject = {
                    isFileMenuExpanded = false
                    val next = BuildDroidProject(name = "Untitled Game")
                    project = next
                    selectedInstanceId = next.items.firstOrNull()?.id
                    selectedObjectId = null
                    isPlaytest = false
                    status = "Created a new project."
                },
                onImportProject = {
                    isFileMenuExpanded = false
                    projectPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                },
                onExportProject = {
                    isFileMenuExpanded = false
                    exportPicker.launch("${project.name.replace(Regex("[^A-Za-z0-9_-]"), "_")}.bdproj.zip")
                },
                onImportAssets = {
                    isFileMenuExpanded = false
                    isImporting = true
                    assetPicker.launch(arrayOf("*/*"))
                },
                onProjectDetails = {
                    isFileMenuExpanded = false
                    projectNameDraft = project.name
                    showProjectDetails = true
                },
                onToken = {
                    isFileMenuExpanded = false
                    tokenDraft = ""
                    showTokenDialog = true
                },
                onBuild = { isFileMenuExpanded = false; startBuild() },
                isBuilding = isBuilding,
            )

            if (isFileMenuExpanded) {
                FileMenu(
                    onClose = { isFileMenuExpanded = false },
                    onSave = { isFileMenuExpanded = false; scope.launch { ProjectStorage.save(context, project); status = "Saved ${project.name}." } },
                    onProjects = { isFileMenuExpanded = false; scope.launch { projectLibrary = ProjectStorage.list(context) }; showProjectLibrary = true },
                    onNewProject = { isFileMenuExpanded = false; val next = BuildDroidProject(name = "Untitled Game"); project = next; selectedInstanceId = next.items.firstOrNull()?.id; isPlaytest = false },
                    onImportProject = { isFileMenuExpanded = false; projectPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    onExportProject = { isFileMenuExpanded = false; exportPicker.launch("${project.name.replace(Regex("[^A-Za-z0-9_-]"), "_")}.bdproj.zip") },
                    onImportAssets = { isFileMenuExpanded = false; isImporting = true; assetPicker.launch(arrayOf("*/*")) },
                    onProjectDetails = { isFileMenuExpanded = false; projectNameDraft = project.name; showProjectDetails = true },
                    onToken = { isFileMenuExpanded = false; tokenDraft = ""; showTokenDialog = true },
                    onBuild = { isFileMenuExpanded = false; startBuild() },
                )
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (selectedTab) {
                    EditorTab.EDIT -> EditPanel(
                        project = project,
                        selectedInstanceId = selectedInstanceId,
                        selectedInstance = selectedInstance,
                        isPlaytest = isPlaytest,
                        runtimeFrame = runtimeFrame,
                        images = assetImages,
                        onSelectInstance = { selectedInstanceId = it; selectedObjectId = null },
                        onMoveInstance = { id, dx, dy -> updateInstance(id) { item ->
                            item.copy(
                                x = (item.x + dx).coerceIn(0f, (project.currentScene.width - item.width * item.scaleX).coerceAtLeast(0f)),
                                y = (item.y + dy).coerceIn(0f, (project.currentScene.height - item.height * item.scaleY).coerceAtLeast(0f)),
                            )
                        } },
                        onResizeInstance = ::resizeInstance,
                        onMoveRuntime = ::moveRuntimeItem,
                        onPointer = ::updateRuntimePointer,
                        onUpdateInstance = ::updateInstance,
                        onAddInstance = { showAddInstance = true },
                        onAddObject = { addObject("Object${project.objects.size + 1}", "Rectangle") },
                        onAddUi = { addObject("Button${project.objects.size + 1}", "Button"); project.objects.lastOrNull()?.let { addInstance(it.id) } },
                        onDuplicate = ::duplicateSelected,
                        onDelete = { id -> project = project.withCurrentScene { it.copy(instances = it.instances.filterNot { instance -> instance.id == id }) }; selectedInstanceId = null },
                        onStartPlaytest = ::startPlaytest,
                        onStopPlaytest = ::stopPlaytest,
                        onKey = ::updateRuntimeKey,
                        onAddScene = ::addScene,
                        onSelectScene = { id -> project = project.copy(activeSceneId = id); selectedInstanceId = project.scenes.firstOrNull { it.id == id }?.instances?.firstOrNull()?.id },
                    )
                    EditorTab.EXPLORER -> ExplorerPanel(
                        project = project,
                        selectedInstanceId = selectedInstanceId,
                        selectedObjectId = selectedObjectId,
                        selectedAssetId = selectedAssetId,
                        onSelectScene = { id -> project = project.copy(activeSceneId = id); selectedInstanceId = project.scenes.firstOrNull { it.id == id }?.instances?.firstOrNull()?.id; selectedObjectId = null; selectedAssetId = null },
                        onSelectInstance = { selectedInstanceId = it; selectedObjectId = null; selectedAssetId = null },
                        onSelectObject = { selectedObjectId = it; selectedInstanceId = null; selectedAssetId = null },
                        onSelectAsset = { selectedAssetId = it },
                        onSelectScript = { id -> project = project.copy(selectedScriptId = id); selectedTab = EditorTab.SCRIPT },
                        onAddScene = ::addScene,
                        onAddObject = { addObject("Object${project.objects.size + 1}", "Rectangle") },
                        onAddInstance = { showAddInstance = true },
                        onAddScript = { addScript() },
                        onImportAssets = { isImporting = true; assetPicker.launch(arrayOf("*/*")) },
                        onDeleteInstance = { id -> project = project.withCurrentScene { it.copy(instances = it.instances.filterNot { instance -> instance.id == id }) }; selectedInstanceId = null },
                        onUpdateInstance = ::updateInstance,
                        onUpdateObject = { id, transform -> project = project.copy(objects = project.objects.map { if (it.id == id) transform(it) else it }) },
                        onRenameScene = { id, name -> project = project.copy(scenes = project.scenes.map { if (it.id == id) it.copy(name = name) else it }) },
                        onUpdateScene = { id, transform -> project = project.copy(scenes = project.scenes.map { if (it.id == id) transform(it) else it }) },
                        onDeleteScene = { id ->
                            if (project.scenes.size > 1) {
                                val scenes = project.scenes.filterNot { it.id == id }
                                val nextSceneId = if (project.activeSceneId == id) scenes.first().id else project.activeSceneId
                                project = project.copy(scenes = scenes, activeSceneId = nextSceneId)
                                selectedInstanceId = scenes.firstOrNull { it.id == nextSceneId }?.instances?.firstOrNull()?.id
                                status = "Deleted scene."
                            }
                        },
                        onDeleteObject = { id ->
                            project = project.copy(
                                objects = project.objects.filterNot { it.id == id },
                                scenes = project.scenes.map { scene -> scene.copy(instances = scene.instances.filterNot { it.objectId == id }) },
                                scripts = project.scripts.filterNot { it.targetObjectId == id },
                            )
                            selectedObjectId = null
                        },
                        onApplyAsset = { assetId ->
                            val asset = project.assets.firstOrNull { it.id == assetId }
                            if (asset != null && selectedInstance != null) updateInstance(selectedInstance.id) { it.copy(spriteAssetId = assetId, kind = "Sprite") }
                            else if (asset != null && selectedObject != null) project = project.copy(objects = project.objects.map { if (it.id == selectedObject.id) it.copy(spriteAssetId = assetId, type = "Sprite") else it })
                        },
                        onDeleteAsset = { id ->
                            val removed = project.assets.firstOrNull { it.id == id }
                            project = project.copy(
                                assets = project.assets.filterNot { it.id == id },
                                objects = project.objects.map { definition -> if (definition.spriteAssetId == id) definition.copy(spriteAssetId = null) else definition },
                                scenes = project.scenes.map { scene -> scene.copy(instances = scene.instances.map { item -> if (item.spriteAssetId == id) item.copy(spriteAssetId = null, kind = "Rectangle") else item }) },
                            )
                            if (removed != null) scope.launch { ProjectStorage.deleteAssetFile(context, project, removed) }
                            if (selectedAssetId == id) selectedAssetId = null
                        },
                    )
                    EditorTab.SCRIPT -> ScriptPanel(
                        project = project,
                        selectedScript = selectedScript,
                        output = output,
                        onSelectScript = { id -> project = project.copy(selectedScriptId = id) },
                        onScriptChange = { id, source -> project = project.copy(scripts = project.scripts.map { if (it.id == id) it.copy(source = source) else it }) },
                        onAddScript = { addScript() },
                        onAddEvent = { targetId, event -> addScript(targetId, event) },
                        onDeleteScript = { id ->
                            val scripts = project.scripts.filterNot { it.id == id }
                            project = project.copy(scripts = scripts, selectedScriptId = scripts.firstOrNull()?.id.orEmpty())
                            status = "Deleted script."
                        },
                        onRunTest = { source -> runScriptTest(source) },
                    )
                }
            }

            BottomTabs(selectedTab = selectedTab, onSelect = { selectedTab = it })
            StatusBar(status = if (isImporting) "Importing files…" else status, isBuilding = isBuilding || isImporting, isPlaytest = isPlaytest)
        }
        }
    }

    if (showAddInstance) {
        StudioDialog(title = "Add instance", onDismiss = { showAddInstance = false }) {
            UiText("Choose an object definition to place in ${project.currentScene.name}.", color = TextMuted, size = 12)
            project.objects.forEach { definition ->
                MenuLine("＋  ${definition.name}", "${definition.type} · ${definition.defaultWidth.toInt()} × ${definition.defaultHeight.toInt()}") {
                    showAddInstance = false
                    addInstance(definition.id)
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Border))
            UiText("NEW OBJECT TYPES", color = TextMuted, size = 9, weight = FontWeight.Bold)
            listOf("Rectangle", "Circle", "Ellipse", "Text", "Button", "Sprite").forEach { type ->
                val nextNumber = project.objects.count { it.type == type } + 1
                MenuLine("＋  $type", "Create definition and place an instance") {
                    showAddInstance = false
                    addObject("$type$nextNumber", type)
                    project.objects.lastOrNull()?.let { addInstance(it.id) }
                }
            }
        }
    }

    if (showProjectLibrary) {
        StudioDialog(title = "Projects", onDismiss = { showProjectLibrary = false }) {
            UiText("Projects are stored locally on this device. Export a .bdproj ZIP to move them elsewhere.", color = TextMuted, size = 12)
            if (projectLibrary.isEmpty()) UiText("No saved projects yet.", color = TextMuted, size = 13)
            projectLibrary.forEach { saved ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(5.dp)).clickable {
                        scope.launch {
                            stopPlaytest()
                            ProjectStorage.load(context, saved.id)?.let { opened ->
                                project = opened
                                selectedInstanceId = opened.items.firstOrNull()?.id
                                selectedObjectId = null
                                selectedAssetId = null
                                selectedTab = EditorTab.EDIT
                                status = "Opened ${opened.name}."
                            }
                            showProjectLibrary = false
                        }
                    }.padding(horizontal = 10.dp, vertical = 8.dp)) {
                        UiText(saved.name, color = TextMain, size = 12, weight = FontWeight.Medium)
                        UiText("${saved.scenes.size} scene(s) · ${saved.assets.size} asset(s)", color = TextMuted, size = 9)
                    }
                    StudioButton("Delete", onClick = {
                        if (saved.id == project.id) {
                            status = "Create or open another project before deleting the active project."
                        } else scope.launch {
                            ProjectStorage.delete(context, saved.id)
                            projectLibrary = ProjectStorage.list(context)
                            status = "Deleted ${saved.name}."
                        }
                    }, color = Color(0xFFFF8585), enabled = saved.id != project.id)
                }
            }
            StudioButton("Import project ZIP", onClick = { showProjectLibrary = false; projectPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }, modifier = Modifier.fillMaxWidth())
        }
    }

    if (showProjectDetails) {
        StudioDialog(title = "Project details", onDismiss = { showProjectDetails = false }) {
            PropertyField("Name", projectNameDraft, { projectNameDraft = it })
            UiText("This name is used for the project library and GitHub repository slug.", color = TextMuted, size = 11)
            StudioButton("Apply", onClick = { project = project.copy(name = projectNameDraft.trim().ifBlank { "My Game" }); showProjectDetails = false }, modifier = Modifier.fillMaxWidth())
        }
    }

    if (showTokenDialog) {
        StudioDialog(title = "GitHub token", onDismiss = { showTokenDialog = false }) {
            UiText(if (tokenSaved) "A token is already stored securely on this device. Saving a new one replaces it." else "Enter a GitHub token with repository contents, workflow, and Actions permissions.", color = TextMuted, size = 12)
            BasicTextField(
                value = tokenDraft,
                onValueChange = { tokenDraft = it },
                modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(5.dp)).padding(12.dp),
                textStyle = TextStyle(color = TextMain, fontSize = 13.sp),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            )
            StudioButton("Save token", onClick = {
                if (tokenDraft.isNotBlank()) runCatching { tokenStore.save(tokenDraft.trim()) }
                    .onSuccess { tokenSaved = true; showTokenDialog = false; tokenDraft = ""; status = "GitHub token saved securely on this device." }
                    .onFailure { status = "Token save failed: ${it.message}" }
                else showTokenDialog = false
            }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun TopBar(
    projectName: String,
    sceneName: String,
    isPlaytest: Boolean,
    menuExpanded: Boolean,
    onMenuToggle: () -> Unit,
    onMenuDismiss: () -> Unit,
    onSave: () -> Unit,
    onProjects: () -> Unit,
    onNewProject: () -> Unit,
    onImportProject: () -> Unit,
    onExportProject: () -> Unit,
    onImportAssets: () -> Unit,
    onProjectDetails: () -> Unit,
    onToken: () -> Unit,
    onBuild: () -> Unit,
    isBuilding: Boolean,
) {
    Row(
        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Image(
            painter = painterResource(id = com.nicelytinned.builddroid.R.drawable.builddroid_logo),
            contentDescription = "BuildDroid logo",
            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(5.dp)),
        )
        Column(Modifier.weight(1f)) {
            UiText("BuildDroid", color = TextMain, size = 17, weight = FontWeight.Bold)
            UiText("NicelyTinned · $projectName · $sceneName", color = TextMuted, size = 10)
        }
        if (isPlaytest) Pill("PLAY", Accent)
        Box {
            StudioButton("File  ▾", onClick = onMenuToggle, selected = menuExpanded)
        }
    }
}

@Composable
private fun FileMenu(
    onClose: () -> Unit,
    onSave: () -> Unit,
    onProjects: () -> Unit,
    onNewProject: () -> Unit,
    onImportProject: () -> Unit,
    onExportProject: () -> Unit,
    onImportAssets: () -> Unit,
    onProjectDetails: () -> Unit,
    onToken: () -> Unit,
    onBuild: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp).background(Panel2, RoundedCornerShape(6.dp)).border(1.dp, Border, RoundedCornerShape(6.dp)).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        MenuLine("Save project", "Autosave is enabled", onSave)
        MenuLine("Project manager", "Open / switch projects", onProjects)
        MenuLine("New project", "Create a blank project", onNewProject)
        MenuLine("Import project ZIP", "Open a .bdproj archive", onImportProject)
        MenuLine("Export project ZIP", "Include project data and assets", onExportProject)
        MenuLine("Import assets / files", "Images, audio, fonts, data", onImportAssets)
        MenuLine("Project details", "Name and metadata", onProjectDetails)
        MenuLine("GitHub token", "Securely stored on device", onToken)
        MenuLine("Build APK with Actions", "${if (false) "Building" else "Cloud build"}", onBuild)
    }
}

@Composable
private fun EditPanel(
    project: BuildDroidProject,
    selectedInstanceId: String?,
    selectedInstance: ProjectItem?,
    isPlaytest: Boolean,
    runtimeFrame: LuaGameRuntime.Frame?,
    images: Map<String, ImageBitmap>,
    onSelectInstance: (String) -> Unit,
    onMoveInstance: (String, Float, Float) -> Unit,
    onResizeInstance: (String, Float, Float, Float, Float) -> Unit,
    onMoveRuntime: (String, Float, Float) -> Unit,
    onPointer: (Float, Float, Boolean) -> Unit,
    onUpdateInstance: (String, (ProjectItem) -> ProjectItem) -> Unit,
    onAddInstance: () -> Unit,
    onAddObject: () -> Unit,
    onAddUi: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: (String) -> Unit,
    onStartPlaytest: () -> Unit,
    onStopPlaytest: () -> Unit,
    onKey: (String, Boolean) -> Unit,
    onAddScene: () -> Unit,
    onSelectScene: (String) -> Unit,
) {
    val definitions = project.objects.associateBy { it.id }
    val drawItems = if (isPlaytest) {
        runtimeFrame?.instances.orEmpty().map { frame ->
            val def = definitions[frame.objectId]
            DrawItem(frame.id.toString(), frame.objectId, frame.objectName, def?.type ?: "Rectangle", frame.x, frame.y, frame.width, frame.height, frame.rotation, frame.depth, frame.color, frame.alpha, frame.visible, frame.text, frame.spriteAssetId ?: def?.spriteAssetId, false)
        }
    } else {
        project.items.map { item ->
            val def = definitions[item.objectId]
            DrawItem(item.id, item.objectId, item.name, item.kind, item.x, item.y, item.width * item.scaleX, item.height * item.scaleY, item.rotation, item.depth, item.color, item.alpha, item.visible, item.text, item.spriteAssetId ?: def?.spriteAssetId, item.locked)
        }
    }
    Column(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                UiText(if (isPlaytest) "Playtest" else "SCENE EDITOR", color = TextMain, size = 16, weight = FontWeight.Bold)
                UiText("${project.currentScene.name}  ·  ${project.currentScene.width} × ${project.currentScene.height}  ·  ${drawItems.size} objects", color = TextMuted, size = 9)
            }
            if (isPlaytest) {
                StudioButton("Stop", onClick = onStopPlaytest, selected = true, color = Color(0xFFFF7D7D))
            } else {
                StudioButton("＋ Add", onClick = onAddInstance)
                StudioButton("▶ Play", onClick = onStartPlaytest, selected = true)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            StudioButton("Object", onClick = onAddObject)
            StudioButton("UI", onClick = onAddUi)
            if (!isPlaytest) {
                StudioButton("Duplicate", onClick = onDuplicate, enabled = selectedInstance != null)
                StudioButton("Delete", onClick = { selectedInstance?.let { onDelete(it.id) } }, enabled = selectedInstance != null, color = Color(0xFFFF8B8B))
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            project.scenes.forEach { scene ->
                StudioButton(scene.name, onClick = { if (!isPlaytest) onSelectScene(scene.id) }, selected = scene.id == project.activeSceneId, enabled = !isPlaytest)
            }
            if (!isPlaytest) StudioButton("＋ Scene", onClick = onAddScene)
        }
        SceneCanvas(
            scene = project.currentScene,
            items = drawItems,
            selectedId = if (isPlaytest) null else selectedInstanceId,
            images = images,
            isPlaytest = isPlaytest,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            onSelect = { id -> if (!isPlaytest) onSelectInstance(id) },
            onPointer = onPointer,
            onMove = { id, dx, dy -> if (isPlaytest) {
                val item = drawItems.firstOrNull { it.id == id }
                if (item != null) onMoveRuntime(id, item.x + dx, item.y + dy)
            } else onMoveInstance(id, dx, dy) },
            onResize = onResizeInstance,
        )
        if (isPlaytest) {
            runtimeFrame?.error?.let { UiText("Runtime error: $it", color = Color(0xFFFF8585), size = 11) }
            UiText("${runtimeFrame?.timeSeconds?.let { "%.1f".format(it) } ?: "0.0"}s  ·  ${runtimeFrame?.logs?.lastOrNull() ?: "running"}", color = TextMuted, size = 10)
        } else if (selectedInstance != null) {
            CompactInstanceInspector(item = selectedInstance, onChange = { transform -> onUpdateInstance(selectedInstance.id, transform) })
        } else {
            UiText("select an instance · drag to move · use the corner and edge handles to resize", color = TextMuted, size = 9)
        }
    }
}

@Composable
private fun FullscreenPlaytest(
    scene: GameScene,
    objectDefinitions: Map<String, GameObjectDefinition>,
    frame: LuaGameRuntime.Frame?,
    images: Map<String, ImageBitmap>,
    onPointer: (Float, Float, Boolean) -> Unit,
    onKey: (String, Boolean) -> Unit,
    onStop: () -> Unit,
) {
    val items = remember(frame?.instances, objectDefinitions) {
        frame?.instances.orEmpty().map { instance ->
            val definition = objectDefinitions[instance.objectId]
            DrawItem(
                id = instance.id.toString(), objectId = instance.objectId, name = instance.objectName,
                type = definition?.type ?: "Rectangle", x = instance.x, y = instance.y,
                width = instance.width, height = instance.height, rotation = instance.rotation,
                depth = instance.depth, color = instance.color, alpha = instance.alpha,
                visible = instance.visible, text = instance.text,
                assetId = instance.spriteAssetId ?: definition?.spriteAssetId, locked = false,
            )
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        SceneCanvas(
            scene = scene,
            items = items,
            selectedId = null,
            images = images,
            isPlaytest = true,
            modifier = Modifier.fillMaxSize(),
            onSelect = {},
            onPointer = onPointer,
            onMove = { _, _, _ -> },
            onResize = { _, _, _, _, _ -> },
        )
        Box(Modifier.align(Alignment.TopEnd).padding(10.dp).background(Color(0xCC101923), RoundedCornerShape(5.dp))) {
            StudioButton("EXIT  ×", onClick = onStop, color = Color(0xFFFF8B8B))
        }
        Row(
            Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 12.dp)
                .background(Color(0x55202D3B), RoundedCornerShape(8.dp)).padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            HoldControl("◀", "left", onKey)
            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                HoldControl("▲", "up", onKey)
                HoldControl("▼", "down", onKey)
            }
            HoldControl("▶", "right", onKey)
        }
    }
}

@Composable
private fun SceneCanvas(
    scene: GameScene,
    items: List<DrawItem>,
    selectedId: String?,
    images: Map<String, ImageBitmap>,
    isPlaytest: Boolean,
    modifier: Modifier,
    onSelect: (String) -> Unit,
    onPointer: (Float, Float, Boolean) -> Unit,
    onMove: (String, Float, Float) -> Unit,
    onResize: (String, Float, Float, Float, Float) -> Unit,
) {
    var viewportWidth by remember { mutableStateOf(1f) }
    var viewportHeight by remember { mutableStateOf(1f) }
    val currentItems by rememberUpdatedState(items)
    val currentScene by rememberUpdatedState(scene)
    val currentPlaytest by rememberUpdatedState(isPlaytest)
    val currentSelectedId by rememberUpdatedState(selectedId)
    val latestSelect by rememberUpdatedState(onSelect)
    val latestPointer by rememberUpdatedState(onPointer)
    val latestMove by rememberUpdatedState(onMove)
    val latestResize by rememberUpdatedState(onResize)
    val nativeTextPaint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 22f
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
    }
    val renderItems = remember(items) { items.sortedBy { it.depth } }
    val canvasShape = if (isPlaytest) RoundedCornerShape(0.dp) else RoundedCornerShape(6.dp)

    fun worldScale(): Float = min(
        viewportWidth / currentScene.width.toFloat(),
        viewportHeight / currentScene.height.toFloat(),
    ).coerceAtLeast(0.001f)

    fun mapPoint(point: Offset): Offset {
        val scale = worldScale()
        val left = (viewportWidth - currentScene.width * scale) / 2f
        val top = (viewportHeight - currentScene.height * scale) / 2f
        return Offset((point.x - left) / scale, (point.y - top) / scale)
    }

    fun hit(point: Offset): DrawItem? {
        val mapped = mapPoint(point)
        return currentItems.asSequence().sortedBy { it.depth }.toList().asReversed().firstOrNull { item ->
            item.visible && mapped.x >= item.x && mapped.y >= item.y && mapped.x <= item.x + item.width && mapped.y <= item.y + item.height
        }
    }

    fun handleAt(point: Offset, item: DrawItem): String? {
        val middleX = item.x + item.width / 2f
        val middleY = item.y + item.height / 2f
        val handles = listOf(
            "nw" to Offset(item.x, item.y), "n" to Offset(middleX, item.y), "ne" to Offset(item.x + item.width, item.y),
            "e" to Offset(item.x + item.width, middleY), "se" to Offset(item.x + item.width, item.y + item.height),
            "s" to Offset(middleX, item.y + item.height), "sw" to Offset(item.x, item.y + item.height),
            "w" to Offset(item.x, middleY),
        )
        val tolerance = 17f / worldScale()
        return handles.minByOrNull { (_, center) -> (center - point).let { it.x * it.x + it.y * it.y } }
            ?.takeIf { (_, center) -> (center - point).let { it.x * it.x + it.y * it.y } <= tolerance * tolerance }
            ?.first
    }

    Canvas(
        modifier = modifier
            .clip(canvasShape)
            .background(Color(0xFF070C12))
            .border(if (isPlaytest) 0.dp else 1.dp, Border, canvasShape)
            .onSizeChanged { viewportWidth = it.width.toFloat(); viewportHeight = it.height.toFloat() }
            .pointerInput(isPlaytest, selectedId) {
                if (currentPlaytest) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        var mapped = mapPoint(down.position)
                        latestPointer(mapped.x, mapped.y, true)
                        var pressed = true
                        while (pressed) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            mapped = mapPoint(change.position)
                            pressed = change.pressed
                            latestPointer(mapped.x, mapped.y, pressed)
                            if (!pressed) change.consume()
                        }
                    }
                } else {
                    detectTapGestures { point -> hit(point)?.let { latestSelect(it.id) } }
                }
            }
            .pointerInput(isPlaytest, selectedId) {
                if (!currentPlaytest) {
                    var dragged: DrawItem? = null
                    var resizeHandle: String? = null
                    detectDragGestures(
                        onDragStart = { point ->
                            val world = mapPoint(point)
                            val selected = currentItems.firstOrNull { it.id == currentSelectedId && it.visible && !it.locked }
                            resizeHandle = selected?.let { handleAt(world, it) }
                            dragged = if (resizeHandle != null) selected else hit(point)
                            dragged?.let { item ->
                                latestSelect(item.id)
                                if (item.locked) { dragged = null; resizeHandle = null }
                            }
                        },
                        onDragEnd = { dragged = null; resizeHandle = null },
                        onDragCancel = { dragged = null; resizeHandle = null },
                        onDrag = { change, amount ->
                            change.consume()
                            val item = dragged ?: return@detectDragGestures
                            val scale = worldScale()
                            val dx = amount.x / scale
                            val dy = amount.y / scale
                            val handle = resizeHandle
                            if (handle == null) {
                                latestMove(item.id, dx, dy)
                                dragged = item.copy(x = item.x + dx, y = item.y + dy)
                            } else {
                                var left = item.x
                                var top = item.y
                                var right = item.x + item.width
                                var bottom = item.y + item.height
                                val minSize = 8f
                                if ('w' in handle) left = (left + dx).coerceIn(0f, maxOf(0f, right - minSize))
                                if ('e' in handle) right = (right + dx).coerceIn(minOf(currentScene.width.toFloat(), left + minSize), currentScene.width.toFloat())
                                if ('n' in handle) top = (top + dy).coerceIn(0f, maxOf(0f, bottom - minSize))
                                if ('s' in handle) bottom = (bottom + dy).coerceIn(minOf(currentScene.height.toFloat(), top + minSize), currentScene.height.toFloat())
                                dragged = item.copy(x = left, y = top, width = right - left, height = bottom - top)
                                latestResize(item.id, left, top, right - left, bottom - top)
                            }
                        },
                    )
                }
            },
    ) {
        val scale = min(size.width / scene.width.toFloat(), size.height / scene.height.toFloat()).coerceAtLeast(0.001f)
        val offsetX = (size.width - scene.width * scale) / 2f
        val offsetY = (size.height - scene.height * scale) / 2f
        drawRect(Color(0xFF070C12))
        withTransform({ translate(offsetX, offsetY); scale(scale, scale, pivot = Offset.Zero) }) {
            drawRect(parseHex(scene.background), size = Size(scene.width.toFloat(), scene.height.toFloat()))
            if (!isPlaytest) {
                val gridStep = 32f
                var x = 0f
                while (x <= scene.width) { drawLine(Color(0x182E4358), Offset(x, 0f), Offset(x, scene.height.toFloat()), 1f); x += gridStep }
                var y = 0f
                while (y <= scene.height) { drawLine(Color(0x182E4358), Offset(0f, y), Offset(scene.width.toFloat(), y), 1f); y += gridStep }
                drawRect(Color(0xFF31465B), size = Size(scene.width.toFloat(), scene.height.toFloat()), style = Stroke(width = 1f))
            }
            renderItems.forEach { item ->
                if (!item.visible) return@forEach
                val tint = parseHex(item.color).copy(alpha = item.alpha.coerceIn(0f, 1f))
                val pivot = Offset(item.x + item.width / 2f, item.y + item.height / 2f)
                rotate(item.rotation, pivot) {
                    val image = item.assetId?.let(images::get)
                    if (image != null) {
                        drawImage(image, dstOffset = IntOffset(item.x.toInt(), item.y.toInt()), dstSize = IntSize(item.width.toInt().coerceAtLeast(1), item.height.toInt().coerceAtLeast(1)), alpha = item.alpha)
                    } else when (item.type.lowercase()) {
                        "circle", "ellipse" -> drawCircle(tint, radius = min(item.width, item.height) / 2f, center = pivot)
                        "text", "label" -> {
                            nativeTextPaint.color = runCatching { android.graphics.Color.parseColor(item.color) }.getOrDefault(android.graphics.Color.WHITE)
                            nativeTextPaint.alpha = (item.alpha.coerceIn(0f, 1f) * 255).toInt()
                            drawContext.canvas.nativeCanvas.drawText(item.text.ifBlank { item.name }, item.x, item.y + min(item.height, 28f), nativeTextPaint)
                        }
                        else -> drawRoundRect(tint, Offset(item.x, item.y), Size(item.width, item.height), CornerRadius(if (item.type == "Button") 8f else 4f, if (item.type == "Button") 8f else 4f))
                    }
                }
                if (!isPlaytest && item.id == selectedId) {
                    val handleSize = 12f / scale
                    val half = handleSize / 2f
                    val midX = item.x + item.width / 2f
                    val midY = item.y + item.height / 2f
                    val left = item.x
                    val top = item.y
                    val right = item.x + item.width
                    val bottom = item.y + item.height
                    drawRect(Color.White, Offset(left - 2f / scale, top - 2f / scale), Size(item.width + 4f / scale, item.height + 4f / scale), style = Stroke(width = 2f / scale))
                    listOf(
                        Offset(left, top), Offset(midX, top), Offset(right, top), Offset(right, midY),
                        Offset(right, bottom), Offset(midX, bottom), Offset(left, bottom), Offset(left, midY),
                    ).forEach { center ->
                        drawRect(Color(0xFF07111A), Offset(center.x - half - 1f / scale, center.y - half - 1f / scale), Size(handleSize + 2f / scale, handleSize + 2f / scale))
                        drawRect(Color.White, Offset(center.x - half, center.y - half), Size(handleSize, handleSize))
                        drawRect(Accent, Offset(center.x - half, center.y - half), Size(handleSize, handleSize), style = Stroke(width = 1.5f / scale))
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactInstanceInspector(item: ProjectItem, onChange: ((ProjectItem) -> ProjectItem) -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(6.dp)).border(1.dp, Border, RoundedCornerShape(6.dp)).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            UiText("PROPERTIES · ${item.name}", color = Accent, size = 10, weight = FontWeight.Bold)
            UiText(item.kind, color = TextMuted, size = 10)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumberField("X", item.x, { value -> onChange { it.copy(x = value) } }, Modifier.weight(1f))
            NumberField("Y", item.y, { value -> onChange { it.copy(y = value) } }, Modifier.weight(1f))
            NumberField("W", item.width, { value -> onChange { it.copy(width = value.coerceAtLeast(1f)) } }, Modifier.weight(1f))
            NumberField("H", item.height, { value -> onChange { it.copy(height = value.coerceAtLeast(1f)) } }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumberField("Rotation", item.rotation, { value -> onChange { it.copy(rotation = value) } }, Modifier.weight(1f))
            NumberField("Depth", item.depth.toFloat(), { value -> onChange { it.copy(depth = value.toInt()) } }, Modifier.weight(1f))
            PropertyField("Color", item.color, { value -> onChange { it.copy(color = value) } }, Modifier.weight(1.5f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumberField("Scale X", item.scaleX, { value -> onChange { it.copy(scaleX = value.coerceAtLeast(0.01f)) } }, Modifier.weight(1f))
            NumberField("Scale Y", item.scaleY, { value -> onChange { it.copy(scaleY = value.coerceAtLeast(0.01f)) } }, Modifier.weight(1f))
            NumberField("Alpha", item.alpha, { value -> onChange { it.copy(alpha = value.coerceIn(0f, 1f)) } }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NumberField("VX", item.velocityX, { value -> onChange { it.copy(velocityX = value) } }, Modifier.weight(1f))
            NumberField("VY", item.velocityY, { value -> onChange { it.copy(velocityY = value) } }, Modifier.weight(1f))
            NumberField("Gravity", item.gravity, { value -> onChange { it.copy(gravity = value) } }, Modifier.weight(1f))
            NumberField("Bounce", item.bounce, { value -> onChange { it.copy(bounce = value.coerceIn(0f, 1f)) } }, Modifier.weight(1f))
        }
        PropertyField("Text", item.text, { value -> onChange { it.copy(text = value) } })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            ToggleLine("Visible", item.visible) { value -> onChange { it.copy(visible = value) } }
            ToggleLine("Collision", item.collisionEnabled) { value -> onChange { it.copy(collisionEnabled = value) } }
            ToggleLine("Locked", item.locked) { value -> onChange { it.copy(locked = value) } }
        }
    }
}

@Composable
private fun ExplorerPanel(
    project: BuildDroidProject,
    selectedInstanceId: String?,
    selectedObjectId: String?,
    selectedAssetId: String?,
    onSelectScene: (String) -> Unit,
    onSelectInstance: (String) -> Unit,
    onSelectObject: (String) -> Unit,
    onSelectAsset: (String) -> Unit,
    onSelectScript: (String) -> Unit,
    onAddScene: () -> Unit,
    onAddObject: () -> Unit,
    onAddInstance: () -> Unit,
    onAddScript: () -> Unit,
    onImportAssets: () -> Unit,
    onDeleteInstance: (String) -> Unit,
    onUpdateInstance: (String, (ProjectItem) -> ProjectItem) -> Unit,
    onUpdateObject: (String, (GameObjectDefinition) -> GameObjectDefinition) -> Unit,
    onRenameScene: (String, String) -> Unit,
    onUpdateScene: (String, (GameScene) -> GameScene) -> Unit,
    onDeleteScene: (String) -> Unit,
    onDeleteObject: (String) -> Unit,
    onApplyAsset: (String) -> Unit,
    onDeleteAsset: (String) -> Unit,
) {
    val selectedItem = project.items.firstOrNull { it.id == selectedInstanceId }
    val selectedObject = project.objects.firstOrNull { it.id == selectedObjectId }
    val selectedAsset = project.assets.firstOrNull { it.id == selectedAssetId }
    var sceneName by remember(project.activeSceneId, project.currentScene.name) { mutableStateOf(project.currentScene.name) }
    Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                UiText("Explorer", color = TextMain, size = 17, weight = FontWeight.Bold)
                UiText("Project hierarchy · objects · instances · resources", color = TextMuted, size = 10)
            }
            StudioButton("＋ Import", onClick = onImportAssets)
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(6.dp)).border(1.dp, Border, RoundedCornerShape(6.dp)).padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            item { ExplorerSection("SCENES", "＋", onAddScene) }
            items(project.scenes, key = { "scene-${it.id}" }) { scene ->
                TreeRow("▣", scene.name, scene.id == project.activeSceneId, "${scene.instances.size} instance(s)") { onSelectScene(scene.id) }
            }
            item { ExplorerSection("OBJECT DEFINITIONS", "＋", onAddObject) }
            items(project.objects, key = { "object-${it.id}" }) { item ->
                TreeRow("◇", item.name, item.id == selectedObjectId, "${item.type} · ${item.defaultWidth.toInt()}×${item.defaultHeight.toInt()}") { onSelectObject(item.id) }
            }
            item { ExplorerSection("${project.currentScene.name.uppercase()} · INSTANCES", "＋", onAddInstance) }
            items(project.items, key = { "instance-${it.id}" }) { item ->
                TreeRow("◈", item.name, item.id == selectedInstanceId, "${item.x.toInt()}, ${item.y.toInt()} · ${item.kind}") { onSelectInstance(item.id) }
            }
            item { ExplorerSection("ASSETS", "＋", onImportAssets) }
            items(project.assets, key = { "asset-${it.id}" }) { asset ->
                val glyph = when (asset.category) { "Image" -> "▧"; "Audio" -> "♫"; "Font" -> "Aa"; else -> "▤" }
                TreeRow(glyph, asset.name, asset.id == selectedAssetId, "${asset.category} · ${formatBytes(asset.sizeBytes)}") { onSelectAsset(asset.id) }
            }
            item { ExplorerSection("SCRIPTS", "＋", onAddScript) }
            items(project.scripts, key = { "script-${it.id}" }) { script ->
                TreeRow("{ }", script.name, script.id == project.selectedScriptId, script.eventType) { onSelectScript(script.id) }
            }
        }
        when {
            selectedAsset != null -> {
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(6.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    UiText("ASSET PROPERTIES", color = Accent, size = 10, weight = FontWeight.Bold)
                    UiText(selectedAsset.name, color = TextMain, size = 14, weight = FontWeight.SemiBold)
                    UiText("${selectedAsset.category} · ${selectedAsset.mimeType} · ${formatBytes(selectedAsset.sizeBytes)}", color = TextMuted, size = 10)
                    UiText("Select an instance or object first, then choose an asset to apply it as a sprite.", color = TextMuted, size = 10)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StudioButton("Apply to selected", onClick = { onApplyAsset(selectedAsset.id) }, modifier = Modifier.weight(1f), enabled = selectedItem != null || selectedObject != null)
                        StudioButton("Remove", onClick = { onDeleteAsset(selectedAsset.id) }, color = Color(0xFFFF8585))
                    }
                }
            }
            selectedItem != null -> {
                Column(Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()).background(Panel, RoundedCornerShape(6.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        UiText("INSTANCE PROPERTIES", color = Accent, size = 10, weight = FontWeight.Bold)
                        StudioButton("Delete", onClick = { onDeleteInstance(selectedItem.id) }, color = Color(0xFFFF8585))
                    }
                    PropertyField("Name", selectedItem.name, { value -> onUpdateInstance(selectedItem.id) { it.copy(name = value) } })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NumberField("X", selectedItem.x, { value -> onUpdateInstance(selectedItem.id) { it.copy(x = value) } }, Modifier.weight(1f))
                        NumberField("Y", selectedItem.y, { value -> onUpdateInstance(selectedItem.id) { it.copy(y = value) } }, Modifier.weight(1f))
                        NumberField("Width", selectedItem.width, { value -> onUpdateInstance(selectedItem.id) { it.copy(width = value.coerceAtLeast(1f)) } }, Modifier.weight(1f))
                        NumberField("Height", selectedItem.height, { value -> onUpdateInstance(selectedItem.id) { it.copy(height = value.coerceAtLeast(1f)) } }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NumberField("Rotation", selectedItem.rotation, { value -> onUpdateInstance(selectedItem.id) { it.copy(rotation = value) } }, Modifier.weight(1f))
                        NumberField("Depth", selectedItem.depth.toFloat(), { value -> onUpdateInstance(selectedItem.id) { it.copy(depth = value.toInt()) } }, Modifier.weight(1f))
                        PropertyField("Color", selectedItem.color, { value -> onUpdateInstance(selectedItem.id) { it.copy(color = value) } }, Modifier.weight(1.5f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ToggleLine("Visible", selectedItem.visible) { value -> onUpdateInstance(selectedItem.id) { it.copy(visible = value) } }
                        ToggleLine("Locked", selectedItem.locked) { value -> onUpdateInstance(selectedItem.id) { it.copy(locked = value) } }
                        ToggleLine("Collision", selectedItem.collisionEnabled) { value -> onUpdateInstance(selectedItem.id) { it.copy(collisionEnabled = value) } }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NumberField("Velocity X", selectedItem.velocityX, { value -> onUpdateInstance(selectedItem.id) { it.copy(velocityX = value) } }, Modifier.weight(1f))
                        NumberField("Velocity Y", selectedItem.velocityY, { value -> onUpdateInstance(selectedItem.id) { it.copy(velocityY = value) } }, Modifier.weight(1f))
                        NumberField("Gravity", selectedItem.gravity, { value -> onUpdateInstance(selectedItem.id) { it.copy(gravity = value) } }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NumberField("Scale X", selectedItem.scaleX, { value -> onUpdateInstance(selectedItem.id) { it.copy(scaleX = value.coerceAtLeast(0.01f)) } }, Modifier.weight(1f))
                        NumberField("Scale Y", selectedItem.scaleY, { value -> onUpdateInstance(selectedItem.id) { it.copy(scaleY = value.coerceAtLeast(0.01f)) } }, Modifier.weight(1f))
                        NumberField("Alpha", selectedItem.alpha, { value -> onUpdateInstance(selectedItem.id) { it.copy(alpha = value.coerceIn(0f, 1f)) } }, Modifier.weight(1f))
                        NumberField("Bounce", selectedItem.bounce, { value -> onUpdateInstance(selectedItem.id) { it.copy(bounce = value.coerceIn(0f, 1f)) } }, Modifier.weight(1f))
                    }
                    PropertyField("Text", selectedItem.text, { value -> onUpdateInstance(selectedItem.id) { it.copy(text = value) } })
                    UiText("CUSTOM VARIABLES", color = Accent, size = 9, weight = FontWeight.Bold)
                    selectedItem.variables.toSortedMap().forEach { (variableName, variableValue) ->
                        PropertyField(variableName, variableValue, { value ->
                            onUpdateInstance(selectedItem.id) { it.copy(variables = it.variables + (variableName to value)) }
                        })
                    }
                    StudioButton("＋ Add variable", onClick = {
                        val nextName = generateSequence(1) { it + 1 }.map { "variable_$it" }.first { it !in selectedItem.variables }
                        onUpdateInstance(selectedItem.id) { it.copy(variables = it.variables + (nextName to "")) }
                    })
                    if (project.assets.any { it.category == "Image" }) {
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            project.assets.filter { it.category == "Image" }.forEach { asset ->
                                StudioButton(asset.name.take(9), onClick = { onApplyAsset(asset.id) }, selected = selectedItem.spriteAssetId == asset.id)
                            }
                        }
                    }
                }
            }
            selectedObject != null -> {
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(6.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        UiText("OBJECT DEFINITION", color = Accent, size = 10, weight = FontWeight.Bold)
                        StudioButton("Delete", onClick = { onDeleteObject(selectedObject.id) }, color = Color(0xFFFF8585))
                    }
                    PropertyField("Name", selectedObject.name, { value -> onUpdateObject(selectedObject.id) { it.copy(name = value) } })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PropertyField("Type", selectedObject.type, { value -> onUpdateObject(selectedObject.id) { it.copy(type = value) } }, Modifier.weight(1f))
                        PropertyField("Color", selectedObject.color, { value -> onUpdateObject(selectedObject.id) { it.copy(color = value) } }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NumberField("Default W", selectedObject.defaultWidth, { value -> onUpdateObject(selectedObject.id) { it.copy(defaultWidth = value.coerceAtLeast(1f)) } }, Modifier.weight(1f))
                        NumberField("Default H", selectedObject.defaultHeight, { value -> onUpdateObject(selectedObject.id) { it.copy(defaultHeight = value.coerceAtLeast(1f)) } }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NumberField("Gravity", selectedObject.gravity, { value -> onUpdateObject(selectedObject.id) { it.copy(gravity = value) } }, Modifier.weight(1f))
                        NumberField("Bounce", selectedObject.bounce, { value -> onUpdateObject(selectedObject.id) { it.copy(bounce = value.coerceIn(0f, 1f)) } }, Modifier.weight(1f))
                    }
                    StudioButton("Place instance", onClick = onAddInstance, modifier = Modifier.fillMaxWidth())
                }
            }
            else -> {
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(6.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    UiText("SCENE SETTINGS", color = Accent, size = 10, weight = FontWeight.Bold)
                    PropertyField("Scene name", sceneName, { value -> sceneName = value; onRenameScene(project.activeSceneId, value) })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NumberField("Width", project.currentScene.width.toFloat(), { value -> onUpdateScene(project.activeSceneId) { it.copy(width = value.toInt().coerceIn(64, 8192)) } }, Modifier.weight(1f))
                        NumberField("Height", project.currentScene.height.toFloat(), { value -> onUpdateScene(project.activeSceneId) { it.copy(height = value.toInt().coerceIn(64, 8192)) } }, Modifier.weight(1f))
                    }
                    PropertyField("Background", project.currentScene.background, { value -> onUpdateScene(project.activeSceneId) { it.copy(background = value) } })
                    if (project.scenes.size > 1) StudioButton("Delete scene", onClick = { onDeleteScene(project.activeSceneId) }, color = Color(0xFFFF8585), modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun ScriptPanel(
    project: BuildDroidProject,
    selectedScript: ScriptDocument?,
    output: String,
    onSelectScript: (String) -> Unit,
    onScriptChange: (String, String) -> Unit,
    onAddScript: () -> Unit,
    onAddEvent: (String?, String) -> Unit,
    onDeleteScript: (String) -> Unit,
    onRunTest: (String) -> Unit,
) {
    var eventTarget by remember { mutableStateOf(project.objects.firstOrNull()?.id.orEmpty()) }
    var eventType by remember { mutableStateOf("Step") }
    data class EditorDraft(val scriptId: String, val source: String)
    var editorDraft by remember { mutableStateOf(selectedScript?.let { EditorDraft(it.id, it.source) }) }
    val latestDraftState = rememberUpdatedState(editorDraft)
    val latestScriptChange = rememberUpdatedState(onScriptChange)
    LaunchedEffect(selectedScript?.id) {
        val selected = selectedScript
        if (selected != null && editorDraft?.scriptId != selected.id) {
            editorDraft = EditorDraft(selected.id, selected.source)
        }
    }
    LaunchedEffect(editorDraft?.scriptId, editorDraft?.source) {
        val draft = editorDraft ?: return@LaunchedEffect
        delay(600)
        if (selectedScript?.id == draft.scriptId) onScriptChange(draft.scriptId, draft.source)
    }
    DisposableEffect(selectedScript?.id) {
        val scriptIdBeingDisplayed = selectedScript?.id
        onDispose {
            latestDraftState.value?.takeIf { it.scriptId == scriptIdBeingDisplayed }?.let { draft ->
                latestScriptChange.value(draft.scriptId, draft.source)
            }
        }
    }
    LaunchedEffect(selectedScript?.id) {
        eventTarget = selectedScript?.targetObjectId.orEmpty()
        eventType = selectedScript?.eventType ?: "Script"
    }
    Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                UiText("Lua 5.1 Editor", color = TextMain, size = 17, weight = FontWeight.Bold)
                UiText(selectedScript?.let { "${it.name} · ${it.eventType}" } ?: "No script selected", color = TextMuted, size = 10)
            }
            StudioButton("＋ Script", onClick = onAddScript)
            StudioButton("Delete", onClick = { selectedScript?.let { onDeleteScript(it.id) } }, enabled = selectedScript != null, color = Color(0xFFFF8585))
            StudioButton("▶ Run", onClick = { editorDraft?.let { onRunTest(it.source) } }, selected = true)
        }
        Row(Modifier.fillMaxWidth().height(38.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            project.scripts.forEach { script ->
                StudioButton(script.name.take(14), onClick = { onSelectScript(script.id) }, selected = script.id == selectedScript?.id)
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            UiText("EVENT", color = TextMuted, size = 9, weight = FontWeight.Bold)
            project.objects.forEach { objectDefinition ->
                StudioButton(objectDefinition.name, onClick = { eventTarget = objectDefinition.id }, selected = eventTarget == objectDefinition.id)
            }
            StudioButton("Global", onClick = { eventTarget = "" }, selected = eventTarget.isBlank())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("Create", "Step", "Collision", "Destroy").forEach { event ->
                StudioButton(event, onClick = { eventType = event }, selected = eventType == event)
            }
            StudioButton("＋ Add", onClick = { onAddEvent(eventTarget.takeIf { it.isNotBlank() }, eventType) })
        }
        if (selectedScript != null) {
            LuaCodeEditor(
                source = editorDraft?.takeIf { it.scriptId == selectedScript.id }?.source ?: selectedScript.source,
                onSourceChange = { updated -> editorDraft = EditorDraft(selectedScript.id, updated) },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
        } else {
            Box(Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                UiText("Create a script to start coding.", color = TextMuted, size = 12)
            }
        }
        Column(Modifier.fillMaxWidth().height(112.dp).background(Panel, RoundedCornerShape(6.dp)).border(1.dp, Border, RoundedCornerShape(6.dp)).padding(10.dp)) {
            UiText("OUTPUT / CONSOLE", color = Accent, size = 9, weight = FontWeight.Bold)
            BasicText(
                output,
                modifier = Modifier.padding(top = 5.dp).verticalScroll(rememberScrollState()),
                style = TextStyle(color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 14.sp),
            )
        }
    }
}

@Composable
private fun HoldControl(label: String, key: String, onKey: (String, Boolean) -> Unit) {
    Box(
        Modifier.padding(4.dp).size(48.dp).clip(RoundedCornerShape(6.dp)).background(Panel2).border(1.dp, Border, RoundedCornerShape(6.dp))
            .pointerInput(key) {
                awaitEachGesture {
                    awaitFirstDown()
                    onKey(key, true)
                    waitForUpOrCancellation()
                    onKey(key, false)
                }
            },
        contentAlignment = Alignment.Center,
    ) { UiText(label, color = TextMain, size = 20, weight = FontWeight.Bold) }
}

@Composable
private fun BottomTabs(selectedTab: EditorTab, onSelect: (EditorTab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        EditorTab.entries.forEach { tab ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(5.dp)).background(if (selectedTab == tab) Panel3 else Color.Transparent)
                    .clickable { onSelect(tab) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                UiText(tab.glyph, color = if (selectedTab == tab) Accent else TextMuted, size = 15, weight = FontWeight.Bold)
                UiText(tab.label, color = if (selectedTab == tab) TextMain else TextMuted, size = 9)
            }
        }
    }
}

@Composable
private fun StatusBar(status: String, isBuilding: Boolean, isPlaytest: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF080D12)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(if (isBuilding) Warning else if (isPlaytest) AccentBlue else Accent))
        UiText(status, color = TextMuted, size = 9)
    }
}

@Composable
private fun ExplorerSection(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        UiText(title, color = TextMuted, size = 9, weight = FontWeight.Bold)
        UiText(action, color = Accent, size = 14, modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 2.dp))
    }
}

@Composable
private fun TreeRow(glyph: String, title: String, selected: Boolean, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(5.dp)).background(if (selected) Color(0xFF263B4D) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        UiText(glyph, color = if (selected) Accent else AccentBlue, size = 12, weight = FontWeight.Bold)
        Column(Modifier.weight(1f)) {
            UiText(title, color = TextMain, size = 12, weight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
            UiText(subtitle, color = TextMuted, size = 9)
        }
    }
}

@Composable
private fun CompactDummy() = Unit

@Composable
private fun StudioButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
    color: Color = Accent,
) {
    Box(
        modifier.clip(RoundedCornerShape(5.dp))
            .background(if (selected) color.copy(alpha = 0.16f) else Panel2)
            .border(1.dp, if (selected) color.copy(alpha = 0.7f) else Border, RoundedCornerShape(5.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        UiText(label, color = if (!enabled) TextMuted.copy(alpha = 0.4f) else if (selected) color else TextMain, size = 10, weight = FontWeight.SemiBold)
    }
}

@Composable
private fun MenuLine(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(5.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        UiText(title, color = TextMain, size = 12, weight = FontWeight.Medium)
        subtitle?.let { UiText(it, color = TextMuted, size = 9) }
    }
}

@Composable
private fun Pill(label: String, color: Color) {
    Box(Modifier.background(color.copy(alpha = 0.14f), RoundedCornerShape(30.dp)).border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(30.dp)).padding(horizontal = 8.dp, vertical = 5.dp)) {
        UiText(label, color = color, size = 9, weight = FontWeight.Bold)
    }
}

@Composable
private fun PropertyField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        UiText(label.uppercase(), color = TextMuted, size = 8, weight = FontWeight.Bold)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(5.dp)).border(1.dp, Border, RoundedCornerShape(5.dp)).padding(horizontal = 8.dp, vertical = 7.dp),
            singleLine = true,
            textStyle = TextStyle(color = TextMain, fontSize = 11.sp),
        )
    }
}

@Composable
private fun NumberField(label: String, value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf(formatFloat(value)) }
    LaunchedEffect(value) {
        val parsed = text.toFloatOrNull()
        if (parsed == null || abs(parsed - value) > 0.0001f) text = formatFloat(value)
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        UiText(label.uppercase(), color = TextMuted, size = 8, weight = FontWeight.Bold)
        BasicTextField(
            value = text,
            onValueChange = { next ->
                text = next
                next.toFloatOrNull()?.let(onChange)
            },
            modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(5.dp)).border(1.dp, Border, RoundedCornerShape(5.dp)).padding(horizontal = 8.dp, vertical = 7.dp),
            singleLine = true,
            textStyle = TextStyle(color = TextMain, fontSize = 11.sp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        )
    }
}

@Composable
private fun ToggleLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.clickable { onChange(!checked) }) {
        Box(Modifier.size(14.dp).clip(RoundedCornerShape(4.dp)).background(if (checked) Accent else Panel2).border(1.dp, if (checked) Accent else Border, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
            if (checked) UiText("✓", color = Color(0xFF062117), size = 10, weight = FontWeight.Bold)
        }
        UiText(label, color = TextMuted, size = 9)
    }
}

@Composable
private fun StudioDialog(title: String, onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.92f).background(Panel, RoundedCornerShape(6.dp)).border(1.dp, Border, RoundedCornerShape(6.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                UiText(title, color = TextMain, size = 16, weight = FontWeight.Bold)
                StudioButton("✕", onClick = onDismiss)
            }
            content()
        }
    }
}

@Composable
private fun UiText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = TextMain,
    size: Int = 12,
    weight: FontWeight = FontWeight.Normal,
) {
    BasicText(text, modifier = modifier, style = TextStyle(color = color, fontSize = size.sp, fontWeight = weight))
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun parseHex(value: String): Color = runCatching { Color(android.graphics.Color.parseColor(value)) }.getOrElse { Accent }
private fun formatFloat(value: Float): String = if (value % 1f == 0f) value.toInt().toString() else "%.2f".format(value)
private fun formatBytes(size: Long): String = when {
    size < 1024 -> "$size B"
    size < 1024 * 1024 -> "${size / 1024} KB"
    else -> "${size / (1024 * 1024)} MB"
}
