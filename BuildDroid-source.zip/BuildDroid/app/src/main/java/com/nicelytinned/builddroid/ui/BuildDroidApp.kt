package com.nicelytinned.builddroid.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.ViewQuilt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.nicelytinned.builddroid.github.BuildCoordinator
import com.nicelytinned.builddroid.github.GitHubTokenStore
import com.nicelytinned.builddroid.lua.LuaEngine
import com.nicelytinned.builddroid.model.BuildDroidProject
import com.nicelytinned.builddroid.model.ProjectItem
import com.nicelytinned.builddroid.storage.ProjectStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private val Bg = Color(0xFF10141B)
private val Panel = Color(0xFF1B222D)
private val PanelAlt = Color(0xFF222C39)
private val Accent = Color(0xFF55D6A0)
private val Muted = Color(0xFF9AA8BA)
private val CodeGreen = Color(0xFF9BE6BF)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuildDroidApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tokenStore = remember { GitHubTokenStore(context) }
    val buildCoordinator = remember { BuildCoordinator(context) }

    var project by remember { mutableStateOf(BuildDroidProject()) }
    var selectedTab by remember { mutableStateOf(EditorTab.EDIT) }
    var selectedItemId by remember { mutableStateOf(project.items.firstOrNull()?.id) }
    var isPlaytest by remember { mutableStateOf(false) }
    var isFileMenuExpanded by remember { mutableStateOf(false) }
    var showTokenDialog by remember { mutableStateOf(false) }
    var showProjectDialog by remember { mutableStateOf(false) }
    var tokenDraft by remember { mutableStateOf("") }
    var projectNameDraft by remember { mutableStateOf(project.name) }
    var isBuilding by remember { mutableStateOf(false) }
    var buildStatus by remember { mutableStateOf("Ready. Create something small first.") }
    var luaLog by remember { mutableStateOf("Run the Lua test to see output here.") }
    var tokenAlreadySaved by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        ProjectStorage.load(context)?.let { loaded ->
            project = loaded
            selectedItemId = loaded.items.firstOrNull()?.id
        }
        tokenAlreadySaved = tokenStore.hasToken()
    }

    fun saveProject() {
        scope.launch {
            runCatching { ProjectStorage.save(context, project) }
                .onSuccess { buildStatus = "Saved ${project.name}." }
                .onFailure { buildStatus = "Save failed: ${it.message}" }
        }
    }

    fun runLuaTest() {
        scope.launch {
            buildStatus = "Running Lua 5.1 test…"
            val snapshot = project.script
            runCatching { withContext(Dispatchers.Default) { LuaEngine.runPreflight(snapshot) } }
                .onSuccess { result ->
                    luaLog = result.log.ifBlank { "Lua ran successfully. No log messages." }
                    buildStatus = "Lua test passed: ${result.instanceCount} instance(s), scene ${result.sceneName}."
                }
                .onFailure { error ->
                    luaLog = error.message ?: "Lua test failed."
                    buildStatus = "Lua test failed."
                }
        }
    }

    fun startBuild() {
        val token = tokenStore.read()
        if (token.isNullOrBlank()) {
            tokenDraft = ""
            showTokenDialog = true
            buildStatus = "Add a GitHub token before starting a cloud build."
            return
        }
        val projectSnapshot = project
        scope.launch {
            isBuilding = true
            buildStatus = "Preparing cloud build…"
            try {
                val result = buildCoordinator.build(projectSnapshot, token) { message ->
                    buildStatus = message
                }
                buildStatus = "APK ready: ${result.apk.absolutePath}"
                luaLog = result.luaLog.ifBlank { "Lua preflight passed." }
            } catch (error: Throwable) {
                buildStatus = "Build failed: ${error.message ?: error.javaClass.simpleName}"
            } finally {
                isBuilding = false
            }
        }
    }

    val colorScheme = darkColorScheme(
        primary = Accent,
        onPrimary = Color(0xFF062117),
        secondary = Color(0xFF7AB6FF),
        background = Bg,
        surface = Panel,
        onBackground = Color(0xFFEAF0F7),
        onSurface = Color(0xFFEAF0F7),
    )

    MaterialTheme(colorScheme = colorScheme) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("BuildDroid", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("NicelyTinned · ${project.name}", color = Muted, fontSize = 11.sp)
                        }
                    },
                    actions = {
                        Box {
                            TextButton(onClick = { isFileMenuExpanded = true }) {
                                Text("File  ▾", color = Accent)
                            }
                            DropdownMenu(
                                expanded = isFileMenuExpanded,
                                onDismissRequest = { isFileMenuExpanded = false },
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Save project") },
                                    leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Save, null) },
                                    onClick = { isFileMenuExpanded = false; saveProject() },
                                )
                                DropdownMenuItem(
                                    text = { Text("Project details") },
                                    onClick = {
                                        isFileMenuExpanded = false
                                        projectNameDraft = project.name
                                        showProjectDialog = true
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("GitHub token") },
                                    onClick = {
                                        isFileMenuExpanded = false
                                        tokenDraft = ""
                                        showTokenDialog = true
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text(if (isBuilding) "Building…" else "Build APK with Actions") },
                                    enabled = !isBuilding,
                                    onClick = { isFileMenuExpanded = false; startBuild() },
                                )
                            }
                        }
                    },
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(
                        selected = selectedTab == EditorTab.EDIT,
                        onClick = { selectedTab = EditorTab.EDIT },
                        icon = { androidx.compose.material3.Icon(Icons.Default.ViewQuilt, null) },
                        label = { Text("Preview / Edit") },
                    )
                    NavigationBarItem(
                        selected = selectedTab == EditorTab.EXPLORER,
                        onClick = { selectedTab = EditorTab.EXPLORER },
                        icon = { androidx.compose.material3.Icon(Icons.Default.FolderOpen, null) },
                        label = { Text("Explorer") },
                    )
                    NavigationBarItem(
                        selected = selectedTab == EditorTab.SCRIPT,
                        onClick = { selectedTab = EditorTab.SCRIPT },
                        icon = { androidx.compose.material3.Icon(Icons.Default.Code, null) },
                        label = { Text("Script") },
                    )
                }
            },
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (selectedTab) {
                    EditorTab.EDIT -> EditPanel(
                        project = project,
                        isPlaytest = isPlaytest,
                        onTogglePlaytest = { isPlaytest = !isPlaytest },
                        onAddObject = {
                            val newItem = ProjectItem(
                                id = UUID.randomUUID().toString(),
                                name = "Object${project.items.size + 1}",
                                x = 90f + (project.items.size * 18f),
                                y = 80f + (project.items.size * 14f),
                            )
                            project = project.copy(items = project.items + newItem)
                            selectedItemId = newItem.id
                        },
                        onAddUi = {
                            val newItem = ProjectItem(
                                id = UUID.randomUUID().toString(),
                                name = "Button${project.items.size + 1}",
                                kind = "UI Element",
                                x = 60f + (project.items.size * 12f),
                                y = 180f + (project.items.size * 8f),
                                width = 110f,
                                height = 42f,
                            )
                            project = project.copy(items = project.items + newItem)
                            selectedItemId = newItem.id
                        },
                    )
                    EditorTab.EXPLORER -> ExplorerPanel(
                        project = project,
                        selectedItemId = selectedItemId,
                        onSelectItem = { selectedItemId = it },
                        onDeleteItem = { id ->
                            project = project.copy(items = project.items.filterNot { it.id == id })
                            selectedItemId = project.items.firstOrNull()?.id
                        },
                        onRenameItem = { id, name ->
                            project = project.copy(items = project.items.map { if (it.id == id) it.copy(name = name) else it })
                        },
                        onPositionItem = { id, x, y ->
                            project = project.copy(items = project.items.map { if (it.id == id) it.copy(x = x, y = y) else it })
                        },
                    )
                    EditorTab.SCRIPT -> ScriptPanel(
                        script = project.script,
                        log = luaLog,
                        onScriptChange = { project = project.copy(script = it) },
                        onRunTest = ::runLuaTest,
                    )
                }
                StatusBar(status = buildStatus, isBuilding = isBuilding)
            }
        }
    }

    if (showProjectDialog) {
        AlertDialog(
            onDismissRequest = { showProjectDialog = false },
            title = { Text("Project details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Project name", color = Muted)
                    OutlinedTextField(
                        value = projectNameDraft,
                        onValueChange = { projectNameDraft = it },
                        singleLine = true,
                        placeholder = { Text("My Game") },
                    )
                    Text("GitHub repository: ${projectNameDraft.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "builddroid-project" }}", color = Muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    project = project.copy(name = projectNameDraft.trim().ifBlank { "My Game" })
                    showProjectDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showProjectDialog = false }) { Text("Cancel") } },
        )
    }

    if (showTokenDialog) {
        AlertDialog(
            onDismissRequest = { showTokenDialog = false },
            title = { Text("GitHub token") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (tokenAlreadySaved) "A token is already saved securely. Enter a replacement, or leave this blank to keep it."
                        else "Paste a GitHub fine-grained personal access token. BuildDroid encrypts it with Android Keystore.",
                        color = Muted,
                    )
                    OutlinedTextField(
                        value = tokenDraft,
                        onValueChange = { tokenDraft = it },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        placeholder = { Text("github_pat_…") },
                    )
                    Text(
                        "Permissions: Repository creation (write), Contents (read/write), Workflows (write), Actions (read/write). For automatic repository creation, choose All repositories; keep the permissions above narrowly scoped.",
                        color = Muted,
                        fontSize = 11.sp,
                    )
                    if (tokenAlreadySaved) {
                        TextButton(onClick = {
                            tokenStore.clear()
                            tokenAlreadySaved = false
                            showTokenDialog = false
                            buildStatus = "Saved GitHub token removed."
                        }) { Text("Remove saved token", color = Color(0xFFFF9C9C)) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (tokenDraft.isNotBlank()) {
                        runCatching { tokenStore.save(tokenDraft.trim()) }
                            .onSuccess {
                                tokenAlreadySaved = true
                                showTokenDialog = false
                                tokenDraft = ""
                                buildStatus = "GitHub token encrypted and saved on this device."
                            }
                            .onFailure { buildStatus = "Could not save token: ${it.message}" }
                    } else {
                        showTokenDialog = false
                    }
                }) { Text("Save token") }
            },
            dismissButton = { TextButton(onClick = { showTokenDialog = false }) { Text("Cancel") } },
        )
    }
}

private enum class EditorTab { EDIT, EXPLORER, SCRIPT }

@Composable
private fun EditPanel(
    project: BuildDroidProject,
    isPlaytest: Boolean,
    onTogglePlaytest: () -> Unit,
    onAddObject: () -> Unit,
    onAddUi: () -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(if (isPlaytest) "Playtest" else "Scene editor", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Text("MainScene · ${project.items.size} instance(s)", color = Muted, fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = onAddObject) { Text("+ Object") }
                OutlinedButton(onClick = onAddUi) { Text("+ UI") }
                Button(onClick = onTogglePlaytest) {
                    androidx.compose.material3.Icon(Icons.Default.PlayArrow, null, Modifier.size(17.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (isPlaytest) "Stop" else "Playtest")
                }
            }
        }
        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(18.dp),
        ) {
            Box(Modifier.fillMaxSize().padding(10.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().background(Color(0xFF151C26), RoundedCornerShape(12.dp))) {
                    val grid = 32.dp.toPx()
                    var x = 0f
                    while (x < size.width) {
                        drawLine(Color(0xFF253142), Offset(x, 0f), Offset(x, size.height), 1f)
                        x += grid
                    }
                    var y = 0f
                    while (y < size.height) {
                        drawLine(Color(0xFF253142), Offset(0f, y), Offset(size.width, y), 1f)
                        y += grid
                    }
                    drawRect(Color(0xFF354458), topLeft = Offset(8f, 8f), size = Size(size.width - 16f, size.height - 16f), style = Stroke(width = 2f))
                    project.items.forEachIndexed { index, item ->
                        val left = item.x.dp.toPx().coerceAtMost(size.width - 40f)
                        val top = item.y.dp.toPx().coerceAtMost(size.height - 40f)
                        val width = item.width.dp.toPx().coerceAtMost(size.width - left - 8f)
                        val height = item.height.dp.toPx().coerceAtMost(size.height - top - 8f)
                        val color = if (index % 2 == 0) Accent else Color(0xFF79B4FF)
                        drawRoundRect(color.copy(alpha = 0.9f), topLeft = Offset(left, top), size = Size(width.coerceAtLeast(16f), height.coerceAtLeast(16f)), cornerRadius = androidx.compose.ui.geometry.CornerRadius(9f, 9f))
                    }
                }
                if (isPlaytest) {
                    Surface(
                        color = Color(0xCC101820),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
                    ) { Text("LIVE PREVIEW · sample renderer", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Accent, fontSize = 11.sp) }
                }
            }
        }
        Text("Add scene objects and UI elements here; rename and position them in Explorer. Touch-drag editing is planned for the next increment.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ExplorerPanel(
    project: BuildDroidProject,
    selectedItemId: String?,
    onSelectItem: (String) -> Unit,
    onDeleteItem: (String) -> Unit,
    onRenameItem: (String, String) -> Unit,
    onPositionItem: (String, Float, Float) -> Unit,
) {
    val selected = project.items.firstOrNull { it.id == selectedItemId }
    var renameDraft by remember(selectedItemId, selected?.name) { mutableStateOf(selected?.name.orEmpty()) }
    var xDraft by remember(selectedItemId, selected?.x) { mutableStateOf(selected?.x?.toInt()?.toString().orEmpty()) }
    var yDraft by remember(selectedItemId, selected?.y) { mutableStateOf(selected?.y?.toInt()?.toString().orEmpty()) }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Explorer", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
                item { ExplorerHeader("Scenes") }
                item { ExplorerRow("▣", "MainScene", false, null, {}) }
                item { ExplorerHeader("Instances") }
                items(project.items, key = { it.id }) { item ->
                    ExplorerRow(
                        symbol = "◇",
                        title = item.name,
                        selected = item.id == selectedItemId,
                        subtitle = "${item.kind} instance · x ${item.x.toInt()}, y ${item.y.toInt()}",
                        onClick = { onSelectItem(item.id) },
                    )
                }
                item { ExplorerHeader("Resources") }
                item { ExplorerRow("▧", "Sprites", false, "Coming soon", {}) }
                item { ExplorerRow("♫", "Sounds", false, "Coming soon", {}) }
                item { ExplorerRow("{ }", "Scripts", false, "main.lua", {}) }
            }
        }
        if (selected != null) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Properties", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = renameDraft,
                        onValueChange = { renameDraft = it },
                        label = { Text("Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = xDraft, onValueChange = { xDraft = it }, label = { Text("X") },
                            singleLine = true, modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = yDraft, onValueChange = { yDraft = it }, label = { Text("Y") },
                            singleLine = true, modifier = Modifier.weight(1f),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            onRenameItem(selected.id, renameDraft.trim().ifBlank { selected.name })
                            val nextX = xDraft.toFloatOrNull()
                            val nextY = yDraft.toFloatOrNull()
                            if (nextX != null || nextY != null) {
                                // Position is applied through the same selected-instance model.
                                onPositionItem(selected.id, nextX ?: selected.x, nextY ?: selected.y)
                            }
                        }) { Text("Apply") }
                        OutlinedButton(onClick = { onDeleteItem(selected.id) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExplorerHeader(title: String) {
    Text(title.uppercase(), color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 5.dp))
}

@Composable
private fun ExplorerRow(
    symbol: String,
    title: String,
    selected: Boolean,
    subtitle: String?,
    onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) Color(0xFF263849) else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(symbol, color = if (selected) Accent else Color(0xFF83A7C8), fontFamily = FontFamily.Monospace, modifier = Modifier.width(30.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, color = Color(0xFFEAF0F7))
            subtitle?.let { Text(it, fontSize = 10.sp, color = Muted) }
        }
    }
}

@Composable
private fun ScriptPanel(
    script: String,
    log: String,
    onScriptChange: (String) -> Unit,
    onRunTest: () -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Lua 5.1", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("main.lua · Game API smoke test", color = Muted, fontSize = 11.sp)
            }
            Button(onClick = onRunTest) { Text("Run Lua Test") }
        }
        OutlinedTextField(
            value = script,
            onValueChange = onScriptChange,
            modifier = Modifier.fillMaxWidth().weight(1f),
            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = CodeGreen, lineHeight = 19.sp),
            shape = RoundedCornerShape(12.dp),
            placeholder = { Text("-- write Lua here") },
        )
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Output", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(log, color = Muted, fontFamily = FontFamily.Monospace, fontSize = 11.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun StatusBar(status: String, isBuilding: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(PanelAlt).padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.size(7.dp).background(if (isBuilding) Color(0xFFFFC66D) else Accent, RoundedCornerShape(50)))
        Text(status, color = Muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
