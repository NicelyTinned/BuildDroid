package com.nicelytinned.builddroid.lua

import party.iroiro.luajava.lua51.Lua51

/**
 * First-pass BuildDroid Lua 5.1 bridge.
 * This is a small smoke-test API, not yet a complete or hardened game runtime.
 */
object LuaEngine {
    private val bootstrap = """
        Game = {
            logs = {},
            instances = {},
            current_scene = "MainScene"
        }

        function Game.log(message)
            table.insert(Game.logs, tostring(message))
        end

        function Game.instance_create(object_name, x, y)
            local id = #Game.instances + 1
            Game.instances[id] = {
                id = id,
                object = tostring(object_name),
                x = tonumber(x) or 0,
                y = tonumber(y) or 0
            }
            Game.log("Created " .. tostring(object_name) .. " #" .. tostring(id))
            return id
        end

        function Game.instance_count()
            return #Game.instances
        end

        function Game.instance_get(id)
            return Game.instances[tonumber(id)]
        end

        function Game.keyboard_check(_key)
            return false
        end

        function Game.scene_name()
            return Game.current_scene
        end

        -- GameMaker-inspired convenience aliases.
        function instance_create(object_name, x, y)
            return Game.instance_create(object_name, x, y)
        end

        function keyboard_check(key)
            return Game.keyboard_check(key)
        end

        function show_debug_message(message)
            Game.log(message)
        end

        function print(...)
            local parts = {}
            for index = 1, select("#", ...) do
                parts[index] = tostring(select(index, ...))
            end
            Game.log(table.concat(parts, " "))
        end

        -- Bound accidental infinite loops in editor preflight runs.
        local __builddroid_instructions = 0
        if debug and debug.sethook then
            debug.sethook(function()
                __builddroid_instructions = __builddroid_instructions + 1
                if __builddroid_instructions > 100 then
                    error("BuildDroid Lua instruction budget exceeded")
                end
            end, "", 10000)
        end

        -- Do not expose Java, filesystem, process, package, or debug access to project scripts.
        java = nil
        luajava = nil
        io = nil
        os = nil
        package = nil
        debug = nil
        require = nil
        dofile = nil
        loadfile = nil
        loadstring = nil
        collectgarbage = nil
    """.trimIndent()

    data class TestResult(
        val log: String,
        val instanceCount: Int,
        val sceneName: String,
    )

    fun runPreflight(source: String): TestResult {
        val lua = Lua51()
        try {
            lua.openLibraries()
            // Re-apply the sandbox after standard libraries have been loaded.
            lua.run(bootstrap)
            lua.run(source)
            val log = lua.eval("return table.concat(Game.logs, '\\n')")
                .firstOrNull()?.toString().orEmpty()
            val count = lua.eval("return Game.instance_count()")
                .firstOrNull()?.toInteger()?.toInt() ?: 0
            val scene = lua.eval("return Game.scene_name()")
                .firstOrNull()?.toString().orEmpty()
            return TestResult(log = log, instanceCount = count, sceneName = scene)
        } finally {
            lua.close()
        }
    }
}
