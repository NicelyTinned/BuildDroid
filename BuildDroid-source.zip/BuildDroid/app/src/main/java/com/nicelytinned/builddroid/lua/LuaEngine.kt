package com.nicelytinned.builddroid.lua

import com.nicelytinned.builddroid.model.BuildDroidProject
import com.nicelytinned.builddroid.model.GameObjectDefinition
import com.nicelytinned.builddroid.model.ProjectItem
import com.nicelytinned.builddroid.model.ScriptDocument
import party.iroiro.luajava.JFunction
import party.iroiro.luajava.Lua
import party.iroiro.luajava.lua51.Lua51
import java.io.Closeable
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** A small but live 2D runtime. All methods must be called on one worker thread. */
class LuaGameRuntime(private val project: BuildDroidProject) : Closeable {
    private data class RuntimeInstance(
        val id: Int,
        val objectId: String,
        var objectName: String,
        var x: Float,
        var y: Float,
        var width: Float,
        var height: Float,
        var rotation: Float,
        var depth: Int,
        var velocityX: Float,
        var velocityY: Float,
        var gravity: Float,
        var bounce: Float,
        var color: String,
        var visible: Boolean,
        var alpha: Float,
        var text: String,
        var spriteAssetId: String?,
        var collisionEnabled: Boolean,
        var scaleX: Float,
        var scaleY: Float,
        val variables: MutableMap<String, String>,
    )

    data class Snapshot(
        val id: Int,
        val objectId: String,
        val objectName: String,
        val x: Float,
        val y: Float,
        val width: Float,
        val height: Float,
        val rotation: Float,
        val depth: Int,
        val color: String,
        val visible: Boolean,
        val alpha: Float,
        val text: String,
        val spriteAssetId: String?,
    )

    data class Frame(
        val instances: List<Snapshot>,
        val logs: List<String>,
        val timeSeconds: Float,
        val error: String? = null,
    )

    private val lua = Lua51()
    private val objectDefinitions = project.objects.associateBy { it.name }
    private val instances = mutableListOf<RuntimeInstance>()
    private val instancesById = HashMap<Int, RuntimeInstance>()
    private val logs = mutableListOf<String>()
    private val pressedKeys = mutableSetOf<String>()
    private val scriptFunctions = mutableMapOf<Pair<String, String>, MutableList<String>>()
    private val pendingCreate = mutableListOf<RuntimeInstance>()
    private val pendingDestroy = linkedSetOf<Int>()
    private val justPressedKeys = linkedSetOf<String>()
    private val justReleasedKeys = linkedSetOf<String>()
    private var nextInstanceId = 1
    private var elapsed = 0f
    private var lastDeltaSeconds = 1f / 60f
    private var lastError: String? = null
    private var activeOtherId: Int? = null
    private var pointerX = 0f
    private var pointerY = 0f
    private var pointerDown = false
    private var pointerPressed = false
    private var pointerReleased = false

    init {
        lua.openLibraries()
        lua.run(HOOK_SETUP)
        registerGameApi()
        lua.run(SANDBOX)
        project.currentScene.instances.forEach { source ->
            val definition = project.objects.firstOrNull { it.id == source.objectId }
            val instance = source.toRuntime(nextInstanceId++, definition)
            instances += instance
            instancesById[instance.id] = instance
        }
        compileEventFunctions()
        runGlobalScripts()
        instances.toList().forEach { runEvents(it, "Create", 0f) }
        drainCreatedInstances()
        drainDestroyedInstances()
    }

    fun setKeys(keys: Set<String>) {
        val normalized = keys.map { it.lowercase() }.toSet()
        justPressedKeys.clear()
        justPressedKeys.addAll(normalized - pressedKeys)
        justReleasedKeys.clear()
        justReleasedKeys.addAll(pressedKeys - normalized)
        pressedKeys.clear()
        pressedKeys.addAll(normalized)
    }

    fun setKey(key: String, pressed: Boolean) {
        val normalized = key.lowercase()
        if (pressed && pressedKeys.add(normalized)) justPressedKeys += normalized
        if (!pressed && pressedKeys.remove(normalized)) justReleasedKeys += normalized
    }

    fun setPointer(x: Float, y: Float, pressed: Boolean) {
        pointerX = x
        pointerY = y
        if (pressed && !pointerDown) pointerPressed = true
        if (!pressed && pointerDown) pointerReleased = true
        pointerDown = pressed
    }

    fun moveInstance(id: Int, x: Float, y: Float) {
        find(id)?.let { it.x = x; it.y = y }
    }

    fun tick(deltaSeconds: Float, captureFrame: Boolean = true): Frame {
        if (lastError != null) return if (captureFrame) snapshot() else emptyFrame()
        val dt = deltaSeconds.coerceIn(0f, 0.05f)
        lastDeltaSeconds = dt
        elapsed += dt
        return try {
            // Instances created during Step are queued for Create and begin stepping next frame.
            // Destroyed instances are only removed after this loop, so no defensive O(n²) scan is needed.
            val frameInstanceCount = instances.size
            var index = 0
            while (index < frameInstanceCount) {
                val instance = instances[index]
                runEvents(instance, "Step", dt)
                instance.velocityY += instance.gravity * dt
                instance.x += instance.velocityX * dt
                instance.y += instance.velocityY * dt
                index++
            }
            drainCreatedInstances()
            drainDestroyedInstances()
            resolveSceneBounds()
            resolveCollisions()
            drainDestroyedInstances()
            justPressedKeys.clear()
            justReleasedKeys.clear()
            pointerPressed = false
            pointerReleased = false
            if (captureFrame) snapshot() else emptyFrame()
        } catch (error: Throwable) {
            lastError = error.message ?: error.javaClass.simpleName
            if (captureFrame) snapshot() else emptyFrame()
        }
    }

    private fun emptyFrame() = Frame(
        instances = emptyList(),
        logs = emptyList(),
        timeSeconds = elapsed,
        error = lastError,
    )

    fun snapshot(): Frame = Frame(
        instances = instances.sortedByDescending { it.y }.map {
            Snapshot(it.id, it.objectId, it.objectName, it.x, it.y, it.width * it.scaleX, it.height * it.scaleY, it.rotation, it.depth, it.color, it.visible, it.alpha, it.text, it.spriteAssetId)
        },
        logs = logs.takeLast(100).toList(),
        timeSeconds = elapsed,
        error = lastError,
    )

    override fun close() {
        lua.close()
    }

    private fun registerGameApi() {
        lua.createTable(0, 24)
        fun function(name: String, body: (Lua) -> Int) {
            lua.push(JFunction { state ->
                try {
                    body(state)
                } catch (error: Throwable) {
                    state.push(error.message ?: "BuildDroid API error")
                    -1
                }
            })
            lua.setField(-2, name)
        }
        function("log") { state -> logs += state.toString(1).orEmpty(); 0 }
        function("scene_name") { state -> state.push(project.currentScene.name); 1 }
        function("time") { state -> state.push(elapsed.toDouble()); 1 }
        function("delta_time") { state ->
            val delta = if (state.getTop() >= 1) state.toNumber(1).toFloat() else lastDeltaSeconds
            state.push(delta.toDouble()); 1
        }
        function("random") { state ->
            val low = if (state.getTop() >= 1) state.toNumber(1).toFloat() else 0f
            val high = if (state.getTop() >= 2) state.toNumber(2).toFloat() else 1f
            state.push((Random.nextFloat() * (high - low) + low).toDouble()); 1
        }
        function("instance_create") { state ->
            val name = state.toString(1).orEmpty().ifBlank { "Object" }
            val x = state.toNumber(2).toFloat()
            val y = state.toNumber(3).toFloat()
            val created = createInstance(name, x, y)
            state.push(created.id.toLong()); 1
        }
        function("instance_count") { state ->
            val filter = state.toString(1)
            state.push(instances.count { filter.isNullOrBlank() || it.objectName == filter }.toLong()); 1
        }
        function("instance_get") { state ->
            val item = instances.firstOrNull { it.id == state.toNumber(1).toInt() }
            if (item == null) state.pushNil() else pushInstanceTable(state, item)
            1
        }
        function("destroy") { state -> pendingDestroy += state.toNumber(1).toInt(); 0 }
        function("instance_exists") { state -> state.push(find(state.toNumber(1).toInt()) != null); 1 }
        function("set_position") { state ->
            find(state.toNumber(1).toInt())?.let { it.x = state.toNumber(2).toFloat(); it.y = state.toNumber(3).toFloat() }; 0
        }
        function("move") { state ->
            find(state.toNumber(1).toInt())?.let { it.x += state.toNumber(2).toFloat(); it.y += state.toNumber(3).toFloat() }; 0
        }
        function("set_velocity") { state ->
            find(state.toNumber(1).toInt())?.let { it.velocityX = state.toNumber(2).toFloat(); it.velocityY = state.toNumber(3).toFloat() }; 0
        }
        function("set_size") { state ->
            find(state.toNumber(1).toInt())?.let { it.width = state.toNumber(2).toFloat().coerceAtLeast(1f); it.height = state.toNumber(3).toFloat().coerceAtLeast(1f) }; 0
        }
        function("set_scale") { state ->
            find(state.toNumber(1).toInt())?.let { it.scaleX = state.toNumber(2).toFloat().coerceAtLeast(0.01f); it.scaleY = if (state.getTop() >= 3) state.toNumber(3).toFloat().coerceAtLeast(0.01f) else it.scaleX }; 0
        }
        function("set_depth") { state -> find(state.toNumber(1).toInt())?.depth = state.toNumber(2).toInt(); 0 }
        function("set_gravity") { state -> find(state.toNumber(1).toInt())?.gravity = state.toNumber(2).toFloat(); 0 }
        function("set_bounce") { state -> find(state.toNumber(1).toInt())?.bounce = state.toNumber(2).toFloat().coerceIn(0f, 1f); 0 }
        function("set_collision") { state -> find(state.toNumber(1).toInt())?.collisionEnabled = state.toBoolean(2); 0 }
        function("get_x") { state -> state.push((find(state.toNumber(1).toInt())?.x ?: 0f).toDouble()); 1 }
        function("get_y") { state -> state.push((find(state.toNumber(1).toInt())?.y ?: 0f).toDouble()); 1 }
        function("set_color") { state -> find(state.toNumber(1).toInt())?.color = state.toString(2) ?: "#55D6A0"; 0 }
        function("set_visible") { state -> find(state.toNumber(1).toInt())?.visible = state.toBoolean(2); 0 }
        function("set_alpha") { state -> find(state.toNumber(1).toInt())?.alpha = state.toNumber(2).toFloat().coerceIn(0f, 1f); 0 }
        function("set_rotation") { state -> find(state.toNumber(1).toInt())?.rotation = state.toNumber(2).toFloat(); 0 }
        function("set_text") { state -> find(state.toNumber(1).toInt())?.text = state.toString(2).orEmpty(); 0 }
        function("keyboard_check") { state -> state.push(pressedKeys.contains(state.toString(1).orEmpty().lowercase())); 1 }
        function("keyboard_check_pressed") { state -> state.push(justPressedKeys.contains(state.toString(1).orEmpty().lowercase())); 1 }
        function("keyboard_check_released") { state -> state.push(justReleasedKeys.contains(state.toString(1).orEmpty().lowercase())); 1 }
        function("mouse_x") { state -> state.push(pointerX.toDouble()); 1 }
        function("mouse_y") { state -> state.push(pointerY.toDouble()); 1 }
        function("mouse_check_button") { state -> state.push(pointerDown); 1 }
        function("mouse_check_button_pressed") { state -> state.push(pointerPressed); 1 }
        function("mouse_check_button_released") { state -> state.push(pointerReleased); 1 }
        function("room_width") { state -> state.push(project.currentScene.width.toLong()); 1 }
        function("room_height") { state -> state.push(project.currentScene.height.toLong()); 1 }
        function("distance") { state ->
            val dx = state.toNumber(3) - state.toNumber(1)
            val dy = state.toNumber(4) - state.toNumber(2)
            state.push(kotlin.math.sqrt(dx * dx + dy * dy)); 1
        }
        function("collides") { state ->
            val first = find(state.toNumber(1).toInt()); val second = find(state.toNumber(2).toInt())
            state.push(first != null && second != null && intersects(first, second)); 1
        }
        function("find") { state ->
            val name = state.toString(1).orEmpty()
            val found = instances.firstOrNull { it.objectName == name }
            if (found == null) state.pushNil() else state.push(found.id.toLong())
            1
        }
        function("instance_find") { state ->
            val name = state.toString(1).orEmpty()
            val index = (state.toNumber(2).toInt().coerceAtLeast(0))
            val found = instances.asSequence().filter { it.objectName == name }.drop(index).firstOrNull()
            if (found == null) state.pushNil() else state.push(found.id.toLong())
            1
        }
        function("instance_nearest") { state ->
            val x = state.toNumber(1).toFloat(); val y = state.toNumber(2).toFloat()
            val name = state.toString(3)
            val found = instances.asSequence().filter { name.isNullOrBlank() || it.objectName == name }
                .minByOrNull { item -> (item.x - x) * (item.x - x) + (item.y - y) * (item.y - y) }
            if (found == null) state.pushNil() else state.push(found.id.toLong())
            1
        }
        function("object_exists") { state -> state.push(objectDefinitions.containsKey(state.toString(1).orEmpty())); 1 }
        function("set_variable") { state ->
            find(state.toNumber(1).toInt())?.variables?.set(state.toString(2).orEmpty(), state.toString(3).orEmpty()); 0
        }
        function("get_variable") { state ->
            val value = find(state.toNumber(1).toInt())?.variables?.get(state.toString(2).orEmpty())
            if (value == null) state.pushNil() else state.push(value)
            1
        }
        function("get_velocity_x") { state -> state.push((find(state.toNumber(1).toInt())?.velocityX ?: 0f).toDouble()); 1 }
        function("get_velocity_y") { state -> state.push((find(state.toNumber(1).toInt())?.velocityY ?: 0f).toDouble()); 1 }
        function("get_alpha") { state -> state.push((find(state.toNumber(1).toInt())?.alpha ?: 1f).toDouble()); 1 }
        function("get_depth") { state -> state.push((find(state.toNumber(1).toInt())?.depth ?: 0).toLong()); 1 }
        function("other") { state -> activeOtherId?.let { state.push(it.toLong()) } ?: state.pushNil(); 1 }
        function("clamp") { state -> state.push(state.toNumber(1).coerceIn(state.toNumber(2), state.toNumber(3))); 1 }
        function("lerp") { state ->
            val start = state.toNumber(1); val finish = state.toNumber(2); val amount = state.toNumber(3).coerceIn(0.0, 1.0)
            state.push(start + (finish - start) * amount); 1
        }
        function("sign") { state -> state.push(kotlin.math.sign(state.toNumber(1))); 1 }
        function("lengthdir_x") { state -> state.push(kotlin.math.cos(Math.toRadians(state.toNumber(2))) * state.toNumber(1)); 1 }
        function("lengthdir_y") { state -> state.push(-kotlin.math.sin(Math.toRadians(state.toNumber(2))) * state.toNumber(1)); 1 }
        function("point_in_rectangle") { state ->
            val px = state.toNumber(1); val py = state.toNumber(2)
            val left = state.toNumber(3); val top = state.toNumber(4); val right = state.toNumber(5); val bottom = state.toNumber(6)
            state.push(px >= left && px <= right && py >= top && py <= bottom); 1
        }
        function("point_in_circle") { state ->
            val dx = state.toNumber(1) - state.toNumber(3)
            val dy = state.toNumber(2) - state.toNumber(4)
            val radius = state.toNumber(5)
            state.push(dx * dx + dy * dy <= radius * radius); 1
        }
        function("get_width") { state -> state.push(((find(state.toNumber(1).toInt())?.let { it.width * it.scaleX }) ?: 0f).toDouble()); 1 }
        function("get_height") { state -> state.push(((find(state.toNumber(1).toInt())?.let { it.height * it.scaleY }) ?: 0f).toDouble()); 1 }
        function("get_rotation") { state -> state.push((find(state.toNumber(1).toInt())?.rotation ?: 0f).toDouble()); 1 }
        function("get_color") { state -> state.push(find(state.toNumber(1).toInt())?.color ?: "#55D6A0"); 1 }
        function("get_visible") { state -> state.push(find(state.toNumber(1).toInt())?.visible ?: false); 1 }
        function("get_text") { state -> state.push(find(state.toNumber(1).toInt())?.text.orEmpty()); 1 }
        function("get_scale_x") { state -> state.push((find(state.toNumber(1).toInt())?.scaleX ?: 1f).toDouble()); 1 }
        function("get_scale_y") { state -> state.push((find(state.toNumber(1).toInt())?.scaleY ?: 1f).toDouble()); 1 }
        function("get_gravity") { state -> state.push((find(state.toNumber(1).toInt())?.gravity ?: 0f).toDouble()); 1 }
        function("get_bounce") { state -> state.push((find(state.toNumber(1).toInt())?.bounce ?: 0f).toDouble()); 1 }
        function("get_collision") { state -> state.push(find(state.toNumber(1).toInt())?.collisionEnabled ?: false); 1 }
        function("set_name") { state -> find(state.toNumber(1).toInt())?.objectName = state.toString(2).orEmpty(); 0 }
        function("get_name") { state -> state.push(find(state.toNumber(1).toInt())?.objectName.orEmpty()); 1 }
        function("set_sprite") { state -> find(state.toNumber(1).toInt())?.spriteAssetId = state.toString(2); 0 }
        function("get_sprite") { state ->
            val sprite = find(state.toNumber(1).toInt())?.spriteAssetId
            if (sprite == null) state.pushNil() else state.push(sprite)
            1
        }
        lua.setGlobal("Game")
        lua.run(ALIASES)
        lua.run(LUA_CLASSES)
    }

    private fun pushInstanceTable(state: Lua, item: RuntimeInstance) {
        state.createTable(0, 24)
        state.push(item.id.toLong()); state.setField(-2, "id")
        state.push(item.objectName); state.setField(-2, "object")
        state.push(item.objectName); state.setField(-2, "name")
        state.push(item.objectId); state.setField(-2, "object_id")
        state.push(item.x.toDouble()); state.setField(-2, "x")
        state.push(item.y.toDouble()); state.setField(-2, "y")
        state.push((item.width * item.scaleX).toDouble()); state.setField(-2, "width")
        state.push((item.height * item.scaleY).toDouble()); state.setField(-2, "height")
        state.push(item.rotation.toDouble()); state.setField(-2, "rotation")
        state.push(item.color); state.setField(-2, "color")
        state.push(item.visible); state.setField(-2, "visible")
        state.push(item.depth.toLong()); state.setField(-2, "depth")
        state.push(item.velocityX.toDouble()); state.setField(-2, "velocity_x")
        state.push(item.velocityY.toDouble()); state.setField(-2, "velocity_y")
        state.push(item.alpha.toDouble()); state.setField(-2, "alpha")
        state.push(item.scaleX.toDouble()); state.setField(-2, "scale_x")
        state.push(item.scaleY.toDouble()); state.setField(-2, "scale_y")
        state.push(item.gravity.toDouble()); state.setField(-2, "gravity")
        state.push(item.bounce.toDouble()); state.setField(-2, "bounce")
        state.push(item.collisionEnabled); state.setField(-2, "collision")
        state.push(item.text); state.setField(-2, "text")
        val spriteAssetId = item.spriteAssetId
        if (spriteAssetId == null) state.pushNil() else state.push(spriteAssetId)
        state.setField(-2, "sprite")
        state.createTable(0, item.variables.size)
        item.variables.forEach { (key, value) -> state.push(value); state.setField(-2, key) }
        state.setField(-2, "variables")
    }

    private fun compileEventFunctions() {
        project.scripts.forEachIndexed { index, script ->
            if (script.targetObjectId == null || script.eventType == "Script") return@forEachIndexed
            val functionName = "__bd_event_$index"
            val prepared = LuaContinuePreprocessor.transform(script.source)
            lua.run("function $functionName(dt)\n$prepared\nend")
            val key = script.targetObjectId to script.eventType
            scriptFunctions.getOrPut(key) { mutableListOf() }.add(functionName)
        }
    }

    private fun runGlobalScripts() {
        project.scripts.filter { it.targetObjectId == null && it.eventType == "Script" }.forEach { script ->
            runScriptWithBudget(script.source, 450_000)
        }
        drainCreatedInstances()
    }

    private fun setInstructionBudget(instructions: Int) {
        lua.getGlobal("__bd_set_budget")
        lua.push(instructions.toLong())
        lua.pCall(1, 0)
    }

    private fun runScriptWithBudget(source: String, instructions: Int) {
        lua.load(LuaContinuePreprocessor.transform(source))
        setInstructionBudget(instructions)
        try {
            lua.pCall(0, 0)
        } finally {
            lua.setTop(0)
            setInstructionBudget(0)
        }
    }

    private fun runEvents(instance: RuntimeInstance, event: String, dt: Float, other: RuntimeInstance? = null) {
        val functions = scriptFunctions[instance.objectId to event].orEmpty()
        functions.forEach { functionName ->
            lua.set("self", instanceTable(instance))
            lua.set("other", other?.let(::instanceTable) ?: emptyMap<String, Any>())
            lua.set("delta_time", dt.toDouble())
            activeOtherId = other?.id
            setInstructionBudget(120_000)
            try {
                lua.getGlobal(functionName)
                lua.push(dt.toDouble())
                lua.pCall(1, 0)
            } finally {
                lua.setTop(0)
                setInstructionBudget(0)
                activeOtherId = null
            }
        }
    }

    private fun instanceTable(item: RuntimeInstance): Map<String, Any> = mapOf(
        "id" to item.id,
        "name" to item.objectName,
        "x" to item.x,
        "y" to item.y,
        "width" to item.width * item.scaleX,
        "height" to item.height * item.scaleY,
        "velocity_x" to item.velocityX,
        "velocity_y" to item.velocityY,
        "depth" to item.depth,
        "alpha" to item.alpha,
        "rotation" to item.rotation,
        "scale_x" to item.scaleX,
        "scale_y" to item.scaleY,
        "gravity" to item.gravity,
        "bounce" to item.bounce,
        "visible" to item.visible,
        "collision" to item.collisionEnabled,
        "color" to item.color,
        "text" to item.text,
    )

    private fun drainCreatedInstances() {
        var processed = 0
        while (pendingCreate.isNotEmpty() && processed < 512) {
            val pending = pendingCreate.removeAt(0)
            runEvents(pending, "Create", 0f)
            processed++
        }
        if (pendingCreate.isNotEmpty()) throw IllegalStateException("Create events spawned more than 512 instances in one frame")
    }

    private fun drainDestroyedInstances() {
        val ids = pendingDestroy.toList()
        pendingDestroy.clear()
        ids.forEach { id ->
            val instance = find(id) ?: return@forEach
            runEvents(instance, "Destroy", 0f)
            instances.removeAll { it.id == id }
            instancesById.remove(id)
        }
    }

    private fun createInstance(name: String, x: Float, y: Float): RuntimeInstance {
        val definition = objectDefinitions[name]
        val item = ProjectItem(
            objectId = definition?.id.orEmpty(), name = name, kind = definition?.type ?: "Rectangle",
            x = x, y = y,
            width = definition?.defaultWidth ?: 48f,
            height = definition?.defaultHeight ?: 48f,
            color = definition?.color ?: "#55D6A0",
            gravity = definition?.gravity ?: 0f,
            bounce = definition?.bounce ?: 0f,
        )
        return item.toRuntime(nextInstanceId++, definition).also {
            instances += it
            instancesById[it.id] = it
            pendingCreate += it
        }
    }

    private fun resolveSceneBounds() {
        val maxX = project.currentScene.width.toFloat()
        val maxY = project.currentScene.height.toFloat()
        instances.forEach { item ->
            val width = item.width * item.scaleX
            val height = item.height * item.scaleY
            if (item.x < 0f) { item.x = 0f; item.velocityX = kotlin.math.abs(item.velocityX) * item.bounce }
            if (item.y < 0f) { item.y = 0f; item.velocityY = kotlin.math.abs(item.velocityY) * item.bounce }
            if (item.x + width > maxX) { item.x = max(0f, maxX - width); item.velocityX = -kotlin.math.abs(item.velocityX) * item.bounce }
            if (item.y + height > maxY) { item.y = max(0f, maxY - height); item.velocityY = -kotlin.math.abs(item.velocityY) * item.bounce }
        }
    }

    /** Spatial buckets avoid an all-pairs collision scan for large scenes. */
    private fun resolveCollisions() {
        if (instances.size < 2 || instances.none { it.collisionEnabled }) return
        val buckets = HashMap<Long, MutableList<RuntimeInstance>>()
        val cellSize = 128f
        instances.asSequence().filter { it.collisionEnabled }.forEach { item ->
            val left = kotlin.math.floor(item.x / cellSize).toInt()
            val top = kotlin.math.floor(item.y / cellSize).toInt()
            val right = kotlin.math.floor((item.x + item.width * item.scaleX) / cellSize).toInt()
            val bottom = kotlin.math.floor((item.y + item.height * item.scaleY) / cellSize).toInt()
            for (cy in top..bottom) for (cx in left..right) {
                val key = (cx.toLong() shl 32) xor (cy.toLong() and 0xffffffffL)
                buckets.getOrPut(key) { mutableListOf() }.add(item)
            }
        }
        val tested = HashSet<Long>()
        buckets.values.forEach { bucket ->
            for (a in 0 until bucket.size) for (b in a + 1 until bucket.size) {
                val first = bucket[a]
                val second = bucket[b]
                val low = min(first.id, second.id).toLong()
                val high = max(first.id, second.id).toLong()
                val pairKey = (low shl 32) xor (high and 0xffffffffL)
                if (!tested.add(pairKey)) continue
                if (intersects(first, second)) {
                    runEvents(first, "Collision", 0f, second)
                    runEvents(second, "Collision", 0f, first)
                }
            }
        }
    }

    private fun find(id: Int): RuntimeInstance? = instancesById[id]

    private fun intersects(a: RuntimeInstance, b: RuntimeInstance): Boolean {
        val aw = a.width * a.scaleX
        val ah = a.height * a.scaleY
        val bw = b.width * b.scaleX
        val bh = b.height * b.scaleY
        return a.x < b.x + bw && a.x + aw > b.x && a.y < b.y + bh && a.y + ah > b.y
    }

    private fun ProjectItem.toRuntime(id: Int, definition: GameObjectDefinition?) = RuntimeInstance(
        id = id, objectId = objectId.ifBlank { definition?.id.orEmpty() }, objectName = definition?.name ?: name,
        x = x, y = y, width = width, height = height, rotation = rotation, depth = depth,
        velocityX = velocityX, velocityY = velocityY, gravity = gravity,
        bounce = bounce.coerceIn(0f, 1f), color = color.ifBlank { definition?.color ?: "#55D6A0" },
        visible = visible, alpha = alpha.coerceIn(0f, 1f), text = text, spriteAssetId = spriteAssetId ?: definition?.spriteAssetId,
        collisionEnabled = collisionEnabled, scaleX = scaleX, scaleY = scaleY, variables = variables.toMutableMap(),
    )

    private fun snapshotOf(item: ProjectItem) = item

    companion object {
        private const val HOOK_SETUP = """
            local sethook = debug.sethook
            __bd_set_budget = function(limit)
                if limit > 0 then
                    sethook(function() error('BuildDroid Lua instruction budget exceeded') end, '', limit)
                else
                    sethook()
                end
            end
        """
        private const val SANDBOX = """
            os = nil; io = nil; package = nil; debug = nil
            dofile = nil; loadfile = nil; loadstring = nil; require = nil
            collectgarbage = nil; java = nil; luajava = nil
        """
        private const val LUA_CLASSES = """
            Engine = { name = "BuildDroid", version = "0.8.0", log = Game.log }
            Time = {
                now = function() return Game.time() end,
                delta = function() return Game.delta_time() end
            }
            Scene = {
                name = function() return Game.scene_name() end,
                width = function() return Game.room_width() end,
                height = function() return Game.room_height() end
            }
            Input = {
                key_down = function(key) return Game.keyboard_check(key) end,
                key_pressed = function(key) return Game.keyboard_check_pressed(key) end,
                key_released = function(key) return Game.keyboard_check_released(key) end,
                axis = function(negative, positive)
                    return (Game.keyboard_check(positive) and 1 or 0) - (Game.keyboard_check(negative) and 1 or 0)
                end,
                pointer_x = function() return Game.mouse_x() end,
                pointer_y = function() return Game.mouse_y() end,
                pointer_down = function() return Game.mouse_check_button() end,
                pointer_pressed = function() return Game.mouse_check_button_pressed() end,
                pointer_released = function() return Game.mouse_check_button_released() end
            }
            Transform = {
                position = function(id, x, y)
                    if x == nil or y == nil then return Vector2.new(Game.get_x(id), Game.get_y(id)) end
                    return Game.set_position(id, x, y)
                end,
                move = function(id, x, y) return Game.move(id, x, y) end,
                size = function(id, w, h)
                    if w == nil or h == nil then return Vector2.new(Game.get_width(id), Game.get_height(id)) end
                    return Game.set_size(id, w, h)
                end,
                scale = function(id, x, y)
                    if x == nil then return Vector2.new(Game.get_scale_x(id), Game.get_scale_y(id)) end
                    return Game.set_scale(id, x, y)
                end,
                rotation = function(id, angle)
                    if angle == nil then return Game.get_rotation(id) end
                    return Game.set_rotation(id, angle)
                end,
                depth = function(id, value)
                    if value == nil then return Game.get_depth(id) end
                    return Game.set_depth(id, value)
                end
            }
            Physics = {
                velocity = function(id, x, y)
                    if x == nil or y == nil then return Vector2.new(Game.get_velocity_x(id), Game.get_velocity_y(id)) end
                    return Game.set_velocity(id, x, y)
                end,
                gravity = function(id, value)
                    if value == nil then return Game.get_gravity(id) end
                    return Game.set_gravity(id, value)
                end,
                bounce = function(id, value)
                    if value == nil then return Game.get_bounce(id) end
                    return Game.set_bounce(id, value)
                end,
                collision = function(id, enabled)
                    if enabled == nil then return Game.get_collision(id) end
                    return Game.set_collision(id, enabled)
                end,
                overlaps = function(a, b) return Game.collides(a, b) end
            }
            Instance = {
                create = function(name, x, y) return Game.instance_create(name, x, y) end,
                get = function(id) return Game.instance_get(id) end,
                find = function(name, index) return Game.instance_find(name, index or 0) end,
                nearest = function(x, y, name) return Game.instance_nearest(x, y, name) end,
                count = function(name) return Game.instance_count(name) end,
                exists = function(id) return Game.instance_exists(id) end,
                rename = function(id, name) return Game.set_name(id, name) end,
                name = function(id) return Game.get_name(id) end,
                destroy = function(id) return Game.destroy(id) end
            }
            Math = {
                clamp = Game.clamp, lerp = Game.lerp, sign = Game.sign,
                distance = Game.distance,
                round = function(value) if value < 0 then return math.ceil(value - 0.5) else return math.floor(value + 0.5) end end,
                approach = function(value, target, amount)
                    if value < target then return math.min(value + amount, target) end
                    return math.max(value - amount, target)
                end,
                random_range = function(low, high) return Game.random(low, high) end,
                point_in_rect = Game.point_in_rectangle,
                point_in_circle = Game.point_in_circle
            }
            Vector2 = {}
            function Vector2.new(x, y)
                return setmetatable({ x = x or 0, y = y or 0 }, {
                    __add = function(a, b) return Vector2.new(a.x + b.x, a.y + b.y) end,
                    __sub = function(a, b) return Vector2.new(a.x - b.x, a.y - b.y) end,
                    __mul = function(a, b)
                        if type(a) == "number" then return Vector2.new(a * b.x, a * b.y) end
                        return Vector2.new(a.x * b, a.y * b)
                    end
                })
            end
            function Vector2.length(v) return math.sqrt(v.x * v.x + v.y * v.y) end
            function Vector2.distance(a, b) return Vector2.length(a - b) end
            function Vector2.normalized(v)
                local length = Vector2.length(v)
                if length == 0 then return Vector2.new(0, 0) end
                return Vector2.new(v.x / length, v.y / length)
            end
            Sprite = {
                assign = function(id, assetId) return Game.set_sprite(id, assetId) end,
                get = function(id) return Game.get_sprite(id) end
            }
            Rect = {}
            function Rect.new(x, y, width, height)
                return { x = x or 0, y = y or 0, width = width or 0, height = height or 0 }
            end
            function Rect.contains(rect, x, y)
                return Math.point_in_rect(x, y, rect.x, rect.y, rect.x + rect.width, rect.y + rect.height)
            end
            function Rect.intersects(a, b)
                return a.x < b.x + b.width and a.x + a.width > b.x and
                    a.y < b.y + b.height and a.y + a.height > b.y
            end
            Color = {
                rgb = function(r, g, b)
                    return string.format("#%02X%02X%02X", math.floor(Game.clamp(r, 0, 255)), math.floor(Game.clamp(g, 0, 255)), math.floor(Game.clamp(b, 0, 255)))
                end,
                hex = function(value) return value end,
                with_alpha = function(value, alpha) return { hex = value, alpha = Game.clamp(alpha, 0, 1) } end
            }
        """

        private const val ALIASES = """
            function instance_create(name, x, y) return Game.instance_create(name, x, y) end
            function instance_number(name) return Game.instance_count(name) end
            function instance_exists(id) return Game.instance_exists(id) end
            function instance_destroy(id) return Game.destroy(id) end
            function keyboard_check(key) return Game.keyboard_check(key) end
            function keyboard_check_pressed(key) return Game.keyboard_check_pressed(key) end
            function keyboard_check_released(key) return Game.keyboard_check_released(key) end
            function mouse_x() return Game.mouse_x() end
            function mouse_y() return Game.mouse_y() end
            function mouse_check_button(_button) return Game.mouse_check_button() end
            function mouse_check_button_pressed(_button) return Game.mouse_check_button_pressed() end
            function mouse_check_button_released(_button) return Game.mouse_check_button_released() end
            function room_width() return Game.room_width() end
            function room_height() return Game.room_height() end
            function point_distance(x1, y1, x2, y2) return Game.distance(x1, y1, x2, y2) end
            function instance_nearest(x, y, name) return Game.instance_nearest(x, y, name) end
            function object_exists(name) return Game.object_exists(name) end
            function instance_find(name, index) return Game.instance_find(name, index or 0) end
            function instance_variable_set(id, key, value) return Game.set_variable(id, key, value) end
            function instance_variable_get(id, key) return Game.get_variable(id, key) end
            function lengthdir_x(length, direction) return Game.lengthdir_x(length, direction) end
            function lengthdir_y(length, direction) return Game.lengthdir_y(length, direction) end
            function clamp(value, low, high) return Game.clamp(value, low, high) end
            function lerp(a, b, amount) return Game.lerp(a, b, amount) end
            function sign(value) return Game.sign(value) end
            function point_in_rectangle(x, y, left, top, right, bottom) return Game.point_in_rectangle(x, y, left, top, right, bottom) end
            function other_id() return Game.other() end
            function show_debug_message(message) return Game.log(message) end
            function print(...) local out = {}; for i = 1, select('#', ...) do out[i] = tostring(select(i, ...)) end; Game.log(table.concat(out, ' ')) end
        """
    }
}

object LuaEngine {
    data class TestResult(val log: String, val instanceCount: Int, val sceneName: String)

    /** Boots the real project runtime and advances one frame, checking global and active-scene events. */
    fun validateProject(project: BuildDroidProject): TestResult {
        val objectIds = project.objects.map { it.id }.toSet()
        val missingTargets = project.scripts.mapNotNull { it.targetObjectId }.filterNot { it in objectIds }.distinct()
        require(missingTargets.isEmpty()) { "Scripts reference missing object definitions: ${missingTargets.joinToString()}" }
        val missingInstances = project.scenes.flatMap { it.instances }.map { it.objectId }.filter { it.isNotBlank() && it !in objectIds }.distinct()
        require(missingInstances.isEmpty()) { "Scene instances reference missing objects: ${missingInstances.joinToString()}" }
        val assetIds = project.assets.map { it.id }.toSet()
        val missingSprites = (project.objects.mapNotNull { it.spriteAssetId } + project.scenes.flatMap { it.instances.mapNotNull(ProjectItem::spriteAssetId) }).filterNot { it in assetIds }.distinct()
        require(missingSprites.isEmpty()) { "Objects reference missing image assets: ${missingSprites.joinToString()}" }
        LuaGameRuntime(project).use { runtime ->
            val frame = runtime.tick(1f / 60f)
            frame.error?.let { throw IllegalStateException(it) }
            return TestResult(frame.logs.joinToString("\n"), frame.instances.size, project.currentScene.name)
        }
    }

    fun runPreflight(source: String): TestResult {
        val lua = Lua51()
        val output = mutableListOf<String>()
        var count = 0
        var scene = "MainScene"
        try {
            lua.openLibraries()
            lua.run("local sethook = debug.sethook; __bd_set_budget = function(limit) if limit > 0 then sethook(function() error('BuildDroid Lua instruction budget exceeded') end, '', limit) else sethook() end end")
            lua.createTable(0, 4)
            lua.push(JFunction { state -> output += state.toString(1).orEmpty(); 0 }); lua.setField(-2, "log")
            lua.push(JFunction { state -> count++; state.push(count.toLong()); 1 }); lua.setField(-2, "instance_create")
            lua.push(JFunction { state -> state.push(count.toLong()); 1 }); lua.setField(-2, "instance_count")
            lua.push(JFunction { state -> scene = "MainScene"; state.push(scene); 1 }); lua.setField(-2, "scene_name")
            lua.setGlobal("Game")
            lua.run("os=nil; io=nil; package=nil; debug=nil; dofile=nil; loadfile=nil; loadstring=nil; require=nil; java=nil; luajava=nil")
            lua.load(LuaContinuePreprocessor.transform(source))
            lua.getGlobal("__bd_set_budget")
            lua.push(350_000L)
            lua.pCall(1, 0)
            try {
                lua.pCall(0, 0)
            } finally {
                lua.setTop(0)
                lua.getGlobal("__bd_set_budget")
                lua.push(0L)
                lua.pCall(1, 0)
                lua.setTop(0)
            }
            return TestResult(output.joinToString("\n"), count, scene)
        } finally {
            lua.close()
        }
    }
}
