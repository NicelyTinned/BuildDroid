-- BuildDroid's starter Lua 5.1 script.
speed = 4
health = 100

Game.log("Player ready")
local coinId = Game.instance_create("Coin", 200, 120)
assert(coinId > 0, "instance_create should return an id")
assert(Game.instance_count() == 1, "one instance should exist")
Game.log("Lua API test passed")
