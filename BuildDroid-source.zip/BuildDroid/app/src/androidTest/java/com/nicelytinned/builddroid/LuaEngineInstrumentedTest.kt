package com.nicelytinned.builddroid

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nicelytinned.builddroid.lua.LuaEngine
import com.nicelytinned.builddroid.lua.LuaGameRuntime
import com.nicelytinned.builddroid.model.BuildDroidProject
import com.nicelytinned.builddroid.model.ScriptDocument
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LuaEngineInstrumentedTest {
    @Test
    fun lua51SmokeTestCanCreateAnInstance() {
        val result = LuaEngine.runPreflight(
            """
                Game.log("instrumented test")
                local id = Game.instance_create("Coin", 10, 20)
                assert(id == 1)
                assert(Game.instance_count() == 1)
            """.trimIndent(),
        )
        assertEquals(1, result.instanceCount)
        assertTrue(result.log.contains("instrumented test"))
    }

    @Test
    fun namespacesAndContinueWorkInTheNativeLuaRuntime() {
        val script = ScriptDocument(
            id = "studio-api-test",
            name = "studio-api-test.lua",
            source = """
                assert(Engine.name == "BuildDroid")
                assert(Scene.name() == "MainScene")
                assert(Scene.width() == 640)
                local vector = Vector2.new(3, 4)
                assert(Vector2.length(vector) == 5)

                local sum = 0
                for i = 1, 5 do
                    if i == 3 then continue end
                    sum = sum + i
                end
                assert(sum == 12)

                local step = 0
                while step < 6 do
                    step = step + 1
                    if step == 2 then continue end
                    if step == 4 then break end
                end
                assert(step == 4)

                local instance = Instance.create("Coin", 10, 20)
                Transform.position(instance, 30, 40)
                Transform.size(instance, 42, 24)
                Physics.velocity(instance, 3, 4)
                local position = Transform.position(instance)
                local size = Transform.size(instance)
                local velocity = Physics.velocity(instance)
                local details = Instance.get(instance)
                assert(position.x == 30 and position.y == 40)
                assert(size.x == 42 and size.y == 24)
                assert(velocity.x == 3 and velocity.y == 4)
                assert(details.x == 30 and details.y == 40)
                assert(Instance.name(instance) == "Coin")
                Sprite.assign(instance, "coin-sprite")
                assert(Sprite.get(instance) == "coin-sprite")
                local rect = Rect.new(10, 20, 30, 40)
                assert(Rect.contains(rect, 20, 30))
                assert(Rect.intersects(rect, Rect.new(30, 30, 20, 20)))
                Game.log("api + continue passed")
            """.trimIndent(),
        )
        val project = BuildDroidProject(scripts = listOf(script), selectedScriptId = script.id)
        LuaGameRuntime(project).use { runtime ->
            val frame = runtime.snapshot()
            assertTrue(frame.error.orEmpty().isEmpty())
            assertTrue(frame.logs.any { it.contains("api + continue passed") })
        }
    }

    @Test
    fun runtimeCanAdvanceWithoutPublishingAFullFrameSnapshot() {
        val project = BuildDroidProject()
        LuaGameRuntime(project).use { runtime ->
            val skipped = runtime.tick(1f / 60f, captureFrame = false)
            assertTrue(skipped.instances.isEmpty())
            val published = runtime.snapshot()
            assertEquals(project.currentScene.instances.size, published.instances.size)
        }
    }

}
