package com.nicelytinned.builddroid

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nicelytinned.builddroid.lua.LuaEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LuaEngineInstrumentedTest {
    @Test
    fun lua51SmokeTestCanCreateAnInstance() {
        val result = LuaEngine.runPreflight(
            """
                Game.log("instrumented test")
                local id = Game.instance_create("Coin", 10, 20)
                assert(id == 1)
                assert(Game.instance_count() == 1)
            """.trimIndent(),
        )
        assertEquals(1, result.instanceCount)
        assertTrue(result.log.contains("instrumented test"))
    }
}
