@echo off
set VERSION=8.13
set DISTROOT=%USERPROFILE%\.gradle\wrapper\dists\builddroid-gradle-%VERSION%
set GRADLEHOME=%DISTROOT%\gradle-%VERSION%
if exist "%GRADLEHOME%\bin\gradle.bat" goto runGradle
if not exist "%DISTROOT%" mkdir "%DISTROOT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip='%DISTROOT%\gradle-%VERSION%-bin.zip'; $shaFile=$zip+'.sha256'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile $zip; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip.sha256' -OutFile $shaFile; $expected=(Get-Content $shaFile).Split(' ')[0].ToLower(); $actual=(Get-FileHash $zip -Algorithm SHA256).Hash.ToLower(); if ($expected -ne $actual) { throw 'Gradle distribution checksum mismatch' }; Expand-Archive -Path $zip -DestinationPath '%DISTROOT%' -Force; Remove-Item $zip,$shaFile"
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%
:runGradle
call "%GRADLEHOME%\bin\gradle.bat" %*
