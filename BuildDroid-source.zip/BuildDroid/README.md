# BuildDroid

**BuildDroid** is an Android-first 2D game-making editor by **NicelyTinned**. This is the initial Android Studio source project, not a finished GameMaker replacement.

## Included

- Jetpack Compose Android app with three work areas: **Preview / Edit**, **Explorer**, and **Script**.
- A simple 2D scene canvas with starter instances, `+ Object`, and `+ UI` actions.
- Explorer actions to select, rename, reposition, and delete scene items.
- Local project persistence in app-private storage (`projects/current-project.json`).
- Lua 5.1 execution and a small smoke-test API: `Game.log`, `Game.instance_create`, `Game.instance_count`, `Game.instance_get`, `Game.keyboard_check`, and `Game.scene_name`.
- GitHub token storage encrypted with AES-GCM using Android Keystore.
- GitHub Actions-only APK builds for game projects created inside BuildDroid.

The editor UI and project format are deliberately small. Touch-drag canvas editing, sprite importing/rendering, separate reusable object definitions and scene instances, object event editors, full UI layout controls, a real playtest runtime, collision/physics, and publishing/release signing are not implemented yet.

## Open in Android Studio

1. Extract this ZIP.
2. Open the `BuildDroid` folder in Android Studio.
3. Use JDK 17 and Android SDK Platform 36.
4. Allow Gradle to download its pinned Gradle 8.13 distribution on first sync.
5. Run the `app` configuration on an Android device or emulator (Android 8.0 / API 26 or newer).

The included `gradlew` / `gradlew.bat` scripts bootstrap Gradle 8.13 when a system Gradle is not installed, and verify the downloaded distribution against Gradle's published SHA-256 file.

## Build this app with GitHub Actions from a phone

The source ZIP deliberately does **not** contain the top-level GitHub Actions workflow. Download the separate `build-builddroid.yml` workflow file supplied with this project.

1. Create a GitHub repository, for example `BuildDroid`.
2. Upload this ZIP to the repository root with the exact filename `BuildDroid-source.zip`.
3. In that repository, create `.github/workflows/build-builddroid.yml` and paste the contents of the separate workflow file.
4. Open the repository's **Actions** tab, select **Build BuildDroid APK**, and run it. The workflow also starts automatically when the ZIP or workflow is pushed to the default branch.
5. When the run succeeds, open the run's **Artifacts** section and download `BuildDroid-debug-apk`. The artifact contains the debug APK.

The workflow unzips this archive, runs `testDebugUnitTest`, builds `assembleDebug`, and uploads the APK. It uses the workflow's built-in read-only `GITHUB_TOKEN`; no personal access token or secret is needed to compile BuildDroid itself.

## Lua runtime

BuildDroid uses **LuaJava 4.1.0**, with its `lua51` interpreter and Android AAR. The dependency declarations are in `app/build.gradle.kts`:

```kotlin
implementation("party.iroiro.luajava:luajava:4.1.0")
implementation("party.iroiro.luajava:lua51:4.1.0")
runtimeOnly("party.iroiro.luajava:android:4.1.0:lua51@aar")
```

The first engine API is intentionally tiny. `keyboard_check()` currently returns `false`; it is a stub until Android input events are connected to the runtime. The preflight environment removes Java, filesystem, process, and debug globals after loading standard Lua libraries, and uses a debug-hook instruction budget to catch simple accidental infinite loops. This is an early sandbox, not a security boundary for running hostile scripts.

## In-app GitHub builds for games

The in-app **File → Build APK with Actions** feature is separate from the workflow that builds the BuildDroid editor. It uses a user-provided GitHub token to create/update a game repository, dispatch a generated workflow, and retrieve the resulting APK artifact. Keep that token private and never commit it to a repository.

## Tests and limitations

- `ProjectModelTest` covers repository-name sanitization.
- `LuaEngineInstrumentedTest` exercises the actual Android Lua 5.1 native runtime and should be run on an emulator/device.
- The standalone editor-build workflow runs JVM unit tests before assembling the debug APK. It does not run instrumentation tests on an emulator.
- This is an early prototype. It is not yet a complete 2D engine or a production-ready publishing tool.

## Project identity

- App: **BuildDroid**
- Company: **NicelyTinned**
- Application ID: `com.nicelytinned.builddroid`
- Initial scripting language: **Lua 5.1**
