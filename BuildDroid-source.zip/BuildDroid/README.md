# BuildDroid

![BuildDroid logo](app/src/main/res/drawable-nodpi/builddroid_logo.png)


**BuildDroid** is a mobile-first 2D game editor for Android, made by **NicelyTinned**. It uses a lightweight custom dark interface built with Jetpack Compose Foundation (no Material components), Lua 5.1 through LuaJava, and a project archive format designed for moving projects between devices.

## Current editor features

- Three workspaces: **Scene Editor**, **Explorer**, and **Script**, arranged for narrow phone screens.
- A compact, square-edged studio layout with a scene toolbar, hierarchy, object inspector, and touch-first canvas.
- Canvas selection, drag placement, eight functional edge/corner resize handles, scene grid, scene switching, and add/duplicate/delete instances.
- Fullscreen immersive playtest: the live Lua runtime takes over the display, receives touch pointer input and an on-screen directional pad, and hides Android system bars until playtest exits.
- Reusable object definitions and scene instances, with properties for position, size, rotation, depth, visibility, locking, color, alpha, scaling, velocity, gravity, bounce, collision, text, and sprite assignment.
- Explorer groups scenes, object definitions, current-scene instances, assets, and scripts; selected entries expose editable properties or delete actions.
- Runtime Lua events: Create, Step, Collision, and Destroy. Collision callbacks expose `self`, `other`, and `other_id()`.
- Keyboard input (arrows/WASD) and a touch D-pad in playtest; tap input is exposed through `mouse_x`, `mouse_y`, and `mouse_check_button*`.
- Multiple local projects, debounced autosave, project manager, ZIP import/export, and Android Storage Access Framework (SAF) file importing.
- Scene settings (name, dimensions, background), reusable object definitions, event-script targeting, and instance selection shared between Explorer and the canvas.
- A Lua 5.1 2D runtime with Create, Step, Collision and Destroy events, touch/keyboard input, instance variables, bounds/bounce and spatial-bucket overlap detection.
- Expanded Lua engine namespaces: `Engine`, `Scene`, `Time`, `Input`, `Instance`, `Transform`, `Physics`, `Sprite`, `Math`, `Vector2`, `Rect`, and `Color`.
- Lua 5.1 `continue` compatibility for `while` and `for` loops, including preservation of ordinary `break` behavior.
- A dedicated runtime thread, frame-stepped playtest, throttled UI snapshots, and spatial-bucket collision broad phase.
- Images are decoded off the UI thread and only referenced sprites are preview-decoded, capped to 16 images at 768px maximum dimension using RGB_565 to limit memory pressure.
- Lua editor with line numbers, token syntax highlighting, JetBrains Mono font download/cache, and offline monospace fallback.
- GitHub Actions-only project builds and encrypted GitHub token storage using Android Keystore.

## Imported asset types

Use **File → Import assets / files** or **Explorer → Import** to pick multiple files from Android's document picker. Images are previewed in scenes; `.lua` files are added as script documents. Audio, video, fonts, JSON, CSV, XML, text, and other data files are stored in the project archive. Imported audio/video are resources only in this release; playback and media-specific runtime APIs are not implemented yet. `.lua` files are also added to the Script list. Individual imports are limited to 100 MB.

## Lua 5.1 API (engine surface)

`Game` exposes logging and timing (`log`, `scene_name`, `time`, `delta_time`, `random`); instance creation and lookup (`instance_create`, `instance_count`, `instance_get`, `instance_exists`, `instance_find`, `instance_nearest`, `destroy`, `object_exists`); transforms and state (`set_position`, `move`, `set_velocity`, `set_size`, `set_scale`, `set_depth`, `set_gravity`, `set_bounce`, `set_collision`, `set_color`, `set_visible`, `set_alpha`, `set_rotation`, `set_text`, `set_sprite`, `set_name`, and matching getters); per-instance variables; keyboard and pointer input; scene dimensions; collision and geometry; and common math helpers.

The engine also exposes class-style Lua namespaces:

- `Engine`: engine name/version and logging.
- `Scene`: current scene name and dimensions.
- `Time`: elapsed time and frame delta.
- `Input`: key state, pointer state, and a two-key axis helper.
- `Instance`: create, get, find, nearest, count, exists, and destroy.
- `Transform`: position, movement, size, scale, rotation, and depth, with getter/setter forms.
- `Physics`: velocity, gravity, bounce, collision enablement, getters, and overlap checks.
- `Sprite`: assign and retrieve a project's sprite asset ID for an instance.
- `Math`: clamp, lerp, sign, distance, round, approach, random range, and point/shape tests.
- `Vector2`: vector creation, addition, subtraction, scalar multiplication, length, distance, and normalization.
- `Rect`: rectangle creation, point containment, and overlap tests.
- `Color`: RGB-to-hex conversion, hex passthrough, and alpha metadata helper.

Common global aliases remain available, including `instance_create`, `instance_number`, `instance_exists`, `instance_destroy`, `instance_find`, `instance_nearest`, `keyboard_check`, `mouse_x`, `mouse_y`, `room_width`, `room_height`, `point_distance`, `show_debug_message`, and `print`.

Lua 5.1 has no native `continue` statement. BuildDroid preprocesses `continue` in `while` and `for` loop bodies and preserves `break` behavior for those loops. `continue` in `repeat ... until` is intentionally rejected because a safe Lua 5.1 rewrite would otherwise change the scope of locals used by the `until` condition. Java/Kotlin functionality is exposed through explicit engine APIs rather than unrestricted Java reflection; filesystem, process, `java`, `luajava`, and debug globals remain removed.

The runtime is a compact 2D foundation, not full GameMaker compatibility. It does not yet include a full animation/timeline system, tilemaps, audio playback, particle systems, shader pipeline, or a visual LSP/autocomplete server. The code editor includes line numbers, basic token highlighting, and JetBrains Mono when its font download succeeds; offline use falls back to the platform monospace font. Lua scripts are instruction-budgeted and have OS, filesystem, process, Java, and debug globals removed, but this is not a hardened security boundary for hostile code.

**Export limitation:** the in-app GitHub Actions export is still an early Android smoke-test shell. It includes the Lua 5.1 runtime and project files/assets, but it does not yet reproduce the full BuildDroid editor playtest engine in the exported APK. The editor's own Preview/Playtest runs the fuller in-app runtime described above.

## Open in Android Studio

1. Extract the ZIP.
2. Open the `BuildDroid` folder in Android Studio.
3. Use JDK 17 and Android SDK Platform 36.
4. Use Gradle 8.13, JDK 17, and Android SDK 36. The supplied GitHub workflow installs Gradle directly and does not depend on the Gradle wrapper executable.
5. Run the `app` configuration on Android 8.0 / API 26 or newer.

The app source uses Compose Foundation and UI primitives only; it does not depend on Material 2 or Material 3. The app's layout is deliberately custom and compact for phone screens.

## Build BuildDroid from a phone using GitHub Actions

The source ZIP deliberately does **not** contain the standalone workflow. Use the separate `build-builddroid.yml` file supplied with the ZIP.

1. Create a GitHub repository, for example `BuildDroid`.
2. Upload this ZIP to its root with the exact name `BuildDroid-source.zip`.
3. Create `.github/workflows/build-builddroid.yml` and paste the separate workflow file.
4. Open **Actions → Build BuildDroid APK → Run workflow**.
5. Download `BuildDroid-debug-apk` from the completed workflow run's Artifacts section.

The workflow unpacks the source archive, runs JVM unit tests, builds the debug APK, and uploads it. This workflow builds the **BuildDroid editor app**. The in-app **Build APK with Actions** command is a separate pipeline for a user's game project and needs a GitHub token with repository/workflow/Actions access.

## Lua runtime dependency

The app uses LuaJava 4.1.0 and its Lua 5.1 Android native runtime artifacts:

```kotlin
implementation("party.iroiro.luajava:luajava:4.1.0")
implementation("party.iroiro.luajava:lua51:4.1.0")
runtimeOnly("party.iroiro.luajava:android:4.1.0:lua51@aar")
```

## Tests and verification

- JVM tests cover repository slug handling, project JSON round-tripping, and migration from the original v1 format.
- Android instrumentation tests exercise the native Lua 5.1 runtime and should be run on an emulator or device.
- GitHub Actions runs `testDebugUnitTest` before `assembleDebug`.

A full Android compile and real-device performance test must be run by Android Studio or GitHub Actions. Static source checks alone do not prove that a build passes on every device.

## Project identity

- App: **BuildDroid**
- Version: **0.8.0** (mobile studio update)
- Company: **NicelyTinned**
- Application ID: `com.nicelytinned.builddroid`
- Scripting language: **Lua 5.1**


## v0.8.0 studio and runtime update

- The scene canvas now supports hit-tested selection, move dragging, and eight resize handles.
- Playtest runs as an immersive full-screen scene view with touch pointer tracking and an on-screen directional pad.
- The Lua API now provides class-style engine namespaces (including `Sprite` and `Rect`) and a Lua 5.1 `continue` preprocessor for `while` and `for` loops.
- Studio controls use tighter, squarer surfaces and horizontally scrollable scene tabs for phone layouts.

## v0.7.1 editor and runtime performance notes

- Opening the Lua editor no longer starts a network font download. A previously cached JetBrains Mono file is used when present; otherwise Android's monospace font is used immediately.
- Lua syntax highlighting is cached and skips tokenization for files larger than 48 KB to avoid freezing while typing.
- Script text is edited in a local draft and committed after a short idle debounce, rather than rebuilding the whole project model on every keystroke. Drafts are flushed when switching scripts or leaving the editor.
- Playtest simulation continues at the display frame cadence, while Compose snapshots are published at up to 30 FPS to reduce UI recomposition.
- Runtime instance lookups use an ID map, and per-frame stepping avoids an O(n²) membership scan.
- Imported sprite previews are decoded off the UI thread and capped to 8 referenced images at 512 px maximum dimension.
