# BuildDroid

![BuildDroid logo](app/src/main/res/drawable-nodpi/builddroid_logo.png)


**BuildDroid** is a mobile-first 2D game editor for Android, made by **NicelyTinned**. It uses a lightweight custom dark interface built with Jetpack Compose Foundation (no Material components), Lua 5.1 through LuaJava, and a project archive format designed for moving projects between devices.

## Current editor features

- Three workspaces: **Preview / Edit**, **Explorer**, and **Script**.
- Touch canvas selection and drag placement, grid, scene switching, add/duplicate/delete instances, and live 2D playtest.
- Reusable object definitions and scene instances, with properties for position, size, rotation, depth, visibility, locking, color, alpha, scaling, velocity, gravity, bounce, collision, text, and sprite assignment.
- Explorer groups scenes, object definitions, current-scene instances, assets, and scripts; selected entries expose editable properties or delete actions.
- Runtime Lua events: Create, Step, Collision, and Destroy. Collision callbacks expose `self`, `other`, and `other_id()`.
- Keyboard input (arrows/WASD) and a touch D-pad in playtest; tap input is exposed through `mouse_x`, `mouse_y`, and `mouse_check_button*`.
- Multiple local projects, debounced autosave, project manager, ZIP import/export, and Android Storage Access Framework (SAF) file importing.
- Scene settings (name, dimensions, background), reusable object definitions, event-script targeting, and instance selection shared between Explorer and the canvas.
- A small but functional Lua 5.1 2D runtime with Create, Step, Collision and Destroy events, touch/keyboard input, instance variables, bounds/bounce and spatial-bucket overlap detection.
- A dedicated runtime thread, frame-stepped playtest, throttled UI snapshots, and spatial-bucket collision broad phase.
- Images are decoded off the UI thread and only referenced sprites are preview-decoded, capped to 16 images at 768px maximum dimension using RGB_565 to limit memory pressure.
- Lua editor with line numbers, token syntax highlighting, JetBrains Mono font download/cache, and offline monospace fallback.
- GitHub Actions-only project builds and encrypted GitHub token storage using Android Keystore.

## Imported asset types

Use **File → Import assets / files** or **Explorer → Import** to pick multiple files from Android's document picker. Images are previewed in scenes; `.lua` files are added as script documents. Audio, video, fonts, JSON, CSV, XML, text, and other data files are stored in the project archive. Imported audio/video are resources only in this release; playback and media-specific runtime APIs are not implemented yet. `.lua` files are also added to the Script list. Individual imports are limited to 100 MB.

## Lua 5.1 API (first engine surface)

`Game` functions include:

- Logging and scene timing: `Game.log`, `Game.scene_name`, `Game.time`, `Game.delta_time`, `Game.random`.
- Instances: `Game.instance_create`, `Game.instance_count`, `Game.instance_get`, `Game.instance_exists`, `Game.instance_find`, `Game.instance_nearest`, `Game.destroy`, `Game.object_exists`.
- Transforms and state: `Game.set_position`, `Game.move`, `Game.set_velocity`, `Game.set_size`, `Game.set_scale`, `Game.set_depth`, `Game.set_gravity`, `Game.set_bounce`, `Game.set_collision`, `Game.set_color`, `Game.set_visible`, `Game.set_alpha`, `Game.set_rotation`, `Game.set_text`, `Game.get_x`, `Game.get_y`, `Game.get_velocity_x`, `Game.get_velocity_y`.
- Per-instance variables: `Game.set_variable`, `Game.get_variable`.
- Input: `Game.keyboard_check`, `Game.keyboard_check_pressed`, `Game.keyboard_check_released`, `Game.mouse_x`, `Game.mouse_y`, `Game.mouse_check_button`, `Game.mouse_check_button_pressed`, `Game.mouse_check_button_released`.
- Geometry/math: `Game.room_width`, `Game.room_height`, `Game.distance`, `Game.collides`, `Game.point_in_rectangle`, `Game.clamp`, `Game.lerp`, `Game.sign`, `Game.lengthdir_x`, `Game.lengthdir_y`.

Common global aliases include `instance_create`, `instance_number`, `instance_exists`, `instance_destroy`, `instance_find`, `instance_nearest`, `keyboard_check`, `mouse_x`, `mouse_y`, `room_width`, `room_height`, `point_distance`, `show_debug_message`, and `print`.

The runtime is a compact 2D foundation, not full GameMaker compatibility. It does not yet include a full animation/timeline system, tilemaps, audio playback, particle systems, shader pipeline, or a visual LSP/autocomplete server. The code editor includes line numbers, basic token highlighting, and JetBrains Mono when its font download succeeds; offline use falls back to the platform monospace font. Lua scripts are instruction-budgeted and have OS, filesystem, process, Java, and debug globals removed, but this is not a hardened security boundary for hostile code.

**Export limitation:** the in-app GitHub Actions export is still an early Android smoke-test shell. It includes the Lua 5.1 runtime and project files/assets, but it does not yet reproduce the full BuildDroid editor playtest engine in the exported APK. The editor's own Preview/Playtest runs the fuller in-app runtime described above.

## Open in Android Studio

1. Extract the ZIP.
2. Open the `BuildDroid` folder in Android Studio.
3. Use JDK 17 and Android SDK Platform 36.
4. Use Gradle 8.13, JDK 17, and Android SDK 36. The supplied GitHub workflow installs Gradle directly and does not depend on the Gradle wrapper executable.
5. Run the `app` configuration on Android 8.0 / API 26 or newer.

The app source uses Compose Foundation and UI primitives only; it does not depend on Material 2 or Material 3. The app's layout is deliberately custom and compact for phone screens.

## Build BuildDroid from a phone using GitHub Actions

The source ZIP deliberately does **not** contain the standalone workflow. Use the separate `build-builddroid.yml` file supplied with the ZIP.

1. Create a GitHub repository, for example `BuildDroid`.
2. Upload this ZIP to its root with the exact name `BuildDroid-source.zip`.
3. Create `.github/workflows/build-builddroid.yml` and paste the separate workflow file.
4. Open **Actions → Build BuildDroid APK → Run workflow**.
5. Download `BuildDroid-debug-apk` from the completed workflow run's Artifacts section.

The workflow unpacks the source archive, runs JVM unit tests, builds the debug APK, and uploads it. This workflow builds the **BuildDroid editor app**. The in-app **Build APK with Actions** command is a separate pipeline for a user's game project and needs a GitHub token with repository/workflow/Actions access.

## Lua runtime dependency

The app uses LuaJava 4.1.0 and its Lua 5.1 Android native runtime artifacts:

```kotlin
implementation("party.iroiro.luajava:luajava:4.1.0")
implementation("party.iroiro.luajava:lua51:4.1.0")
runtimeOnly("party.iroiro.luajava:android:4.1.0:lua51@aar")
```

## Tests and verification

- JVM tests cover repository slug handling, project JSON round-tripping, and migration from the original v1 format.
- Android instrumentation tests exercise the native Lua 5.1 runtime and should be run on an emulator or device.
- GitHub Actions runs `testDebugUnitTest` before `assembleDebug`.

A full Android compile and real-device performance test must be run by Android Studio or GitHub Actions. Static source checks alone do not prove that a build passes on every device.

## Project identity

- App: **BuildDroid**
- Version: **0.6.0** (prototype release)
- Company: **NicelyTinned**
- Application ID: `com.nicelytinned.builddroid`
- Scripting language: **Lua 5.1**
